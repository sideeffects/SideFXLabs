"""Cross-platform configuration helper for the ApexScript Toolkit installer.

The shell installers (install.sh / install.ps1) handle platform-specific bits
(finding Python, pip install, copying files). Everything that touches structured
state — Claude Code's settings.json, the ~/.claude/CLAUDE.md block, Codex's
~/.codex/AGENTS.md and config.toml, and the Houdini package .json files — is
funnelled through this one script so the logic is identical on Windows and
Linux and a reinstall/uninstall is idempotent.

It is copied into ~/.apexscript/ at install time so the generated uninstall
script can reuse it after the bundle is gone.

Usage:
    apex_toolkit_config.py hook install   --claude-dir DIR --command CMD
    apex_toolkit_config.py hook install   --claude-dir DIR --interpreter EXE
                                          [--interpreter-arg=ARG ...] --script FILE
    apex_toolkit_config.py hook uninstall --claude-dir DIR
    apex_toolkit_config.py claudemd install   --claude-dir DIR --block-file FILE
    apex_toolkit_config.py claudemd uninstall --claude-dir DIR
    apex_toolkit_config.py codexmd install   --codex-dir DIR --block-file FILE
    apex_toolkit_config.py codexmd uninstall --codex-dir DIR
    apex_toolkit_config.py codexmcp install   --codex-dir DIR --command CMD
    apex_toolkit_config.py codexmcp uninstall --codex-dir DIR
    apex_toolkit_config.py panel install   --panel-path DIR [--stubs-path DIR]
                                           [--reference-path DIR]
                                           [--houdini-root DIR ...]
    apex_toolkit_config.py panel uninstall [--houdini-root DIR ...]
    apex_toolkit_config.py installdir clean  --install-dir DIR
    apex_toolkit_config.py installdir backup-user-data --install-dir DIR [--purge]
    apex_toolkit_config.py launcher install --install-dir DIR --python EXE
    apex_toolkit_config.py preflight [--only pypi|marketplace|vscode-update ...] [--quiet]
    apex_toolkit_config.py doctor --install-dir DIR --claude-dir DIR --codex-dir DIR
                                  [--houdini-root DIR ...]

Exit code 3 from `installdir clean` means lib/ could not even be set aside
because a running process holds it (Claude Code / Codex / Houdini): close them
and re-run; nothing was modified. Usually the rename succeeds even with the
server running: the in-use copy is left as lib.old-<pid> with a NOTE and is
removed by the next install or uninstall.

Exit code is 0 on success, 1 on hard error. Best-effort steps (e.g. a single
Houdini dir failing to write) warn but do not abort.
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys
from pathlib import Path

# --- Constants ---------------------------------------------------------------

HOOK_MARKER = "apexscript_require_mcp.py"  # identifies our PreToolUse entry
HOOK_MATCHER = "Write|Edit|MultiEdit|NotebookEdit"

CLAUDEMD_START = "<!-- apexscript-toolkit:start -->"
CLAUDEMD_END = "<!-- apexscript-toolkit:end -->"

# Codex CLI (~/.codex). AGENTS.md reuses the same HTML-comment markers as
# CLAUDE.md; config.toml needs TOML comment markers instead.
CODEX_TOML_START = "# apexscript-toolkit:start"
CODEX_TOML_END = "# apexscript-toolkit:end"
CODEX_MCP_TABLE = "[mcp_servers.apexscript]"

PANEL_JSON_NAME = "apexscript-houdini-panel.json"

# Matches a Houdini user-pref dir: "houdini20.5" or (on macOS, under a
# "houdini" parent) a bare "20.5".
_HOUDINI_DIR_RE = re.compile(r"^(?:houdini)?(\d+)\.(\d+)$")
# The panel needs Houdini 20.5+ (serve-web embedding, apex::script nodes).
MIN_PANEL_HOUDINI = (20, 5)


def _is_pref_dir(name: str, min_version=MIN_PANEL_HOUDINI) -> bool:
    m = _HOUDINI_DIR_RE.match(name)
    return bool(m) and (int(m.group(1)), int(m.group(2))) >= min_version


# --- Small JSON helpers ------------------------------------------------------

def _load_json(path: Path):
    if not path.exists():
        return None
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None
    if not text.strip():
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        print(f"  WARNING: {path} is not valid JSON; leaving it untouched.")
        raise


def _write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def _to_fwd(p: str) -> str:
    """Forward-slash path. Houdini accepts forward slashes on every platform
    and it keeps the generated JSON free of escape headaches."""
    return str(p).replace("\\", "/")


# --- Hook (settings.json) ----------------------------------------------------

def _group_is_ours(group) -> bool:
    if not isinstance(group, dict):
        return False
    for hook in group.get("hooks", []) or []:
        if isinstance(hook, dict) and HOOK_MARKER in str(hook.get("command", "")):
            return True
    return False


def hook_command(interpreter: str, script: str, interpreter_args=None) -> str:
    """Compose the settings.json hook command line, double-quoting both paths.

    The shells pass the pieces separately and let this side quote them:
    PowerShell 5.1 strips quotes embedded in a single argument, which turned a
    pre-quoted command into an unquoted one that breaks on a profile path with
    a space (found 2026-09-21 in a sandbox install)."""
    parts = [f'"{_to_fwd(interpreter)}"', *(interpreter_args or []), f'"{_to_fwd(script)}"']
    return " ".join(parts)


def hook_install(claude_dir: Path, command: str) -> int:
    settings_path = claude_dir / "settings.json"
    settings = _load_json(settings_path)
    if settings is None:
        settings = {}
    if not isinstance(settings, dict):
        print(f"  ERROR: {settings_path} is not a JSON object; aborting hook step.")
        return 1

    hooks = settings.setdefault("hooks", {})
    if not isinstance(hooks, dict):
        print("  ERROR: settings.json 'hooks' is not an object; aborting hook step.")
        return 1
    pre = hooks.get("PreToolUse")
    if not isinstance(pre, list):
        pre = []

    # Drop any prior version of our entry, then add the fresh one (idempotent).
    pre = [g for g in pre if not _group_is_ours(g)]
    pre.append({
        "matcher": HOOK_MATCHER,
        "hooks": [{"type": "command", "command": command}],
    })
    hooks["PreToolUse"] = pre

    _write_json(settings_path, settings)
    print(f"  Hook command: {command}")
    print(f"  Registered .apex MCP-gate hook in {settings_path}")
    return 0


def hook_uninstall(claude_dir: Path) -> int:
    settings_path = claude_dir / "settings.json"
    settings = _load_json(settings_path)
    if not isinstance(settings, dict):
        return 0  # nothing to do
    hooks = settings.get("hooks")
    if not isinstance(hooks, dict):
        return 0
    pre = hooks.get("PreToolUse")
    if not isinstance(pre, list):
        return 0

    kept = [g for g in pre if not _group_is_ours(g)]
    if len(kept) == len(pre):
        return 0  # ours wasn't present

    if kept:
        hooks["PreToolUse"] = kept
    else:
        hooks.pop("PreToolUse", None)
    if not hooks:
        settings.pop("hooks", None)

    _write_json(settings_path, settings)
    print(f"  Removed .apex MCP-gate hook from {settings_path}")
    return 0


# --- Marker-delimited md blocks (CLAUDE.md / AGENTS.md) ------------------------

def _strip_block(text: str, start: str = CLAUDEMD_START,
                 end: str = CLAUDEMD_END) -> str:
    """Remove an existing marker-delimited block (and trailing newline)."""
    pattern = re.compile(
        re.escape(start) + r".*?" + re.escape(end) + r"\r?\n?",
        re.DOTALL,
    )
    return pattern.sub("", text)


def _replace_block(text: str, block: str, start: str, end: str) -> str:
    """Swap the first marker-delimited block for `block`, keeping everything
    around it byte-for-byte (a strip-and-append would move text the user
    wrote after our block to before it). Stray duplicate blocks left by older
    installers are dropped."""
    pattern = re.compile(re.escape(start) + r".*?" + re.escape(end), re.DOTALL)
    text, n = pattern.subn(lambda _m: block, text, count=1)
    if n:
        cut = text.find(block) + len(block)
        text = text[:cut] + _strip_block(text[cut:], start, end)
    return text


def mdblock_install(md_path: Path, block_file: Path) -> int:
    """Install/refresh the marker-delimited ApexScript section in md_path."""
    try:
        body = block_file.read_text(encoding="utf-8").strip()
    except OSError as exc:
        print(f"  ERROR: could not read block file {block_file}: {exc}")
        return 1

    block = f"{CLAUDEMD_START}\n{body}\n{CLAUDEMD_END}"
    md_path.parent.mkdir(parents=True, exist_ok=True)

    if md_path.exists():
        content = md_path.read_text(encoding="utf-8")
        if CLAUDEMD_START in content:
            content = _replace_block(content, block, CLAUDEMD_START, CLAUDEMD_END)
            print(f"  Updated ApexScript section in {md_path}")
        else:
            content = content.rstrip() + "\n\n" + block + "\n"
            print(f"  Appended ApexScript section to {md_path}")
    else:
        content = block + "\n"
        print(f"  Created {md_path} with ApexScript instructions")

    md_path.write_text(content, encoding="utf-8")
    return 0


def mdblock_uninstall(md_path: Path) -> int:
    if not md_path.exists():
        return 0
    content = md_path.read_text(encoding="utf-8")
    if CLAUDEMD_START not in content:
        return 0
    cleaned = _strip_block(content).rstrip()
    if cleaned:
        md_path.write_text(cleaned + "\n", encoding="utf-8")
    else:
        md_path.unlink()
    print(f"  Removed ApexScript section from {md_path}")
    return 0


def claudemd_install(claude_dir: Path, block_file: Path) -> int:
    return mdblock_install(claude_dir / "CLAUDE.md", block_file)


def claudemd_uninstall(claude_dir: Path) -> int:
    return mdblock_uninstall(claude_dir / "CLAUDE.md")


def codexmd_install(codex_dir: Path, block_file: Path) -> int:
    return mdblock_install(codex_dir / "AGENTS.md", block_file)


def codexmd_uninstall(codex_dir: Path) -> int:
    return mdblock_uninstall(codex_dir / "AGENTS.md")


# --- Codex config.toml MCP entry -----------------------------------------------
# Fallback path for when the `codex` CLI is missing or predates `codex mcp add`.
# Python's tomllib is read-only, so we manage a marker-comment-delimited block
# appended at top level and strip-then-reappend it on reinstall. An unmanaged
# [mcp_servers.apexscript] outside our markers is left alone (warn + manual
# instructions) — never rewrite TOML the user authored.

def _strip_toml_block(text: str) -> str:
    pattern = re.compile(
        re.escape(CODEX_TOML_START) + r".*?" + re.escape(CODEX_TOML_END) + r"\r?\n?",
        re.DOTALL,
    )
    return pattern.sub("", text)


def _toml_literal(value: str) -> str:
    """Quote a path as a TOML string. Prefer a literal string (no escaping,
    Windows backslashes survive verbatim); fall back to a basic string when the
    path itself contains a single quote."""
    if "'" not in value:
        return f"'{value}'"
    escaped = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def codexmcp_install(codex_dir: Path, command: str, args: list[str] | None = None) -> int:
    toml_path = codex_dir / "config.toml"
    content = ""
    if toml_path.exists():
        try:
            content = toml_path.read_text(encoding="utf-8")
        except OSError as exc:
            print(f"  ERROR: could not read {toml_path}: {exc}")
            return 1

    had_block = CODEX_TOML_START in content
    if CODEX_MCP_TABLE in _strip_toml_block(content):
        print(f"  WARNING: {toml_path} already defines {CODEX_MCP_TABLE} outside")
        print("  the apexscript-toolkit markers; leaving it untouched.")
        print("  Point it at the installed server yourself:")
        print(f"      command = {_toml_literal(command)}")
        return 0

    lines = [CODEX_TOML_START, CODEX_MCP_TABLE, f"command = {_toml_literal(command)}"]
    if args:
        lines.append("args = [" + ", ".join(_toml_literal(a) for a in args) + "]")
    # Codex defaults to 10 s; a cold start on a Windows box with AV scanning the
    # vendored lib/ can exceed that. 30 s is generous and costs nothing when fast.
    lines.append("startup_timeout_sec = 30")
    lines.append(CODEX_TOML_END)
    block = "\n".join(lines)
    codex_dir.mkdir(parents=True, exist_ok=True)
    if had_block:
        content = _replace_block(content, block, CODEX_TOML_START, CODEX_TOML_END)
        print(f"  Updated 'apexscript' MCP server in {toml_path}")
    elif content.strip():
        content = content.rstrip() + "\n\n" + block + "\n"
        print(f"  Registered 'apexscript' MCP server in {toml_path}")
    else:
        content = block + "\n"
        print(f"  Created {toml_path} with the 'apexscript' MCP server")
    toml_path.write_text(content, encoding="utf-8")
    return 0


def codexmcp_uninstall(codex_dir: Path) -> int:
    toml_path = codex_dir / "config.toml"
    if not toml_path.exists():
        return 0
    content = toml_path.read_text(encoding="utf-8")
    if CODEX_TOML_START not in content:
        return 0
    cleaned = _strip_toml_block(content).rstrip()
    if cleaned:
        toml_path.write_text(cleaned + "\n", encoding="utf-8")
    else:
        toml_path.unlink()
    print(f"  Removed 'apexscript' MCP server from {toml_path}")
    return 0


# --- Houdini panel package json ----------------------------------------------

def _houdini_pref_dirs(roots) -> list[Path]:
    """Find Houdini user-pref dirs (e.g. ~/houdini20.5) under the given roots,
    plus $HOUDINI_USER_PREF_DIR if it is set and exists."""
    found: list[Path] = []

    explicit = os.environ.get("HOUDINI_USER_PREF_DIR")
    if explicit:
        p = Path(explicit)
        if p.is_dir():
            found.append(p)

    for root in roots:
        root = Path(root)
        if not root.is_dir():
            continue
        # The root itself may be a pref dir (when passed directly).
        if _is_pref_dir(root.name):
            found.append(root)
        for child in root.iterdir():
            try:
                if child.is_dir() and _is_pref_dir(child.name):
                    found.append(child)
            except OSError:
                continue

    # De-duplicate while preserving order.
    seen = set()
    unique: list[Path] = []
    for p in found:
        key = str(p.resolve()).lower()
        if key not in seen:
            seen.add(key)
            unique.append(p)
    return unique


def _panel_json(panel_path: str, stubs_path: str, reference_path: str) -> dict:
    env = [
        {"PYTHONPATH": {"value": _to_fwd(panel_path) + "/python", "method": "prepend"}},
        {"HOUDINI_PATH": {"value": _to_fwd(panel_path), "method": "append"}},
        {"APEXSCRIPT_PANEL_PATH": _to_fwd(panel_path)},
    ]
    if stubs_path:
        env.append({"APEX_STUBS_PATH": _to_fwd(stubs_path)})
    if reference_path:
        env.append({"APEX_REFERENCE_PATH": _to_fwd(reference_path)})
    return {"path": _to_fwd(panel_path), "env": env}


def panel_install(panel_path: str, stubs_path: str, reference_path: str,
                  roots) -> int:
    pref_dirs = _houdini_pref_dirs(roots)
    if not pref_dirs:
        print("  No Houdini user-pref directories found.")
        print("  To enable the panel later, copy this file into your Houdini")
        print(f"  packages/ dir and restart Houdini:")
        print(f"      {PANEL_JSON_NAME}")
        return 0

    payload = _panel_json(panel_path, stubs_path, reference_path)
    wrote_any = False
    for pref in pref_dirs:
        try:
            pkg_dir = pref / "packages"
            pkg_dir.mkdir(parents=True, exist_ok=True)
            (pkg_dir / PANEL_JSON_NAME).write_text(
                json.dumps(payload, indent=4) + "\n", encoding="utf-8")
            print(f"  Installed panel for {pref.name}: {pkg_dir / PANEL_JSON_NAME}")
            wrote_any = True
        except OSError as exc:
            print(f"  WARNING: could not write panel json under {pref}: {exc}")
    if not wrote_any:
        return 0
    print("  Restart Houdini, then open: Pane Tab Menu > ApexScript Editor")
    return 0


def panel_uninstall(roots) -> int:
    for pref in _houdini_pref_dirs(roots):
        target = pref / "packages" / PANEL_JSON_NAME
        if target.exists():
            try:
                target.unlink()
                print(f"  Removed {target}")
            except OSError as exc:
                print(f"  WARNING: could not remove {target}: {exc}")
    return 0



# --- Install dir lifecycle ---------------------------------------------------
# ~/.apexscript holds two kinds of content: files the installer manages (and may
# freely replace) and USER DATA the MCP server writes on the user's behalf
# (save_snippet -> snippets/, workflows/). A reinstall must never touch the
# latter; an uninstall moves it aside instead of deleting it.

USER_DATA_DIRS = ("snippets", "workflows")
MANAGED_ENTRIES = (
    "lib", "bin", "houdini-panel", "__pycache__",
    "apex_toolkit_config.py", "claude-md-block.md", "agents-md-block.md",
    "uninstall.sh", "uninstall.ps1", "uninstall.cmd", "VERSION", "install.log",
)
EXIT_LOCKED = 3


def _rmtree(path: Path) -> None:
    import shutil
    if path.is_dir() and not path.is_symlink():
        shutil.rmtree(path)
    else:
        path.unlink()


def installdir_clean(install_dir: Path) -> int:
    """Remove everything the installer manages; keep user data and unknown files.

    On Windows a running MCP server / hook / panel keeps compiled extension
    modules in lib/ mapped, so a recursive delete would stop half-way. We first
    RENAME lib/ aside (atomic). Verified on Windows 2026-09-21: the rename
    succeeds even while a .pyd inside is mapped by a live process (only a
    handle on the directory itself blocks it), so the usual outcome with a
    running server is: the install proceeds on a fresh lib/, the in-use copy
    stays behind as lib.old-<pid> (NOTE below) and is removed by the next
    install or uninstall. Only when the rename itself fails do we abort, before
    anything has been modified."""
    if not install_dir.is_dir():
        return 0
    lib = install_dir / "lib"
    if lib.is_dir():
        staging = install_dir / f"lib.old-{os.getpid()}"
        try:
            lib.rename(staging)
        except OSError as exc:
            print("  ERROR: the installed files are in use (probably a running Claude Code,")
            print("  Codex or Houdini session holding the MCP server open).")
            print(f"  Close them and re-run the installer.  ({exc})")
            return EXIT_LOCKED

    for name in MANAGED_ENTRIES:
        target = install_dir / name
        if target.exists() or target.is_symlink():
            try:
                _rmtree(target)
            except OSError as exc:
                print(f"  WARNING: could not remove {target}: {exc}")
    # The renamed lib plus any stale staging dirs from earlier aborted runs.
    for stale in install_dir.glob("lib.old-*"):
        try:
            _rmtree(stale)
        except OSError as exc:
            print(f"  NOTE: {stale.name} is still in use (a running Claude Code, Codex or Houdini")
            print(f"  session has the previous MCP server loaded) and was left in place. It is")
            print(f"  removed by the next install or uninstall, or delete it by hand after closing")
            print(f"  them. Restart those sessions to pick up the new install.  ({exc})")

    kept = sorted(p.name for p in install_dir.iterdir())
    if kept:
        print(f"  Kept in {install_dir}: {', '.join(kept)}")
    return 0


def installdir_backup_user_data(install_dir: Path, purge: bool = False) -> int:
    """Move snippets/ and workflows/ out of the install dir before it is removed.

    Returns 0 whether or not there was anything to move."""
    import datetime
    import shutil
    present = [install_dir / d for d in USER_DATA_DIRS
               if (install_dir / d).is_dir() and any((install_dir / d).iterdir())]
    if not present:
        return 0
    if purge:
        for d in present:
            _rmtree(d)
            print(f"  Deleted user data {d} (--purge)")
        return 0
    stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
    backup = install_dir.parent / f"{install_dir.name}-user-backup-{stamp}"
    backup.mkdir(parents=True, exist_ok=True)
    for d in present:
        shutil.move(str(d), str(backup / d.name))
    print(f"  Your snippets/workflows were moved to: {backup}")
    print(f"  Move them back into {install_dir} after a reinstall to keep using them.")
    return 0


# --- Launcher -----------------------------------------------------------------
# One Python launcher (registered with Claude Code / Codex as `<python> <launcher>`,
# so no batch file is involved on Windows) plus a shell wrapper per platform for
# humans and --selfcheck. lib/ is a pip --target dir, not a site dir: its .pth
# files (pywin32's DLL bootstrap) are only honoured through site.addsitedir().

LAUNCHER_NAME = "apexscript_mcp_launcher.py"
_LAUNCHER_TEMPLATE = (
    '"""ApexScript MCP server launcher (generated by the installer; do not edit).\n'
    '\n'
    'Registered with Claude Code / Codex as:  {python} {this_file}\n'
    'lib/ is a pip --target directory: put it first on sys.path so vendored deps win\n'
    'over anything leaked via PYTHONPATH, then process its .pth files (pywin32).\n'
    '"""\n'
    'import site\n'
    'import sys\n'
    '\n'
    'LIB = {lib!r}\n'
    '\n'
    'sys.path.insert(0, LIB)\n'
    'site.addsitedir(LIB)\n'
    '\n'
    'from apexscript_mcp_server.server import main  # noqa: E402\n'
    '\n'
    'if __name__ == "__main__":\n'
    '    main()\n'
)


def launcher_install(install_dir: Path, python: str) -> int:
    bin_dir = install_dir / "bin"
    bin_dir.mkdir(parents=True, exist_ok=True)
    lib = str(install_dir / "lib")
    launcher = bin_dir / LAUNCHER_NAME
    # Paths inside the generated docstring use forward slashes: a Windows path
    # like "C:" + backslash + "Users" would be read as a broken unicode escape.
    launcher.write_text(
        _LAUNCHER_TEMPLATE.format(python=_to_fwd(python), this_file=_to_fwd(str(launcher)),
                                  lib=lib),
        encoding="utf-8")

    if os.name == "nt":
        wrapper = bin_dir / "apexscript-mcp-server.cmd"
        # PYTHONHOME leaked from a Houdini shell breaks interpreter startup before
        # any Python runs; only a shell layer can clear it.
        wrapper.write_text(
            "@echo off\r\n"
            "set PYTHONHOME=\r\n"
            f"\"{python}\" \"{launcher}\" %*\r\n",
            encoding="utf-8")
    else:
        wrapper = bin_dir / "apexscript-mcp-server"
        wrapper.write_text(
            "#!/usr/bin/env bash\n"
            "unset PYTHONHOME\n"
            f"exec \"{python}\" \"{launcher}\" \"$@\"\n",
            encoding="utf-8")
        wrapper.chmod(0o755)
    print(f"  Launcher: {launcher}")
    print(f"  Wrapper:  {wrapper}")
    return 0



# --- Network preflight --------------------------------------------------------
# The install needs PyPI (pip), the VS Code Marketplace (ms-python.python) and,
# for the Houdini panel's first launch, the VS Code update server (serve-web
# download). Behind a proxy or air-gapped these fail late and one at a time;
# say so up front instead. urllib honours HTTP(S)_PROXY / NO_PROXY.

PREFLIGHT_TARGETS = {
    "pypi": ("PyPI (pip install)", "https://pypi.org/simple/mcp/"),
    "marketplace": ("VS Code Marketplace (Pylance extension)",
                    "https://marketplace.visualstudio.com/"),
    "vscode-update": ("VS Code update server (Houdini panel first launch)",
                      "https://update.code.visualstudio.com/api/commits/stable/win32-x64"),
}


def preflight(only=None, quiet: bool = False, timeout: float = 5.0) -> int:
    import urllib.error
    import urllib.request
    names = [n for n in PREFLIGHT_TARGETS if not only or n in only]
    blocked = []
    for name in names:
        label, url = PREFLIGHT_TARGETS[name]
        req = urllib.request.Request(url, method="HEAD",
                                     headers={"User-Agent": "apexscript-toolkit-installer"})
        try:
            with urllib.request.urlopen(req, timeout=timeout):
                pass
            status = "OK      "
        except urllib.error.HTTPError as exc:
            status = f"OK      "  # reachable; HEAD may be refused (405) but the host answers
            label += f" (HTTP {exc.code})"
        except Exception as exc:  # URLError, socket.timeout, ssl errors
            status = "BLOCKED "
            label += f": {type(exc).__name__}: {getattr(exc, 'reason', exc)}"
            blocked.append(name)
        if not quiet:
            print(f"  {status} {label}")
    if blocked and not quiet:
        print("  Some services are unreachable (offline or proxy?). Steps that need them")
        print("  will be skipped or fail; see README.md > Prerequisites.")
    return 2 if blocked else 0


# --- Doctor -----------------------------------------------------------------
# Stdlib-only health report that works even when the MCP server itself cannot
# import. Everything a bug report needs in one paste.

def _run(cmd, timeout=60):
    import subprocess
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout + r.stderr).strip()
    except Exception as exc:
        return -1, f"{type(exc).__name__}: {exc}"


def _find_cli(name: str):
    """PATH lookup plus the places the CLIs' own installers put them (a fresh
    install is only on PATH in NEW shells)."""
    import shutil
    found = shutil.which(name)
    if found:
        return found
    home = Path.home()
    exe = ".exe" if os.name == "nt" else ""
    candidates = [home / ".local" / "bin" / f"{name}{exe}"]
    if name == "claude":
        # Claude Code's VS Code extension ships the CLI too; someone who only
        # uses Claude Code inside VS Code has nothing else on PATH. Newest first.
        candidates += sorted(home.glob(
            f".vscode/extensions/anthropic.claude-code-*/resources/native-binary/claude{exe}"),
            reverse=True)
    if os.name == "nt":
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            candidates.append(Path(appdata) / "npm" / f"{name}.cmd")
        if name == "code":
            for base in (os.environ.get("LOCALAPPDATA", ""), os.environ.get("ProgramFiles", "")):
                if base:
                    candidates.append(Path(base) / ("Programs/Microsoft VS Code/bin/code.cmd"
                                                     if "Local" in base else
                                                     "Microsoft VS Code/bin/code.cmd"))
    elif name == "code":
        candidates += [Path("/snap/bin/code"), Path("/usr/share/code/bin/code"),
                       Path("/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code")]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def doctor(install_dir: Path, claude_dir: Path, codex_dir: Path, roots) -> int:
    lines = []

    def row(status, what, detail=""):
        lines.append(f"  {status:<8} {what}" + (f": {detail}" if detail else ""))

    lines.append("=== ApexScript Toolkit doctor ===")
    version_file = install_dir / "VERSION"
    row("INFO", "toolkit version",
        version_file.read_text(encoding="utf-8").strip() if version_file.exists() else "unknown (older bundle without a VERSION file)")
    row("INFO", "doctor python", f"{sys.executable} ({sys.version.split()[0]})")
    row("INFO", "platform", sys.platform)

    # Install dir + vendored deps
    lib = install_dir / "lib"
    if not lib.is_dir():
        row("MISSING", "install dir", f"{lib} not found; run the installer")
    else:
        dists = sorted(p.name[:-10] for p in lib.glob("*.dist-info"))
        mcp = [d for d in dists if d.lower().startswith("mcp-")]
        row("OK" if mcp else "MISSING", "vendored mcp", mcp[0] if mcp else "no mcp-*.dist-info in lib/")
        if mcp and not mcp[0].split("-")[1].startswith("1."):
            row("BAD", "mcp major version", f"{mcp[0]} (server needs 1.x)")
        if os.name == "nt":
            row("OK" if (lib / "pywin32.pth").exists() else "MISSING", "pywin32.pth in lib",
                "" if (lib / "pywin32.pth").exists() else "pywin32 not vendored; reinstall")

    stale = sorted(p.name for p in install_dir.glob("lib.old-*"))
    if stale:
        row("INFO", "stale lib copies", f"{', '.join(stale)} (previous lib/ was still in use at "
            "install time; removed by the next install/uninstall, or delete by hand)")

    # Launcher + self-check
    launcher = install_dir / "bin" / LAUNCHER_NAME
    if not launcher.exists():
        row("MISSING", "launcher", str(launcher))
        python_for_launcher = None
    else:
        python_for_launcher = None
        for line in launcher.read_text(encoding="utf-8").splitlines():
            if line.startswith("Registered with Claude Code / Codex as:"):
                python_for_launcher = line.split(":", 1)[1].strip().split(" ", 1)[0]
                break
        if python_for_launcher and not Path(python_for_launcher).exists():
            row("BAD", "pinned interpreter", f"{python_for_launcher} no longer exists; re-run the installer")
        else:
            rc, out = _run([python_for_launcher or sys.executable, str(launcher), "--selfcheck"])
            last = out.splitlines()[-1] if out else "(no output)"
            row("OK" if rc == 0 else "BAD", "server self-check", last)

    # Claude Code: hook + registration + shadowing
    settings = _load_json_quiet(claude_dir / "settings.json")
    groups = (settings or {}).get("hooks", {}).get("PreToolUse", []) if isinstance(settings, dict) else []
    ours = [g for g in groups if _group_is_ours(g)]
    if ours:
        cmd = ours[0]["hooks"][0].get("command", "")
        row("OK", ".apex MCP-gate hook", cmd)
        hook_file = claude_dir / "hooks" / HOOK_MARKER
        if not hook_file.exists():
            row("BAD", "hook script", f"{hook_file} missing")
    else:
        row("MISSING", ".apex MCP-gate hook", f"no entry in {claude_dir / 'settings.json'}")
    claude_json = _load_json_quiet(claude_dir.parent / ".claude.json")
    entry = ((claude_json or {}).get("mcpServers") or {}).get("apexscript") if isinstance(claude_json, dict) else None
    if entry:
        text = json.dumps(entry)
        row("OK" if LAUNCHER_NAME in text else "WARN", "Claude Code user-scope registration",
            text if LAUNCHER_NAME in text else f"points elsewhere: {text}")
    else:
        row("MISSING", "Claude Code user-scope registration",
            "no 'apexscript' in ~/.claude.json (claude CLI absent at install time?)")
    proj = _load_json_quiet(Path.cwd() / ".mcp.json")
    if isinstance(proj, dict) and "apexscript" in (proj.get("mcpServers") or {}):
        row("WARN", "project .mcp.json shadows the user-scope server",
            json.dumps(proj["mcpServers"]["apexscript"]))
    claude_cli = _find_cli("claude")
    row("OK" if claude_cli else "INFO", "claude CLI", claude_cli or "not found")

    # Codex
    toml = codex_dir / "config.toml"
    if toml.exists():
        content = toml.read_text(encoding="utf-8")
        if CODEX_MCP_TABLE in content:
            row("OK", "Codex registration", f"{CODEX_MCP_TABLE} in {toml}"
                + ("" if LAUNCHER_NAME in content else " (not our launcher)"))
        else:
            row("MISSING", "Codex registration", f"no {CODEX_MCP_TABLE} in {toml}")
    else:
        row("INFO", "Codex", "no ~/.codex/config.toml (Codex not installed)")

    # Houdini panel
    prefs = _houdini_pref_dirs(roots)
    if not prefs:
        row("INFO", "Houdini panel", "no Houdini >= 20.5 pref dirs found")
    for pref in prefs:
        target = pref / "packages" / PANEL_JSON_NAME
        row("OK" if target.exists() else "MISSING", f"panel package for {pref.name}", str(target))

    # VS Code extensions
    code = _find_cli("code")
    if not code:
        row("INFO", "VS Code CLI", "not found (extension/panel unavailable)")
    else:
        rc, out = _run([code, "--list-extensions"], timeout=90) if os.name != "nt" else \
            _run([os.environ.get("ComSpec", "cmd.exe"), "/c", code, "--list-extensions"], timeout=90)
        ids = {l.strip().lower() for l in out.splitlines()}
        for ext in ("apexscript.apexscript-lsp", "ms-python.python"):
            row("OK" if ext in ids else "MISSING", f"VS Code extension {ext}")

    print("\n".join(lines))
    bad = [l for l in lines if l.lstrip().startswith(("BAD", "MISSING"))]
    print(f"\n  {len(bad)} problem(s) found." if bad else "\n  All checks passed.")
    return 1 if bad else 0


def _load_json_quiet(path: Path):
    try:
        return json.loads(path.read_text(encoding="utf-8")) if path.exists() else None
    except Exception:
        return None


# --- CLI ---------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="group", required=True)

    hook = sub.add_parser("hook").add_subparsers(dest="action", required=True)
    hi = hook.add_parser("install")
    hi.add_argument("--claude-dir", required=True)
    hi.add_argument("--command", help="full command line, already quoted")
    hi.add_argument("--interpreter", help="alternative to --command: interpreter path")
    hi.add_argument("--interpreter-arg", action="append", default=[],
                    help="extra interpreter argument, e.g. --interpreter-arg=-3")
    hi.add_argument("--script", help="hook script path (with --interpreter)")
    hu = hook.add_parser("uninstall")
    hu.add_argument("--claude-dir", required=True)

    cm = sub.add_parser("claudemd").add_subparsers(dest="action", required=True)
    ci = cm.add_parser("install")
    ci.add_argument("--claude-dir", required=True)
    ci.add_argument("--block-file", required=True)
    cu = cm.add_parser("uninstall")
    cu.add_argument("--claude-dir", required=True)

    xm = sub.add_parser("codexmd").add_subparsers(dest="action", required=True)
    xi = xm.add_parser("install")
    xi.add_argument("--codex-dir", required=True)
    xi.add_argument("--block-file", required=True)
    xu = xm.add_parser("uninstall")
    xu.add_argument("--codex-dir", required=True)

    xc = sub.add_parser("codexmcp").add_subparsers(dest="action", required=True)
    xci = xc.add_parser("install")
    xci.add_argument("--codex-dir", required=True)
    xci.add_argument("--command", required=True)
    xcu = xc.add_parser("uninstall")
    xcu.add_argument("--codex-dir", required=True)

    panel = sub.add_parser("panel").add_subparsers(dest="action", required=True)
    pi = panel.add_parser("install")
    pi.add_argument("--panel-path", required=True)
    pi.add_argument("--stubs-path", default="")
    pi.add_argument("--reference-path", default="")
    pi.add_argument("--houdini-root", action="append", default=[])
    pu = panel.add_parser("uninstall")
    pu.add_argument("--houdini-root", action="append", default=[])

    xci.add_argument("--arg", dest="args", action="append", default=[],
                     help="argument for the command (repeatable)")

    idir = sub.add_parser("installdir").add_subparsers(dest="action", required=True)
    ic = idir.add_parser("clean")
    ic.add_argument("--install-dir", required=True)
    ib = idir.add_parser("backup-user-data")
    ib.add_argument("--install-dir", required=True)
    ib.add_argument("--purge", action="store_true")

    la = sub.add_parser("launcher").add_subparsers(dest="action", required=True)
    li = la.add_parser("install")
    li.add_argument("--install-dir", required=True)
    li.add_argument("--python", required=True)

    pf = sub.add_parser("preflight")
    pf.add_argument("--only", action="append", default=[], choices=sorted(PREFLIGHT_TARGETS))
    pf.add_argument("--quiet", action="store_true")

    dr = sub.add_parser("doctor")
    dr.add_argument("--install-dir", default=str(Path.home() / ".apexscript"))
    dr.add_argument("--claude-dir", default=str(Path.home() / ".claude"))
    dr.add_argument("--codex-dir", default=str(Path.home() / ".codex"))
    dr.add_argument("--houdini-root", action="append", default=None)

    return parser


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    try:
        if args.group == "hook":
            if args.action == "install":
                if args.command and (args.interpreter or args.script):
                    print("  ERROR: give either --command or --interpreter/--script, not both.")
                    return 1
                if not args.command and not (args.interpreter and args.script):
                    print("  ERROR: hook install needs --command, or --interpreter and --script.")
                    return 1
                command = args.command or hook_command(
                    args.interpreter, args.script, args.interpreter_arg)
                return hook_install(Path(args.claude_dir), command)
            return hook_uninstall(Path(args.claude_dir))
        if args.group == "claudemd":
            if args.action == "install":
                return claudemd_install(Path(args.claude_dir), Path(args.block_file))
            return claudemd_uninstall(Path(args.claude_dir))
        if args.group == "codexmd":
            if args.action == "install":
                return codexmd_install(Path(args.codex_dir), Path(args.block_file))
            return codexmd_uninstall(Path(args.codex_dir))
        if args.group == "codexmcp":
            if args.action == "install":
                return codexmcp_install(Path(args.codex_dir), args.command, args.args)
            return codexmcp_uninstall(Path(args.codex_dir))
        if args.group == "panel":
            if args.action == "install":
                return panel_install(args.panel_path, args.stubs_path,
                                     args.reference_path, args.houdini_root)
            return panel_uninstall(args.houdini_root)
        if args.group == "installdir":
            if args.action == "clean":
                return installdir_clean(Path(args.install_dir))
            return installdir_backup_user_data(Path(args.install_dir), args.purge)
        if args.group == "launcher":
            return launcher_install(Path(args.install_dir), args.python)
        if args.group == "preflight":
            return preflight(args.only or None, args.quiet)
        if args.group == "doctor":
            roots = args.houdini_root
            if roots is None:
                home = Path.home()
                roots = [str(home), str(home / "Documents"),
                         str(home / "Library" / "Preferences" / "houdini")]
            return doctor(Path(args.install_dir), Path(args.claude_dir),
                          Path(args.codex_dir), roots)
    except json.JSONDecodeError:
        return 1
    return 1


if __name__ == "__main__":
    sys.exit(main())
