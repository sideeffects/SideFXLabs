# ApexScript Toolkit

Development tools for ApexScript — the Houdini APEX scripting language.

## What's Included

| Component | Description |
|-----------|-------------|
| **MCP Server** | AI agent integration — 13 tools + 80 resources for Claude Code and Codex CLI |
| **Reference Loader** | 5000+ callback signatures, 290 examples, snippets, and docs |
| **VS Code Extension** | Pylance-based type checking, completions, and diagnostics (optional) |
| **.apex MCP-gate hook** | Claude Code hook that blocks `.apex` edits until the MCP server is consulted — the biggest quality lever (Claude Code only; Codex gets equivalent rules via `AGENTS.md`) |
| **Houdini Panel** | ApexScript editor for `apex::script` / `apex::autorigcomponent` nodes: **Edit in VS Code** opens the node's snippet in VS Code, and saving there updates the node (auto-detected Houdini installs) |
| **Snippet skill** | A Claude Code skill (`apexscript-save-snippets`) that curates reusable ApexScript patterns from a session and saves them to your library via the MCP `save_snippet` tool — also installed as a Codex custom prompt (`/apexscript-save-snippets`) |

## Prerequisites

- **Python 3.11 – 3.14, with pip** (3.10 and older are rejected by the installer) — any native interpreter:
  [python.org](https://www.python.org/downloads/), [uv](https://docs.astral.sh/uv/),
  Homebrew, or your distro's package manager. Debian/Ubuntu need `python3-pip`
  installed separately (`sudo apt install python3-pip`). Every Python
  dependency (including `pywin32` on Windows) is vendored into the install
  directory and pinned via a bundled `constraints.txt` — nothing beyond the
  interpreter and pip is required. If no usable interpreter is found, the
  installer lists every candidate it checked and why it was rejected (too
  old, no pip, Cygwin/MSYS, ...).
- **Network access** during install — the installer checks reachability of
  PyPI, the VS Code Marketplace, and the VS Code update server up front and
  reports each. Offline / air-gapped installs are not supported in this
  release.

Optional:
- **VS Code** — for the ApexScript extension (code completion / diagnostics) and
  the Houdini panel (which needs the `code` CLI). The extension defaults to
  `pylance` mode and needs **Pylance** (`ms-python.python`) for completions;
  the installer auto-installs it when VS Code is found and the Marketplace is
  reachable (and the embedded Houdini panel installs it automatically too),
  so you normally don't install it by hand. If VS Code isn't on `PATH` at
  install time, install `ms-python.python` from the Marketplace yourself.
- **Claude Code** — for auto-configured MCP server
- **Codex CLI** — also auto-configured when detected (`codex` on PATH, or an
  existing `~/.codex` directory); gets the MCP server, `AGENTS.md` rules, and
  the snippet prompt, but not the `.apex` MCP-gate hook (see Codex section
  below).

> **Note:** Cygwin and MSYS Python are not supported (no wheels for the
> compiled dependencies) — the installer rejects them even if found on
> `PATH`. Use a native Windows Python (or WSL) instead.

## Install

### Linux / macOS / WSL

```bash
tar xzf apexscript-toolkit-*.tar.gz
cd apexscript-toolkit-*/
chmod +x install.sh
./install.sh
```

> **Note:** macOS is supported best-effort — `install.sh` has code paths for
> it, but it is untested. Linux and WSL are the verified Unix targets.

### Windows

```cmd
Expand-Archive apexscript-toolkit-*.zip -DestinationPath .
cd apexscript-toolkit-*
install.cmd
```

`install.cmd` runs `install.ps1` with the execution policy bypassed for that
one process — the default PowerShell policy, plus the Mark-of-the-Web on a
downloaded zip, otherwise blocks `.ps1` scripts from running at all. You can
still run `.\install.ps1` directly if you unblock it first
(`Unblock-File .\install.ps1`, or
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned`). Flags pass through,
e.g. `install.cmd -Force` for a non-interactive reinstall.

### What Happens

The installer creates a self-contained directory at:
- **Linux/macOS/WSL:** `~/.apexscript/`
- **Windows:** `%USERPROFILE%\.apexscript\`

It contains the MCP server, reference loader, and all Python dependencies.
Nothing is installed globally — delete the directory to uninstall. The
bundle's `VERSION` file is copied in too (the installer also prints it in its
banner), and the whole run is logged to `~/.apexscript/install.log`.

Before installing anything, the installer checks network reachability of
PyPI, the VS Code Marketplace, and the VS Code update server, printing a line
per service so you know up front what will be skipped.

If an installation already exists, you're asked whether to reinstall (or pass
`-Force`/`--force`/`-y` for a non-interactive reinstall). A reinstall only
replaces the files the installer manages — your snippet library (`snippets/`
and `workflows/`) is always kept — and no longer runs the previous version's
uninstaller. On Windows, if Claude Code, Codex, or Houdini still have the MCP
server loaded, the previous `lib/` is set aside as `lib.old-<pid>` (a NOTE is
printed) and removed by the next install or uninstall; restart those sessions
to pick up the new install. Only if `lib/` cannot even be renamed does the
reinstall stop early and change nothing.

If **Claude Code** is found, the MCP server is auto-registered at user scope
so it's available in every project, as
`<python> <install-dir>/bin/apexscript_mcp_launcher.py` — a plain Python
launcher, no batch file is ever spawned by Claude Code. Any existing
`apexscript` registration is removed first, since `claude mcp add` refuses to
overwrite one. A `CLAUDE.md` is also written to `~/.claude/CLAUDE.md` that
instructs Claude to prioritize the MCP server tools whenever working with
`.apex` files. If **VS Code** is found, the extension is installed with
bundled stubs, plus **Pylance** (`ms-python.python`) — skipped, with a manual
install command printed, if the VS Code Marketplace isn't reachable.

If **Codex CLI** is found (the `codex` command on PATH, or an existing
`~/.codex` directory), the MCP server is registered there too — via
`codex mcp add` when available (the same `<python> <launcher>` command; any
existing registration is removed first), otherwise as a marker-delimited
`[mcp_servers.apexscript]` block in `~/.codex/config.toml` (with
`startup_timeout_sec = 30`, since a cold start on a slow or AV-scanned disk
can exceed Codex's 10 s default; an existing hand-written `apexscript` entry
is never touched). An ApexScript section is also written into
`~/.codex/AGENTS.md`, and the snippet-curation workflow is installed as a
custom prompt at `~/.codex/prompts/apexscript-save-snippets.md` (invoke it
with `/apexscript-save-snippets` in a Codex session). **Codex has no hook
system**, so the `.apex` MCP-gate below is Claude Code only — Codex gets the
MCP server, the AGENTS.md rules, and the snippet prompt, but not the
enforcement hook, and the `[skip-apex-hook]` bypass token has no effect there
since there's no hook to skip.

If `claude`, `codex`, or `code` aren't on `PATH` yet, the installer also
checks the well-known places their own installers put them (e.g.
`~/.local/bin`, `%APPDATA%\npm`, VS Code's default install directories)
before giving up on each. For `claude` it also looks for the CLI bundled with
Claude Code's VS Code extension
(`~/.vscode/extensions/anthropic.claude-code-*/resources/native-binary/`), so
people who only use Claude Code inside VS Code still get the registration.

The installer also:

- **Installs the `.apex` MCP-gate hook.** It drops
  `apexscript_require_mcp.py` into `~/.claude/hooks/` and registers a
  `PreToolUse` entry in `~/.claude/settings.json`. From then on, Claude is
  blocked from writing or editing a `.apex` file unless it called an
  `mcp__apexscript__*` tool in the same turn — forcing snippet/example
  lookups before code is written. Bypass a single edit with the literal
  token `[skip-apex-hook]` in your message. Existing `settings.json` content
  is preserved (the entry is merged, not overwritten). On Windows the hook is
  registered through the `py -3` launcher when available, so it keeps
  working across Python upgrades instead of pointing at one interpreter path
  that may later disappear.
- **Installs the Houdini panel.** The panel (plus its LSP extension, stubs,
  and reference data) is copied under `~/.apexscript/houdini-panel/`, and an
  `apexscript-houdini-panel.json` package file is written into the
  `packages/` folder of every detected Houdini **20.5+** user-pref directory
  (`~/houdiniXX.X` on Linux/macOS, `Documents\houdiniXX.X` on Windows, plus
  `$HOUDINI_USER_PREF_DIR` if set). Paths are absolute and resolved at
  install time. Restart Houdini and open **Pane Tab Menu > ApexScript
  Editor**. If no Houdini install is detected, this step is skipped with a
  note. The panel needs the `code` CLI, and downloads a pinned VS Code
  serve-web build plus Pylance the *first* time you open it — that first
  launch needs internet access even on an otherwise offline machine.

## Uninstall

### Linux / macOS / WSL

```bash
~/.apexscript/uninstall.sh        # from the install
./uninstall.sh                     # or straight from the unpacked bundle
```

### Windows

```cmd
uninstall.cmd
```

or, from an existing install: `%USERPROFILE%\.apexscript\uninstall.cmd`. Like
`install.cmd`, this runs `uninstall.ps1` with the execution policy bypassed
for that one process; `.\uninstall.ps1` works directly too once unblocked
(see Install, above). Pass `-Purge` to delete the snippet library instead of
backing it up (see below).

The same `uninstall.sh` / `uninstall.ps1` / `uninstall.cmd` ship inside the
bundle, so you can remove an existing installation even without re-running
the installer.

This removes the install directory, the MCP server registrations (Claude Code
and Codex — including the `config.toml` fallback block and the installed Codex
prompt), the VS Code extension, the `.apex` MCP-gate hook (and its
`settings.json` entry), the injected `CLAUDE.md` / `AGENTS.md` sections, and
the `apexscript-houdini-panel.json` package file from each detected Houdini
user-pref directory. If the `codex` CLI registered the server but is no longer
on PATH at uninstall time, remove the `[mcp_servers.apexscript]` entry from
`~/.codex/config.toml` by hand.

Your snippet library (`snippets/` and `workflows/`) is **not** deleted by
default — it's moved to a sibling folder,
`~/.apexscript-user-backup-<timestamp>/` (the exact path is printed), so a
later reinstall can pick it back up. Pass `--purge` (Linux/macOS/WSL) or
`-Purge` (Windows) to delete it outright instead.

The uninstaller leaves `~/.vscode-serve-web/` (the Houdini panel's VS Code
profile — extensions, settings, workspace-trust state) in place, since it
isn't part of the toolkit install. Delete that folder by hand if you want a
fully clean slate.

## Getting Started

### With Claude Code (MCP)

If the installer found `claude` on PATH, the MCP server is already configured.
Just open Claude Code in any project and start working with `.apex` files —
the ApexScript tools are automatically available.

To verify: `claude mcp list` should show `apexscript`. For a fuller health
check, see Diagnostics under Troubleshooting.

### With Codex CLI (MCP)

If the installer detected Codex, the MCP server is registered and
`~/.codex/AGENTS.md` instructs it to use the ApexScript tools first (snippets
before writing, no signatures from memory, validate before finishing). Restart
any running Codex session after installing so it picks up the new config.

To verify: `codex mcp list` should show `apexscript` (or check
`~/.codex/config.toml` for `[mcp_servers.apexscript]`).

Note: the `.apex` MCP-gate is a Claude Code hook and does **not** run under
Codex — Codex has no hook system at all, so there the AGENTS.md rules are
advisory, not enforced, and the `[skip-apex-hook]` bypass token has no effect
(there's nothing installed for it to skip).

### With VS Code

1. Open VS Code
2. Create or open a `.apex` file
3. Type `apex.geo.` to see Pylance completions
4. Use snippets like `@sg` or `@ns` to scaffold code

### With the Houdini Panel

1. Restart Houdini after install
2. **Pane Tab Menu > ApexScript Editor**, or select an `apex::script` /
   `apex::autorigcomponent` node
3. Click **Edit in VS Code**. The snippet opens in your open VS Code window,
   or in a new window with the panel's workspace if VS Code isn't running.
   Saving there updates the node.

### Manual MCP Configuration

If the installer couldn't auto-configure (no `claude` CLI), add to your
project's `.mcp.json`. This is the same form the installer registers:
`command` is the Python interpreter it pinned, `args` points at the
generated launcher — no batch file is involved.

```json
{
  "mcpServers": {
    "apexscript": {
      "command": "/path/to/python3",
      "args": ["~/.apexscript/bin/apexscript_mcp_launcher.py"]
    }
  }
}
```

Windows:
```json
{
  "mcpServers": {
    "apexscript": {
      "command": "C:\\Path\\To\\python.exe",
      "args": ["%USERPROFILE%\\.apexscript\\bin\\apexscript_mcp_launcher.py"]
    }
  }
}
```

Codex CLI (`~/.codex/config.toml`):
```toml
[mcp_servers.apexscript]
command = '/path/to/python3'
args = ['/home/<you>/.apexscript/bin/apexscript_mcp_launcher.py']
startup_timeout_sec = 30
# Windows: command = 'C:\Path\To\python.exe'
#          args = ['C:\Users\<you>\.apexscript\bin\apexscript_mcp_launcher.py']
```

Not sure which interpreter the installer used? Check the end of
`~/.apexscript/install.log`, or just test the pinned command by hand with the
shell wrapper — `~/.apexscript/bin/apexscript-mcp-server` (Linux/macOS) or
`%USERPROFILE%\.apexscript\bin\apexscript-mcp-server.cmd` (Windows), the same
one `--selfcheck` uses — which wraps the identical `python` + launcher call.

> **Important — scope shadowing:** a project-scope `apexscript` entry in a
> `.mcp.json` **overrides** the user-scope registration the installer creates,
> so you'd keep running the old/manual entry without realizing. If you set one
> up manually, **remove the project-scope entry after installing** so the
> installed server is the one that runs. (The uninstaller only removes the
> user-scope registration — delete any project-scope entry by hand.)

## Troubleshooting

### Diagnostics

Get a one-paste health report — toolkit version, vendored `mcp`, launcher
self-check, Claude Code / Codex hook and registration status (including a
warning if a project `.mcp.json` is shadowing the user-scope entry), Houdini
panel package files, and VS Code extensions:

```bash
"<python>" ~/.apexscript/apex_toolkit_config.py doctor
```

Windows:
```cmd
"C:\Path\To\python.exe" "%USERPROFILE%\.apexscript\apex_toolkit_config.py" doctor
```

Any Python 3.11+ works for `doctor` itself. Paste the output in bug reports.
`claude mcp list` should also show `apexscript` as connected.

**MCP server not starting:**
- Verify the registered command exists: `<python>` and
  `~/.apexscript/bin/apexscript_mcp_launcher.py` (Linux/macOS), or on Windows
  `%USERPROFILE%\.apexscript\bin\apexscript_mcp_launcher.py`
- Check registration: `claude mcp list`, or run `doctor` above
- Test manually with the shell wrapper: `~/.apexscript/bin/apexscript-mcp-server`
  (Linux/macOS) or `%USERPROFILE%\.apexscript\bin\apexscript-mcp-server.cmd`
  (Windows) — should hang waiting for stdio input; add `--selfcheck` for a
  quick pass/fail instead
- The launcher/wrapper pin the Python path resolved at install time. If that
  interpreter later moves or is pruned (e.g. `uv` upgrading its managed
  CPython, a Python reinstall), it fails with a "not found" error — just
  **re-run the installer** to regenerate it.
- If a project `.mcp.json` also defines `apexscript`, it **shadows** the
  user-scope registration — remove it (see "scope shadowing" above).

**`ModuleNotFoundError: No module named 'pywintypes'` (Windows):**
- Fixed in bundles built from September 2026 on (check `VERSION` and `install.log` in the install dir) (the vendored `pywin32`'s `.pth` bootstrap wasn't
  loaded by the old launcher). Re-run the installer with the current bundle.

**`AttributeError: 'Server' object has no attribute 'list_resources'`:**
- Fixed in bundles built from September 2026 on (check `VERSION` and `install.log` in the install dir) (the old installer could let unpinned `mcp` 2.x
  install; the current wheel pins `mcp<2`). Re-run the installer with the
  current bundle.

**`install.ps1` aborts at "Installing VS Code extension" with
`NativeCommandError` / `DEP0169 DeprecationWarning`:**
- Fixed in bundles built from September 2026 on (check `VERSION` and `install.log` in the install dir) (a harmless VS Code stderr warning used to abort
  the install). Re-run the installer with the current bundle. On an old
  bundle, install the extensions by hand instead:
  `code --install-extension <bundle>\apexscript-lsp-*.vsix` and
  `code --install-extension ms-python.python`.

**`install.ps1` "cannot be loaded because running scripts is disabled on
this system":**
- The default PowerShell execution policy (plus the Mark-of-the-Web on a
  downloaded zip) blocks `.ps1` files from running directly. Use
  `install.cmd` instead — it runs `install.ps1` with the policy bypassed for
  that one process. Or unblock the script yourself:
  `Unblock-File .\install.ps1`.

**Installer says "the installed files are in use" (during a reinstall):**
- A running Claude Code, Codex, or Houdini session is holding the MCP server
  open and `lib/` could not be renamed. Close them and re-run — nothing was
  changed.

**Installer prints "lib.old-<pid> is still in use" (during a reinstall):**
- Same cause, but the install went through on a fresh `lib/`; the copy the
  running session still has loaded was left as `~/.apexscript/lib.old-<pid>`.
  Restart Claude Code / Codex / Houdini to use the new install. The stale
  folder is removed by the next install or uninstall (or delete it by hand);
  `doctor` lists it as "stale lib copies".

**"Skipped: the VS Code Marketplace is unreachable from here" (Pylance not
installed):**
- The network preflight couldn't reach the Marketplace. Once you have
  access, install it by hand: `code --install-extension ms-python.python`.

**Which toolkit version do I have?**
- `cat ~/.apexscript/VERSION` (Windows: `type %USERPROFILE%\.apexscript\VERSION`),
  or the first line of `doctor`'s output above.

**Installer says "no usable Python 3.11+ found" (or lists a candidate as "too old"):**
- Python 3.10 and older are not supported; install 3.11 or newer.
- On uv-only machines (`py` is absent and `python`/`python3` are Microsoft
  Store stub aliases), the installer auto-detects a uv-managed CPython. If it
  still can't find one, run `uv python install 3.11` and re-run the installer.
- Or put any real Python 3.11+ on `PATH` before running the installer.

**Pylance not showing completions:**
- Check extension: `code --list-extensions | grep apexscript`
- Ensure `apexscript.mode` is `"pylance"` in VS Code settings
- Reload VS Code (Ctrl+Shift+P > "Reload Window")

**pip errors during install:**
- Ensure you're using native Python, not Cygwin Python
- If pip is missing: `python3 -m ensurepip --upgrade`

**`.apex` edits are being blocked in Claude Code:**
- That's the MCP-gate hook working as intended — call an `mcp__apexscript__*`
  tool first (e.g. `get_snippet`), then write the file.
- To bypass a single edit, include the literal token `[skip-apex-hook]` in
  your message.
- To disable it entirely, remove the `PreToolUse` entry from
  `~/.claude/settings.json` (or run the uninstaller).

**Houdini panel not appearing:**
- Confirm the package file exists: `<houdini-pref-dir>/packages/apexscript-houdini-panel.json`
- If your Houdini install wasn't detected, copy that file manually from
  `~/.apexscript/houdini-panel/` and set its paths, then restart Houdini.
- Verify in Houdini's Python shell: `import os; print(os.environ.get('HOUDINI_PATH',''))`
