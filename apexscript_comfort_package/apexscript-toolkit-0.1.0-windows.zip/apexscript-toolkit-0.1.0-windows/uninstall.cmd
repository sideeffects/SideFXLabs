@echo off
REM ApexScript Toolkit uninstaller bootstrap (see install.cmd). Pass-through: -Purge.
REM "(goto) 2>nul &" leaves the batch-file context before powershell runs:
REM uninstall.ps1 deletes the directory this file lives in (the installed copy),
REM and cmd would otherwise re-open the batch file afterwards and fail with
REM "The system cannot find the path specified" (exit 1). This way powershell's
REM exit code is what the caller sees. %~dp0 and %* are expanded before the goto.
(goto) 2>nul & powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0uninstall.ps1" %*
