# ApexScript (.apex files)

IMPORTANT: When working with .apex files or answering ApexScript questions, ALWAYS use the apexscript MCP server tools FIRST. Do not fall back to raw file reads on reference data.

A PreToolUse hook enforces this: writing or editing a `.apex` file is blocked unless an `mcp__apexscript__*` tool was used in the same turn. Bypass a single edit by including the literal token `[skip-apex-hook]` in your message.

**Start here:**
- `get_snippet` — ALWAYS check first: curated copy-paste patterns (controls, IK, loops, constraints, graphs, etc.)
- `get_workflow_guide` — step-by-step guides for multi-step tasks (rigging, geometry, graph-building)

**Then use as needed:**
- `search_examples` / `read_example` — find and read reference code from the example library
- `get_apexscript_help` — syntax, language features, and general help
- `get_callback_signature` — look up API signatures and parameters
- `search_callbacks_by_namespace` — find callbacks in a specific namespace
- `get_namespace_help` — comprehensive help for a namespace (geo, skel, transform, etc.)
- `get_domain_overview` — overview of related namespaces (geometry, rigging, simulation, etc.)
- `get_oo_methods` — object-oriented method signatures by type
- `validate_apexscript` — check code for syntax and semantic errors
- `generate_apexscript` — generate ApexScript code from a description
- `save_snippet` — save new snippets to the library
