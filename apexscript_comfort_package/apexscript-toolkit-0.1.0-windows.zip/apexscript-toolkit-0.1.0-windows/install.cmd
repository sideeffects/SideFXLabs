@echo off
REM ApexScript Toolkit installer bootstrap.
REM Runs install.ps1 with the execution policy bypassed for THIS process only:
REM the default policy (Restricted) and the Mark-of-the-Web on a downloaded zip
REM otherwise block .ps1 scripts. Pass-through arguments: -Force, -y.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1" %*
exit /b %ERRORLEVEL%
