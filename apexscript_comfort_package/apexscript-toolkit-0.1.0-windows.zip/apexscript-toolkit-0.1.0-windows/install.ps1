# ApexScript Toolkit Installer (Windows PowerShell)
# Installs everything into %USERPROFILE%\.apexscript\ — no venv, no global pollution.
#Requires -Version 5.1

param(
    [switch]$Force,                       # reinstall without prompting (non-interactive / CI)
    [Alias('y', 'Yes')][switch]$AssumeYes
)

$ErrorActionPreference = "Stop"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = Join-Path $env:USERPROFILE ".apexscript"
$ClaudeDir = Join-Path $env:USERPROFILE ".claude"
$Helper = Join-Path $InstallDir "apex_toolkit_config.py"
$BundleHelper = Join-Path $ScriptDir "apex_toolkit_config.py"
$VersionFile = Join-Path $ScriptDir "VERSION"
$ToolkitVersion = if (Test-Path $VersionFile) { (Get-Content $VersionFile -Raw).Trim() } else { "dev" }

Write-Host "=== ApexScript Toolkit Installer $ToolkitVersion ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Install directory: $InstallDir"
Write-Host ""

# --- Check for existing installation ---
# NOTE: we deliberately do NOT run the previously installed uninstaller here.
# Older uninstallers delete the whole .apexscript dir, including the user's
# snippets/ and workflows/ (written by the MCP server's save_snippet). Every
# step below is idempotent (hook, CLAUDE.md block, registrations, panel json
# are replaced in place), so a reinstall only needs the managed files removed,
# which the bundled helper does while keeping user data ("installdir clean").
$ReinstallPending = $false
if (Test-Path $InstallDir) {
    $doReinstall = $Force -or $AssumeYes
    if (-not $doReinstall) {
        $response = Read-Host "Existing installation found. Reinstall? [y/N] (snippets/workflows are kept)"
        $doReinstall = ($response -eq 'y' -or $response -eq 'Y')
    }
    if ($doReinstall) {
        $ReinstallPending = $true
    } else {
        Write-Host "Aborted."
        exit 0
    }
}

# --- Find Python 3.11+ ---
# Capture a native command's first stdout line, tolerating stderr chatter. Under
# $ErrorActionPreference = 'Stop', a redirected stderr line becomes a terminating
# NativeCommandError in PowerShell 5.1, which made the probes below skip perfectly
# good interpreters (e.g. a `py` launcher that prints a warning but still runs).
# Returns $null on non-zero exit, no output, or a missing/stub executable.
function Get-NativeOutput {
    param([string]$Exe, [string[]]$Arguments)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $out = & $Exe @Arguments 2>&1 |
            Where-Object { $_ -isnot [System.Management.Automation.ErrorRecord] } |
            ForEach-Object { "$_" }
        if ($LASTEXITCODE -ne 0 -or -not $out) { return $null }
        return ("$($out | Select-Object -First 1)").Trim()
    } catch { return $null } finally { $ErrorActionPreference = $prev }
}

# One probe answers everything we need to decide: "major.minor|platform|pip|exe".
# A usable interpreter is 3.11+ (3.10 is NOT supported), native Windows (not Cygwin/MSYS: no wheels for
# the compiled deps) and has pip. Rejected candidates are listed on failure so
# the user sees WHY ("3.9 too old", "no pip") instead of a bare "not found".
$Probe = "import sys, importlib.util; print(f'{sys.version_info.major}.{sys.version_info.minor}|{sys.platform}|{int(importlib.util.find_spec('pip') is not None)}|{sys.executable}')"
$Python = $null
$PythonPath = $null
$Rejected = @()
function Test-PythonCandidate {
    param([string]$Label, [string]$Exe, [string[]]$PreArgs)
    $out = Get-NativeOutput $Exe ($PreArgs + @("-c", $Probe))
    if (-not $out) { $script:Rejected += "$Label - not found or does not run"; return $null }
    $f = $out -split '\|'
    if ($f.Count -lt 4) { $script:Rejected += "$Label - unexpected probe output '$out'"; return $null }
    $major, $minor = $f[0] -split '\.'
    if ([int]$major -lt 3 -or [int]$minor -lt 11) { $script:Rejected += "$Label - Python $($f[0]) is too old: the toolkit needs Python 3.11 or newer"; return $null }
    if ($f[1] -match '^(cygwin|msys)') { $script:Rejected += "$Label - Cygwin/MSYS Python is not supported (no wheels for compiled deps)"; return $null }
    if ($f[2] -ne "1") { $script:Rejected += "$Label - $($f[3]) has no pip (run: `"$($f[3])`" -m ensurepip --upgrade)"; return $null }
    if ([int]$minor -gt 14) { Write-Host "Note: Python $($f[0]) is newer than the tested range (3.11-3.14)." -ForegroundColor DarkYellow }
    return $f[3]
}
foreach ($cmd in @("py -3", "python3", "python")) {
    $parts = $cmd -split ' '
    # Must stay an ARRAY: in PS 5.1 a one-element slice collapses to a scalar
    # string and string + array concatenates into ONE bogus argument.
    $pyArgs = @($parts | Select-Object -Skip 1)
    $PythonPath = Test-PythonCandidate $cmd $parts[0] $pyArgs
    if ($PythonPath) { $Python = $cmd; break }
}

# Fallback: uv-managed CPython. Common on uv-only machines where `py` is absent
# and `python`/`python3` are the Microsoft Store stub aliases (which produce no
# usable interpreter). uv's CPython ships pip, so it installs fine once found.
if (-not $Python -and (Get-Command uv -ErrorAction SilentlyContinue)) {
    $uvPy = Get-NativeOutput "uv" @("python", "find", ">=3.11")
    if ($uvPy -and (Test-Path $uvPy)) {
        $PythonPath = Test-PythonCandidate "uv python" $uvPy @()
        if ($PythonPath) { $Python = $uvPy; Write-Host "Found uv-managed Python: $PythonPath" }
    }
}

if (-not $Python) {
    Write-Host "ERROR: no usable Python 3.11+ found (Python 3.10 and older are not supported). Candidates checked:" -ForegroundColor Red
    foreach ($r in $Rejected) { Write-Host "  - $r" -ForegroundColor Red }
    Write-Host "Install Python from https://www.python.org/downloads/ (tick 'pip'),"
    Write-Host "or with uv:  uv python install 3.12   (then re-run this installer)."
    exit 1
}

# Run a native command without letting PowerShell 5.1 turn stderr text into a
# terminating NativeCommandError (it does so whenever stderr is redirected while
# $ErrorActionPreference = 'Stop' - including when the whole installer is run
# under a wrapper that captures stderr; VS Code >= 1.135 prints a Node DEP0169
# deprecation warning on stderr, which used to abort the whole install here).
# Echoes output indented, drops Node deprecation noise, returns the exit code.
function Invoke-Native {
    param([string]$Exe, [string[]]$Arguments)
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $Exe @Arguments 2>&1 | ForEach-Object {
            $line = if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { "$_" }
            if ($line -and $line -notmatch '^\(node:\d+\) \[DEP\d+\]|^\(Use .*--trace-deprecation') { Write-Host "    $line" }
        }
        return $LASTEXITCODE
    } finally { $ErrorActionPreference = $prev }
}

# Invoke the resolved interpreter directly. Discovery already resolved the real
# sys.executable (even for the `py -3` launcher and uv cases), so this handles
# paths with spaces and avoids re-parsing a command string. Returns the exit code.
function Invoke-Python {
    param([string[]]$Arguments)
    return Invoke-Native $PythonPath $Arguments
}

$pyVersion = Get-NativeOutput $PythonPath @("--version")
Write-Host "Using Python: $PythonPath ($pyVersion)"

# Sanitize the env for the rest of the install. A Houdini shell leaks
# PYTHONHOME/PYTHONPATH that can poison pip's target resolution or break the
# interpreter. We resolved the real interpreter above, so these are now safe to drop.
Remove-Item Env:PYTHONHOME -ErrorAction SilentlyContinue
Remove-Item Env:PYTHONPATH -ErrorAction SilentlyContinue

# --- Network preflight ---
# Say up front what is reachable instead of failing one step at a time later.
Write-Host ""
Write-Host ">>> Checking network access..." -ForegroundColor Yellow
$null = Invoke-Python @($BundleHelper, "preflight")
$MarketplaceOk = (Invoke-Python @($BundleHelper, "preflight", "--only", "marketplace", "--quiet")) -eq 0

# --- Remove the previous install's managed files (user data is kept) ---
# Done with the BUNDLED helper (the installed copy is one of the files removed).
# Exit 3 = lib/ could not be set aside (a running Claude Code / Codex / Houdini
# holds it): nothing has been modified at that point, so the old install keeps
# working. Usually the rename succeeds even with the server running; the in-use
# copy is then left as lib.old-<pid> (the helper prints a NOTE) and removed by
# the next install or uninstall.
if ($ReinstallPending) {
    Write-Host "Removing previous installation (keeping snippets/ and workflows/)..."
    $rc = Invoke-Python @($BundleHelper, "installdir", "clean", "--install-dir", $InstallDir)
    if ($rc -ne 0) {
        Write-Host "ERROR: could not remove the previous installation (exit $rc). Nothing was changed." -ForegroundColor Red
        exit 1
    }
}

# --- Create install directory ---
$LibDir = Join-Path $InstallDir "lib"
$BinDir = Join-Path $InstallDir "bin"
$SnippetsDir = Join-Path $InstallDir "snippets"
New-Item -ItemType Directory -Path $LibDir -Force | Out-Null
New-Item -ItemType Directory -Path $BinDir -Force | Out-Null
New-Item -ItemType Directory -Path $SnippetsDir -Force | Out-Null

# From here on, keep a transcript for bug reports (the dir exists and is clean).
$InstallLog = Join-Path $InstallDir "install.log"
try { Start-Transcript -Path $InstallLog -Force | Out-Null } catch { }
Write-Host "Toolkit version: $ToolkitVersion   (log: $InstallLog)"
if (Test-Path $VersionFile) { Copy-Item $VersionFile $InstallDir -Force }

# Copy the cross-platform config helper + canonical instruction blocks in so
# the uninstall script can reuse them after the bundle is gone.
Copy-Item (Join-Path $ScriptDir "apex_toolkit_config.py") $InstallDir -Force
Copy-Item (Join-Path $ScriptDir "claude-md-block.md") $InstallDir -Force
if (Test-Path (Join-Path $ScriptDir "agents-md-block.md")) {
    Copy-Item (Join-Path $ScriptDir "agents-md-block.md") $InstallDir -Force
}

# --- Step 1: Install Python packages ---
Write-Host ""
Write-Host ">>> Installing Python packages into $LibDir..." -ForegroundColor Yellow
$RefWheel = Get-ChildItem -Path $ScriptDir -Filter "apexscript_reference_loader-*.whl" | Select-Object -First 1
$McpWheel = Get-ChildItem -Path $ScriptDir -Filter "apexscript_mcp_server-*.whl" | Select-Object -First 1

if (-not $RefWheel) {
    Write-Host "ERROR: apexscript_reference_loader wheel not found in $ScriptDir" -ForegroundColor Red
    exit 1
}
if (-not $McpWheel) {
    Write-Host "ERROR: apexscript_mcp_server wheel not found in $ScriptDir" -ForegroundColor Red
    exit 1
}

# constraints.txt (written at build time) pins every transitive dependency to
# the versions the bundle was tested with; without it pip floats to whatever
# PyPI serves on install day (that is how mcp 2.x got in).
$PipArgs = @("-m", "pip", "install", "--target", $LibDir, "--quiet")
$Constraints = Join-Path $ScriptDir "constraints.txt"
if (Test-Path $Constraints) { $PipArgs += @("-c", $Constraints) }
$rc = Invoke-Python ($PipArgs + @($RefWheel.FullName, $McpWheel.FullName))
if ($rc -ne 0) {
    Write-Host "ERROR: pip install failed (exit $rc). See the output above; README.md > Troubleshooting > 'pip errors'." -ForegroundColor Red
    exit 1
}
Write-Host "    Done."

# --- Step 2: Create the launcher ---
# The helper writes bin\apexscript_mcp_launcher.py (registered with Claude Code
# and Codex as `<python> <launcher>`, so no batch file is ever spawned by them)
# and bin\apexscript-mcp-server.cmd for humans / --selfcheck. Both pin the exact
# interpreter that just ran pip (its ABI matches the compiled deps). The .cmd
# also clears a PYTHONHOME leaked from a Houdini shell; the .py launcher puts
# lib first on sys.path and processes its .pth files (pywin32 needs that).
Write-Host ""
Write-Host ">>> Writing launcher..." -ForegroundColor Yellow
$null = Invoke-Python @($Helper, "launcher", "install", "--install-dir", $InstallDir, "--python", $PythonPath)
$McpBin = Join-Path $BinDir "apexscript-mcp-server.cmd"
$Launcher = Join-Path $BinDir "apexscript_mcp_launcher.py"

# Warn if the pinned interpreter lives inside a Houdini install (works, but binds
# the toolkit to an interpreter that moves with HFS upgrades).
if ($PythonPath -match '(?i)hfs|houdini|sidefx') {
    Write-Host "    Note: pinned interpreter is inside a Houdini install:" -ForegroundColor DarkYellow
    Write-Host "          $PythonPath" -ForegroundColor DarkYellow
    Write-Host "          For a more stable install, re-run from a shell where" -ForegroundColor DarkYellow
    Write-Host "          'python'/'py -3' is a standalone system/uv Python." -ForegroundColor DarkYellow
}

# --- Step 3: Install VS Code extension ---
Write-Host ""
# Find a CLI on PATH or at the well-known places its own installer puts it (a
# fresh install is only on PATH in NEW shells, so the current one may miss it).
function Find-Cli {
    param([string[]]$Names, [string[]]$Candidates)
    foreach ($n in $Names) { if (Get-Command $n -ErrorAction SilentlyContinue) { return $n } }
    foreach ($c in $Candidates) { if ($c -and (Test-Path $c)) { return $c } }
    return $null
}
$CodeCmd = Find-Cli @("code", "code-insiders") @(
    (Join-Path $env:LOCALAPPDATA "Programs\Microsoft VS Code\bin\code.cmd"),
    (Join-Path $env:ProgramFiles "Microsoft VS Code\bin\code.cmd"))

$Vsix = Get-ChildItem -Path $ScriptDir -Filter "apexscript-lsp-*.vsix" | Select-Object -First 1
$VsixInstalled = $false
if (-not $Vsix) {
    Write-Host "Note: VS Code extension (.vsix) not found in bundle, skipping." -ForegroundColor DarkYellow
} elseif (-not $CodeCmd) {
    Write-Host "Note: VS Code not found on PATH. To install the extension later:" -ForegroundColor DarkYellow
    Write-Host "    code --install-extension $($Vsix.FullName)"
} else {
    Write-Host ">>> Installing VS Code extension..." -ForegroundColor Yellow
    $rc = Invoke-Native $CodeCmd @("--install-extension", $Vsix.FullName, "--force")
    if ($rc -eq 0) {
        $VsixInstalled = $true
        Write-Host "    Done."
    } else {
        Write-Host "    Warning: extension install failed (exit $rc). Install it later with:" -ForegroundColor DarkYellow
        Write-Host "    $CodeCmd --install-extension $($Vsix.FullName)" -ForegroundColor DarkYellow
    }
    # Pylance (bundled with ms-python.python) — the ApexScript extension defaults
    # to 'pylance' mode and needs it for completions in standalone VS Code.
    Write-Host ">>> Installing Pylance (ms-python.python) for completions..." -ForegroundColor Yellow
    $rc = if ($MarketplaceOk) { Invoke-Native $CodeCmd @("--install-extension", "ms-python.python", "--force") } else { 99 }
    if ($rc -eq 0) {
        Write-Host "    Done."
    } elseif ($rc -eq 99) {
        Write-Host "    Skipped: the VS Code Marketplace is unreachable from here. Install it later with:" -ForegroundColor DarkYellow
        Write-Host "    $CodeCmd --install-extension ms-python.python" -ForegroundColor DarkYellow
    } else {
        Write-Host "    Warning: Pylance install failed (exit $rc). Install it later with:" -ForegroundColor DarkYellow
        Write-Host "    $CodeCmd --install-extension ms-python.python" -ForegroundColor DarkYellow
    }
}

# --- Step 4: Configure MCP server ---
Write-Host ""

# Smoke-test the launcher before registering it, so a broken install (ABI
# mismatch, missing dep) fails LOUD here instead of showing up later as a silent
# "not connected" in Claude Code.
Write-Host ">>> Verifying the MCP server launches..." -ForegroundColor Yellow
$rc = Invoke-Native $env:ComSpec @("/c", $McpBin, "--selfcheck")
if ($rc -eq 0) {
    Write-Host "    Self-check passed."
} else {
    Write-Host "    WARNING: the MCP server failed to start (see diagnostic above)." -ForegroundColor DarkYellow
    Write-Host "    Re-run the check any time with:  $McpBin --selfcheck" -ForegroundColor DarkYellow
}
Write-Host ""

# Claude Code's VS Code extension ships the CLI too; someone who only uses
# Claude Code inside VS Code has nothing else on PATH (seen 2026-09-21). Newest first.
$ClaudeVsix = Get-ChildItem (Join-Path $env:USERPROFILE ".vscode\extensions\anthropic.claude-code-*\resources\native-binary\claude.exe") -ErrorAction SilentlyContinue |
    Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
$ClaudeCmd = Find-Cli @("claude") @(
    (Join-Path $env:USERPROFILE ".local\bin\claude.exe"),
    (Join-Path $env:APPDATA "npm\claude.cmd"),
    $ClaudeVsix)

if ($ClaudeCmd) {
    Write-Host ">>> Configuring MCP server for Claude Code (user scope)..." -ForegroundColor Yellow
    # `claude mcp add` refuses to overwrite an existing name, so drop any previous
    # registration first (a failure here just means there was none).
    $null = Invoke-Native $ClaudeCmd @("mcp", "remove", "--scope", "user", "apexscript")
    $rc = Invoke-Native $ClaudeCmd @("mcp", "add", "--transport", "stdio", "--scope", "user", "apexscript", "--", $PythonPath, $Launcher)
    if ($rc -eq 0) {
        Write-Host "    Done. MCP server registered as 'apexscript'."
        Write-Host "    Note: a project-scope 'apexscript' entry in a .mcp.json SHADOWS this" -ForegroundColor DarkYellow
        Write-Host "          user-scope registration - remove any manual one so this takes effect." -ForegroundColor DarkYellow
    } else {
        Write-Host "    Warning: Could not auto-configure (exit $rc). See manual setup below." -ForegroundColor DarkYellow
    }
} else {
    Write-Host "Note: Claude CLI not found. To configure the MCP server manually,"
    Write-Host "add to your project's .mcp.json:"
    Write-Host ""
    Write-Host "  {"
    Write-Host "    `"mcpServers`": {"
    Write-Host "      `"apexscript`": {"
    Write-Host "        `"command`": `"$($PythonPath -replace '\\', '/')`","
    Write-Host "        `"args`": [`"$($Launcher -replace '\\', '/')`"]"
    Write-Host "      }"
    Write-Host "    }"
    Write-Host "  }"
}

# --- Step 4b: Configure MCP server for Codex CLI ---
# Codex is configured only when it is actually present (the `codex` CLI on
# PATH, or an existing %USERPROFILE%\.codex dir from an app-managed install) —
# we never create a Codex config tree for non-Codex users. Primary path is
# `codex mcp add`; fallback is a marker-delimited block in .codex\config.toml
# written by the helper (safe around user-authored TOML).
$CodexDir = Join-Path $env:USERPROFILE ".codex"
$CodexCmd = Find-Cli @("codex") @(
    (Join-Path $env:USERPROFILE ".local\bin\codex.exe"),
    (Join-Path $env:APPDATA "npm\codex.cmd"))
$HasCodex = $CodexCmd -or (Test-Path $CodexDir)

if ($CodexCmd) {
    Write-Host ""
    Write-Host ">>> Configuring MCP server for Codex CLI..." -ForegroundColor Yellow
    $null = Invoke-Native $CodexCmd @("mcp", "remove", "apexscript")
    $rc = Invoke-Native $CodexCmd @("mcp", "add", "apexscript", "--", $PythonPath, $Launcher)
    if ($rc -eq 0) {
        Write-Host "    Done. MCP server registered as 'apexscript'."
    } else {
        Write-Host "    'codex mcp add' unavailable; writing $CodexDir\config.toml directly..." -ForegroundColor DarkYellow
        $null = Invoke-Python @($Helper, "codexmcp", "install", "--codex-dir", $CodexDir, "--command", $PythonPath, "--arg", $Launcher)
    }
} elseif (Test-Path $CodexDir) {
    Write-Host ""
    Write-Host ">>> Codex config found (no codex CLI on PATH) - configuring MCP server..." -ForegroundColor Yellow
    $null = Invoke-Python @($Helper, "codexmcp", "install", "--codex-dir", $CodexDir, "--command", $PythonPath, "--arg", $Launcher)
}

# --- Step 5: Install CLAUDE.md instructions ---
Write-Host ""
Write-Host ">>> Installing ApexScript instructions into $ClaudeDir\CLAUDE.md..." -ForegroundColor Yellow
$null = Invoke-Python @($Helper, "claudemd", "install", "--claude-dir", $ClaudeDir, "--block-file", (Join-Path $InstallDir "claude-md-block.md"))

# --- Step 5b: Install AGENTS.md instructions for Codex ---
# Codex has no PreToolUse hooks, so the block carries hard self-directed rules
# instead of a gate (see agents-md-block.md).
$AgentsBlock = Join-Path $InstallDir "agents-md-block.md"
if ($HasCodex -and (Test-Path $AgentsBlock)) {
    Write-Host ""
    Write-Host ">>> Installing ApexScript instructions into $CodexDir\AGENTS.md..." -ForegroundColor Yellow
    $null = Invoke-Python @($Helper, "codexmd", "install", "--codex-dir", $CodexDir, "--block-file", $AgentsBlock)
}

# --- Step 6: Install the .apex MCP-gate hook ---
# A PreToolUse hook that blocks Write/Edit on .apex files unless the apexscript
# MCP server was consulted in the current turn. This is the single biggest
# quality lever — it forces snippet/example lookups before code is written.
Write-Host ""
Write-Host ">>> Installing .apex MCP-gate hook..." -ForegroundColor Yellow
$HooksDir = Join-Path $ClaudeDir "hooks"
New-Item -ItemType Directory -Path $HooksDir -Force | Out-Null
$HookDst = Join-Path $HooksDir "apexscript_require_mcp.py"
Copy-Item (Join-Path $ScriptDir "hooks\apexscript_require_mcp.py") $HookDst -Force
# The hook is stdlib-only, so prefer the `py` launcher when present: it keeps
# working across Python upgrades, whereas an absolute python.exe path breaks
# every .apex edit the day Python312 becomes Python313.
# The pieces are passed separately and quoted by the helper: PowerShell 5.1
# strips quotes embedded in an argument, which silently turned a pre-quoted
# command into one that breaks on a profile path containing a space.
$PyLauncher = Get-Command py -ErrorAction SilentlyContinue
if ($PyLauncher) {
    $HookArgs = @("--interpreter", $PyLauncher.Source, "--interpreter-arg=-3", "--script", $HookDst)
} else {
    $HookArgs = @("--interpreter", $PythonPath, "--script", $HookDst)
}
$null = Invoke-Python (@($Helper, "hook", "install", "--claude-dir", $ClaudeDir) + $HookArgs)

# --- Step 6b: Install Claude skills ---
# Drops skill folders into ~/.claude/skills/ (Claude Code auto-discovers them).
# Currently: apexscript-save-snippets (session -> save_snippet curation).
$SkillsSrc = Join-Path $ScriptDir "skills"
if (Test-Path $SkillsSrc) {
    Write-Host ""
    Write-Host ">>> Installing Claude skills into $ClaudeDir\skills..." -ForegroundColor Yellow
    $SkillsDst = Join-Path $ClaudeDir "skills"
    New-Item -ItemType Directory -Path $SkillsDst -Force | Out-Null
    Copy-Item -Recurse -Force (Join-Path $SkillsSrc "*") $SkillsDst
    Write-Host "    Done."
}

# --- Step 6c: Install Codex custom prompts ---
# The Codex analog of skills: markdown prompts in .codex\prompts\ become
# /name commands in a Codex session.
$PromptsSrc = Join-Path $ScriptDir "prompts"
if ($HasCodex -and (Test-Path $PromptsSrc)) {
    Write-Host ""
    Write-Host ">>> Installing Codex prompts into $CodexDir\prompts..." -ForegroundColor Yellow
    $PromptsDst = Join-Path $CodexDir "prompts"
    New-Item -ItemType Directory -Path $PromptsDst -Force | Out-Null
    Copy-Item -Force (Join-Path $PromptsSrc "*.md") $PromptsDst
    Write-Host "    Done."
}

# --- Step 7: Install the Houdini Python panel ---
Write-Host ""
$PanelSrc = Join-Path $ScriptDir "houdini-panel"
if (Test-Path $PanelSrc) {
    Write-Host ">>> Installing Houdini panel..." -ForegroundColor Yellow
    $PanelRoot = Join-Path $InstallDir "houdini-panel"
    Copy-Item -Recurse $PanelSrc $InstallDir -Force
    $DocsDir = Join-Path $env:USERPROFILE "Documents"
    $null = Invoke-Python @(
        $Helper, "panel", "install",
        "--panel-path", (Join-Path $PanelRoot "apexscript-houdini-panel"),
        "--stubs-path", (Join-Path $PanelRoot "stubs"),
        "--reference-path", (Join-Path $PanelRoot "reference\apexscript-reference"),
        "--houdini-root", $env:USERPROFILE,
        "--houdini-root", $DocsDir
    )
} else {
    Write-Host "Note: Houdini panel not found in bundle, skipping." -ForegroundColor DarkYellow
}

# --- Step 8: Install uninstall script ---
# Shipped in the bundle (single source of truth); copied in so it can be run
# later as %USERPROFILE%\.apexscript\uninstall.ps1.
$UninstallPath = Join-Path $InstallDir "uninstall.ps1"
Copy-Item (Join-Path $ScriptDir "uninstall.ps1") $UninstallPath -Force
# The .cmd bootstrap too (execution-policy bypass), so uninstall works the same
# way install did; it becomes the documented uninstall entry point.
$UninstallCmd = Join-Path $InstallDir "uninstall.cmd"
if (Test-Path (Join-Path $ScriptDir "uninstall.cmd")) { Copy-Item (Join-Path $ScriptDir "uninstall.cmd") $UninstallCmd -Force; $UninstallPath = $UninstallCmd }

# --- Done ---
Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "  Installation complete!" -ForegroundColor Green
Write-Host "=========================================" -ForegroundColor Green
Write-Host ""
Write-Host "  Install location:  $InstallDir"
Write-Host "  MCP server:        $PythonPath $Launcher"
Write-Host "                     (shell wrapper: $McpBin)"
Write-Host "  Snippet library:   $SnippetsDir  (kept across reinstalls)"
if ($VsixInstalled) {
    Write-Host "  VS Code extension: installed"
}
Write-Host "  .apex MCP-gate:    $HookDst"
Write-Host "  Uninstall:         $UninstallPath"
Write-Host "  Diagnostics:       `"$PythonPath`" `"$Helper`" doctor   (paste its output in bug reports)"
Write-Host "  Install log:       $InstallLog"
Write-Host ""
Write-Host "Getting started:"
if ($CodeCmd) {
    Write-Host "  - Open VS Code, create a .apex file, type 'apex.geo.' for completions"
}
if ($ClaudeCmd) {
    Write-Host "  - Open Claude Code - ApexScript MCP tools are available in any project"
    Write-Host "  - Writing a .apex file now requires an apexscript MCP call first"
    Write-Host "    (bypass once with the token [skip-apex-hook] in your message)"
}
if ($HasCodex) {
    Write-Host "  - Open Codex - the 'apexscript' MCP server and AGENTS.md rules are configured"
    Write-Host "    (restart any running Codex session to pick up the new config)"
}
if (Test-Path (Join-Path $InstallDir "houdini-panel")) {
    Write-Host "  - Restart Houdini and open: Pane Tab Menu > ApexScript Editor"
}
Write-Host ""
Write-Host "See README.md for more details."
try { Stop-Transcript | Out-Null } catch { }
