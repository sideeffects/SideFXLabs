"""PreToolUse hook: refuse Write/Edit on .apex files when no apexscript MCP
tool was called in the current turn.

Boundary of "current turn": from the most recent real user message (not a
tool_result, not an ide_selection-only synthetic message) to now.

Hook protocol (Claude Code):
- stdin: JSON with {session_id, transcript_path, cwd, hook_event_name,
  tool_name, tool_input}
- stdout JSON with hookSpecificOutput.permissionDecision="deny" blocks the call.
- exit 0 in all paths so a hook bug never silently breaks editing.

Escape hatch: if the most recent user message contains the literal token
[skip-apex-hook], allow the write through.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path


WATCHED_TOOLS = {"Write", "Edit", "MultiEdit", "NotebookEdit"}
MCP_PREFIX = "mcp__apexscript__"
ESCAPE_TOKEN = "[skip-apex-hook]"

DENY_MESSAGE = (
    "BLOCKED: writing a .apex file without consulting the apexscript MCP server this turn.\n"
    "\n"
    "Call one of these FIRST, then paste/adapt what it returns:\n"
    "  - mcp__apexscript__get_snippet         — curated snippet patterns (ALWAYS try first)\n"
    "  - mcp__apexscript__search_examples     — 290+ example library\n"
    "  - mcp__apexscript__read_example        — read a specific example\n"
    "  - mcp__apexscript__get_callback_signature\n"
    "  - mcp__apexscript__generate_apexscript — general guidance + snippets\n"
    "\n"
    "Use the returned code verbatim where possible; do not synthesize callback names "
    "or signatures from memory. Bypass for this single edit by including the literal "
    "token [skip-apex-hook] in your next message."
)


def _safe_load_json(line: str) -> dict | None:
    try:
        return json.loads(line)
    except Exception:
        return None


def _is_real_user_message(rec: dict) -> bool:
    """A 'real' user message is one with at least one text block whose text is
    not purely a tool_result envelope. Tool results come back to us as
    type='user' records but their content is a list of tool_result blocks
    only — those don't count as turn boundaries.
    """
    if rec.get("type") != "user":
        return False
    msg = rec.get("message") or {}
    content = msg.get("content")
    if isinstance(content, str):
        return True
    if isinstance(content, list):
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                return True
    return False


def _user_message_text(rec: dict) -> str:
    msg = rec.get("message") or {}
    content = msg.get("content")
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return " ".join(
            block.get("text", "")
            for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        )
    return ""


def _assistant_mcp_calls(rec: dict) -> list[str]:
    if rec.get("type") != "assistant":
        return []
    msg = rec.get("message") or {}
    content = msg.get("content")
    if not isinstance(content, list):
        return []
    return [
        str(block.get("name", ""))
        for block in content
        if isinstance(block, dict)
        and block.get("type") == "tool_use"
        and str(block.get("name", "")).startswith(MCP_PREFIX)
    ]


def main() -> None:
    raw = sys.stdin.read()
    payload = _safe_load_json(raw) or {}

    tool_name = payload.get("tool_name", "")
    if tool_name not in WATCHED_TOOLS:
        sys.exit(0)

    tool_input = payload.get("tool_input") or {}
    file_path = (
        tool_input.get("file_path")
        or tool_input.get("notebook_path")
        or ""
    )
    if not isinstance(file_path, str) or not file_path.lower().endswith(".apex"):
        sys.exit(0)

    transcript_path = payload.get("transcript_path")
    if not transcript_path or not Path(transcript_path).exists():
        # No way to verify — fail open.
        sys.exit(0)

    # Walk the transcript bottom-up. Stop at the most recent REAL user message;
    # anything seen before that point is "this turn".
    try:
        with open(transcript_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    except Exception:
        sys.exit(0)

    mcp_seen = False
    user_text = ""
    for line in reversed(lines):
        line = line.strip()
        if not line:
            continue
        rec = _safe_load_json(line)
        if not rec:
            continue

        if _is_real_user_message(rec):
            user_text = _user_message_text(rec)
            break

        if _assistant_mcp_calls(rec):
            mcp_seen = True
            # keep walking back to also find the user message (for escape token)

    if ESCAPE_TOKEN in user_text:
        sys.exit(0)

    if mcp_seen:
        sys.exit(0)

    output = {
        "hookSpecificOutput": {
            "hookEventName": "PreToolUse",
            "permissionDecision": "deny",
            "permissionDecisionReason": DENY_MESSAGE,
        }
    }
    sys.stdout.write(json.dumps(output))
    sys.exit(0)


if __name__ == "__main__":
    main()
