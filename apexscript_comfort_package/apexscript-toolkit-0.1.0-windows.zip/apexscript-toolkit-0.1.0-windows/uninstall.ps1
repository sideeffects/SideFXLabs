# ApexScript Toolkit uninstaller (Windows PowerShell).
#
# Reverses everything install.ps1 does: the MCP registration, the VS Code
# extension, the .apex MCP-gate hook (+ its settings.json entry), the injected
# CLAUDE.md section, the Houdini panel package files, and the .apexscript dir.
#
# Runnable two ways:
#   - from the install:  & "$env:USERPROFILE\.apexscript\uninstall.ps1"
#   - straight from the bundle:  .\uninstall.ps1   (uses the bundled helper)
param(
    [switch]$Purge   # also delete snippets/ and workflows/ instead of moving them aside
)
$ErrorActionPreference = "Continue"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallDir = "$env:USERPROFILE\.apexscript"
$ClaudeDir = "$env:USERPROFILE\.claude"

# Prefer the installed helper; fall back to one next to this script (bundle).
$Helper = Join-Path $InstallDir "apex_toolkit_config.py"
if (-not (Test-Path $Helper)) { $Helper = Join-Path $ScriptDir "apex_toolkit_config.py" }

Write-Host "=== Uninstalling ApexScript Toolkit ==="

# Same lookup as the installer: PATH, the CLI's own install locations, then the
# binary bundled with Claude Code's VS Code extension (newest first).
$ClaudeCmd = $null
if (Get-Command "claude" -ErrorAction SilentlyContinue) { $ClaudeCmd = "claude" }
else {
    $ClaudeVsix = Get-ChildItem (Join-Path $env:USERPROFILE ".vscode\extensions\anthropic.claude-code-*\resources\native-binary\claude.exe") -ErrorAction SilentlyContinue |
        Sort-Object FullName -Descending | Select-Object -First 1 -ExpandProperty FullName
    foreach ($c in @((Join-Path $env:USERPROFILE ".local\bin\claude.exe"), (Join-Path $env:APPDATA "npm\claude.cmd"), $ClaudeVsix)) {
        if ($c -and (Test-Path $c)) { $ClaudeCmd = $c; break }
    }
}
if ($ClaudeCmd) {
    Write-Host ">>> Removing MCP server registration..."
    & $ClaudeCmd mcp remove apexscript --scope user 2>$null
}

$CodexDir = Join-Path $env:USERPROFILE ".codex"
if (Get-Command "codex" -ErrorAction SilentlyContinue) {
    Write-Host ">>> Removing Codex MCP server registration..."
    codex mcp remove apexscript 2>$null
}

$CodeCmd = $null
if (Get-Command "code" -ErrorAction SilentlyContinue) { $CodeCmd = "code" }
elseif (Get-Command "code-insiders" -ErrorAction SilentlyContinue) { $CodeCmd = "code-insiders" }
if ($CodeCmd) {
    Write-Host ">>> Removing VS Code extension..."
    & $CodeCmd --uninstall-extension apexscript.apexscript-lsp 2>$null
}

# Undo the structured changes (settings.json / CLAUDE.md / panel json).
# Resolve a WORKING interpreter (reject the Store stubs by requiring real stdout;
# fall back to uv) so this cleanup runs on uv-only machines too.
$PyExe = $null
foreach ($c in @(@{exe='py';pre=@('-3')}, @{exe='python3';pre=@()}, @{exe='python';pre=@()})) {
    try {
        $v = & $c.exe @($c.pre) -c "import sys; print(sys.executable)" 2>$null
        if ($v) { $PyExe = ($v | Select-Object -First 1); break }
    } catch { }
}
if (-not $PyExe -and (Get-Command uv -ErrorAction SilentlyContinue)) {
    try {
        $u = (& uv python find '>=3.11' 2>$null | Select-Object -First 1)
        if ($u -and (Test-Path $u)) { $PyExe = $u }
    } catch { }
}
if ($PyExe -and (Test-Path $Helper)) {
    $docs = Join-Path $env:USERPROFILE "Documents"
    Write-Host ">>> Removing .apex hook, CLAUDE.md/AGENTS.md sections, and Houdini panel..."
    & $PyExe $Helper hook uninstall --claude-dir $ClaudeDir
    & $PyExe $Helper claudemd uninstall --claude-dir $ClaudeDir
    # Codex cleanup: the AGENTS.md block, plus any marker-delimited config.toml
    # entry the fallback path wrote (a `codex mcp add` entry is removed above;
    # this is a no-op when neither exists).
    & $PyExe $Helper codexmd uninstall --codex-dir $CodexDir
    & $PyExe $Helper codexmcp uninstall --codex-dir $CodexDir
    & $PyExe $Helper panel uninstall --houdini-root $env:USERPROFILE --houdini-root $docs
} else {
    Write-Host "Note: python/helper not found; skipping settings.json / CLAUDE.md / AGENTS.md / panel cleanup."
}
Remove-Item -Force (Join-Path $ClaudeDir "hooks\apexscript_require_mcp.py") -ErrorAction SilentlyContinue
Remove-Item -Recurse -Force (Join-Path $ClaudeDir "skills\apexscript-save-snippets") -ErrorAction SilentlyContinue
Remove-Item -Force (Join-Path $CodexDir "prompts\apexscript-save-snippets.md") -ErrorAction SilentlyContinue

if (Test-Path $InstallDir) {
    # User data (snippets/, workflows/) is moved next to the install dir unless
    # -Purge is given; the helper prints where.
    if ($PyExe -and (Test-Path $Helper)) {
        $bargs = @($Helper, "installdir", "backup-user-data", "--install-dir", $InstallDir)
        if ($Purge) { $bargs += "--purge" }
        & $PyExe @bargs
    }
    Write-Host ">>> Removing $InstallDir..."
    Remove-Item -Recurse -Force $InstallDir
}
Write-Host "=== Uninstall complete ===" -ForegroundColor Green

# Best-effort steps above may leave a non-zero $LASTEXITCODE (e.g. the VS Code
# extension was already gone); the uninstall itself completed, so say so.
exit 0
