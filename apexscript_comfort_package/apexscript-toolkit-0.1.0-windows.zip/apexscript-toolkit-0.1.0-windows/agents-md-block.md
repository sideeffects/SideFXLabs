# ApexScript (.apex files)

IMPORTANT: When working with .apex files or answering ApexScript questions, ALWAYS use the tools from the `apexscript` MCP server FIRST. Do not fall back to raw file reads on reference data.

Unlike Claude Code, this environment has no enforcement hook, so treat these as hard rules. Codex has no hook system, so the installer never installs the `.apex` MCP-gate hook here and the `[skip-apex-hook]` bypass token has no effect in this environment.
- NEVER write or edit a `.apex` file before calling the `get_snippet` or `search_examples` tool for the pattern you are about to write.
- Do NOT synthesize callback names or signatures from memory — look them up with `get_callback_signature` and use what it returns verbatim.
- Run `validate_apexscript` on any `.apex` code you wrote before finishing.

**Start here:**
- `get_snippet` — ALWAYS check first: curated copy-paste patterns (controls, IK, loops, constraints, graphs, etc.)
- `get_workflow_guide` — step-by-step guides for multi-step tasks (rigging, geometry, graph-building)

**Then use as needed:**
- `search_examples` / `read_example` — find and read reference code from the example library
- `get_apexscript_help` — syntax, language features, and general help
- `get_callback_signature` — look up API signatures and parameters
- `search_callbacks_by_namespace` — find callbacks in a specific namespace
- `get_namespace_help` — comprehensive help for a namespace (geo, skel, transform, etc.)
- `get_domain_overview` — overview of related namespaces (geometry, rigging, simulation, etc.)
- `get_oo_methods` — object-oriented method signatures by type
- `validate_apexscript` — check code for syntax and semantic errors
- `generate_apexscript` — generate ApexScript code from a description
- `save_snippet` — save new snippets to the library
