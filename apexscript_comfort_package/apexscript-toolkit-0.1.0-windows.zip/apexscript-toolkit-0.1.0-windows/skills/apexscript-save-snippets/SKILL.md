---
name: apexscript-save-snippets
description: >-
  Analyze the current session/conversation for reusable ApexScript (Houdini
  APEX) code patterns and save them to the personal snippet library via the
  apexscript MCP server's save_snippet tool. Use when the user asks to extract,
  curate, "save", or "remember" useful ApexScript snippets/patterns from work
  done this session so they're reusable later via get_snippet. Requires the
  apexscript MCP server.
---

# Save ApexScript snippets from this session

Turn reusable ApexScript patterns produced during a session into curated,
searchable snippets in the user's personal library (`~/.apexscript/snippets/`),
immediately available via `get_snippet`.

## Prerequisite

The **apexscript MCP server** must be configured — you need the tools
`save_snippet`, `get_snippet`, `search_examples`, and `validate_apexscript`.
If `save_snippet` is not available, tell the user to install/configure the
ApexScript Toolkit MCP server and stop (do not hand-write JSON files).

## Guiding principle: quality over quantity

Only save focused, genuinely reusable patterns. A session may yield **zero**
snippets — that is a fine outcome. Never bulk-save everything that was written.

## Workflow

### 1. Identify candidates
Scan the session for self-contained ApexScript patterns reusable beyond this one
task: 5–20 meaningful lines, one clear idea (a setup, an idiom, a
gotcha-avoiding pattern).

**Skip these (anti-patterns):**
- Depends on 5+ parameters with no clear defaults.
- References helper functions or state defined elsewhere in the session.
- More than ~20 lines after cleanup.
- One-off, project-specific, or too domain-specific to reuse.
- A near-duplicate of something that already exists (see step 2).

### 2. Check for duplicates FIRST
Before saving each candidate, query existing coverage so you don't duplicate a
built-in or a prior user snippet:
- `get_snippet(query="<concept / tags>")` and/or `search_examples(...)`.
- If a close match exists, skip it — or, if the user prefers, improve the
  existing snippet instead of adding a near-duplicate.

### 3. Make it standalone
Rewrite each candidate so it compiles on its own:
- Begin with `from apexscript import *` and **only** the setup vars it actually
  uses, e.g.:
  ```
  from apexscript import *

  graph: ApexGraphHandle = ApexGraphHandle()
  geo: Geometry = BindInput()
  ```
- Use **OO-style** syntax: `graph.addNode(...)`, `skel.findJoint(...)`,
  `port.data()` — not `apex.graph.AddNode(graph=...)`.
- Remove compiler artifacts: `__name`, `__color`, `__pos`, `__properties`,
  `_portalias()`, `ScopeEnd`.
- Use descriptive variable names and a short inline comment per step.
- Keep it to 5–20 lines of meaningful code (plus the import + setup).

### 4. Validate (recommended)
Run `validate_apexscript(code=...)` on the cleaned code and fix any errors
before saving.

### 5. Save
Call `save_snippet` with:
- **name** — kebab-case, 2–4 words, optional category prefix
  (e.g. `port-data-read`, `mirror-tags`, `find-or-create-joint`).
- **description** — one line: what the snippet demonstrates.
- **tags** — 5–10: primary callback names + type names + conceptual terms +
  category, e.g. `["promotion","port","data","TransformObject","Dict","graph","findNodes"]`.
- **code** — the standalone code from step 3.
- **notes** (optional) — return-value formats, gotchas, alternatives.
- **related** (optional) — names of snippets that pair well.
- **target** — `"user"` (default → `~/.apexscript/snippets/`). Use `"external"`
  only if the user has set `APEXSCRIPT_SNIPPETS_PATH` for a shared team library.

### 6. Confirm + report
- **Curate with the user**: list the candidates you propose (name + one-line
  description) and let them approve or trim the set before you save. Do not save
  silently.
- After saving, report each snippet's name and path, and note it is now
  available via `get_snippet(name=...)`.

## Notes
- Saved snippets are single self-contained JSON files
  (`name`/`description`/`tags`/`code`[/`notes`/`related`]) — the `save_snippet`
  tool writes and formats them. You never hand-write JSON or manage paired
  `.apex` files (that pipeline is for the built-in library only).
- A saved snippet is live immediately: the loader reads `~/.apexscript/snippets/`
  and `save_snippet` invalidates the snippet cache, so `get_snippet` finds it
  without a server restart.
