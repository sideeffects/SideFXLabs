"""ApexScript curveutils:: namespace stubs."""

from typing import Any, Tuple, overload
from .._types import *  # noqa: F403
__all__ = ['frameFromKeys']


def frameFromKeys(geo: Geometry = ..., targetmultiparmpts: Geometry = ..., tangenttype: Int = 0, alignwithcurvetangent: Bool = ..., enablexaxis: Bool = False, enableyaxis: Bool = False, enablezaxis: Bool = False, enableorient: Bool = True, xaxisname: String = "out", yaxisname: String = "up", zaxisname: String = "tangent", orientname: String = "orient") -> Geometry: ...
