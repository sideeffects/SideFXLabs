"""ApexScript componentgadget:: namespace stubs."""

from typing import Any, Tuple, overload
from .._types import *  # noqa: F403
__all__ = ['referenceSkeleton']


def referenceSkeleton(skeleton: Geometry = ..., group: String = ..., xform: Matrix4 = ..., color: Vector3 = ..., highlight_color: Vector3 = ..., highlight_group: String = ..., prehighlight_color: Vector3 = ..., prehighlight_group: String = ..., new_root_name: String = ..., new_root_xform: Matrix4 = ..., new_root_color: Vector3 = ..., new_root_group: String = ..., delete_color: Vector3 = ..., delete_group: String = ..., delete: Int = ..., transforms: Dict = ...) -> Geometry: ...
