"""ApexScript guidecomponentutils:: namespace stubs."""

from typing import Any, Tuple, overload
from .._types import *  # noqa: F403
__all__ = ['add2BoneIKCore', 'addComponentSkeletonCore']


def add2BoneIKCore(guides: Geometry = ..., graph: ApexGraphHandle = ..., parent: String = ..., name: String = ..., color: Vector3 = Vector3(0.8, 0.8, 0.8), size: Float = 1.8, joint_names: StringArray = ...) -> Tuple[Geometry, ApexGraphHandle]: ...
def addComponentSkeletonCore(guides: Geometry = ..., graph: ApexGraphHandle = ..., guidesource: String = ..., has_template: Bool = ..., ignore_root: Bool = ..., reference_skel: Geometry = ..., name: String = ..., mapping: DictArray = ..., mirror: Bool = ..., left: String = ..., right: String = ..., planenormal: Vector3 = ..., planeorigin: Vector3 = ..., xform: Matrix4 = ..., parent: String = ..., prefix: String = "", suffix: String = "", color: Vector3 = Vector3(1.0, 0.0, 0.0), removegroup: String = "", size: Float = 1.8, jnt_size: Float = 0.02) -> Tuple[Geometry, ApexGraphHandle, StringArray, ApexNodeIDArray]: ...
