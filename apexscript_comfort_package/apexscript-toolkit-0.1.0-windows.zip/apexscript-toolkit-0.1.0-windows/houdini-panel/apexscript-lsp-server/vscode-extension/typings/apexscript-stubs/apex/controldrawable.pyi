"""ApexScript controldrawable:: namespace stubs."""

from typing import Any, Tuple, overload
from .._types import *  # noqa: F403
__all__ = ['skinControl', 'updateVisibility']


def skinControl(skin_geo: Geometry = ..., control_geo: Geometry = ...) -> Tuple[Geometry, Geometry]: ...
def updateVisibility(value: Int = ..., visibility: Bool = ...) -> Int: ...
