#!/usr/bin/env python3
"""Companion diagnostics for ApexScript VS Code extension (pylance mode).

Reads ApexScript source from stdin, detects unsupported Python features
and type system violations, and outputs JSON diagnostics to stdout.

This script is self-contained (stdlib only) so it works without the
apexscript-lsp-server package installed. The detection logic mirrors
UnsupportedFeatureDetector from the LSP server.

Usage:
    echo "while True: pass" | python3 diagnostics-companion.py
    echo "a = Int(); a = Float()" | python3 diagnostics-companion.py --reference-path /path/to/ref
    # Output: [{"line":0,"column":0,"end_line":0,"end_column":16,"message":"...","severity":"error"}]
"""

import ast
import json
import os
import re
import sys
from dataclasses import asdict, dataclass
from typing import Dict, List, Optional, Type


@dataclass
class UnsupportedFeature:
    """An unsupported Python feature found in ApexScript source.

    Line numbers are 0-indexed (matching VS Code Diagnostic ranges).
    """
    line: int
    column: int
    end_line: int
    end_column: int
    message: str
    severity: str


# Mapping of Python AST node types to ApexScript error messages.
# Mirrors apexscript_lsp_server.parser.visitors.unsupported_visitor.
UNSUPPORTED_NODES: Dict[Type[ast.AST], str] = {
    ast.ClassDef: "Class definitions are not supported. Use functions instead.",
    ast.While: "'while' loops are not supported. Use 'for' with range() instead.",
    ast.Try: "Exception handling (try/except) is not supported.",
    ast.With: "'with' statements are not supported.",
    ast.AsyncFunctionDef: "Async functions are not supported.",
    ast.Await: "'await' is not supported.",
    ast.Yield: "'yield' is not supported. Use 'return' instead.",
    ast.YieldFrom: "'yield from' is not supported.",
    ast.Global: "'global' is not supported.",
    ast.Nonlocal: "'nonlocal' is not supported.",
    ast.Lambda: "Lambda functions are not supported. Use def instead.",
    ast.ListComp: "List comprehensions are not supported. Use explicit for loops.",
    ast.SetComp: "Set comprehensions are not supported.",
    ast.DictComp: "Dict comprehensions are not supported.",
    ast.GeneratorExp: "Generator expressions are not supported.",
    ast.Set: "Set literals {a, b} are not supported. Use arrays [a, b] instead.",
    ast.NamedExpr: "Walrus operator ':=' is not supported. Use 'var: Type = value'.",
}

# ApexScript types recognized as constructors for type inference.
APEX_TYPES = frozenset({
    'Int', 'Float', 'Bool', 'String',
    'Vector2', 'Vector3', 'Vector4', 'Matrix3', 'Matrix4',
    'Geometry', 'Dict', 'Quaternion',
    'ApexGraphHandle', 'ApexNodeID', 'ApexPortID',
    'IntArray', 'FloatArray', 'StringArray',
    'Vector2Array', 'Vector3Array', 'Vector4Array',
    'Matrix3Array', 'Matrix4Array',
    'ApexNodeIDArray', 'ApexPortIDArray',
    'AnimChannel', 'AnimChannelArray',
})

# Python literal type -> ApexScript type name.
# bool must be checked before int (bool is a subclass of int in Python).
LITERAL_TYPE_MAP: Dict[type, str] = {
    bool: 'Bool',
    int: 'Int',
    float: 'Float',
    str: 'String',
}


class UnsupportedFeatureDetector(ast.NodeVisitor):
    """Detect Python features not supported in ApexScript."""

    def __init__(self) -> None:
        self.issues: List[UnsupportedFeature] = []

    def generic_visit(self, node: ast.AST) -> None:
        node_type = type(node)
        if node_type in UNSUPPORTED_NODES:
            self.issues.append(UnsupportedFeature(
                line=getattr(node, 'lineno', 1) - 1,
                column=getattr(node, 'col_offset', 0),
                end_line=getattr(node, 'end_lineno', getattr(node, 'lineno', 1)) - 1,
                end_column=getattr(node, 'end_col_offset', 0),
                message=UNSUPPORTED_NODES[node_type],
                severity='error',
            ))
        super().generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        """Detect unannotated variables assigned from dict subscriptions.

        In ApexScript, `myvar = mydict['key']` is a compile error because the
        compiler cannot infer the type from a Dict subscription. The correct
        form is `myvar: Type = mydict['key']` (an AnnAssign in the AST).
        """
        if (isinstance(node.value, ast.Subscript)
                and isinstance(node.value.slice, ast.Constant)
                and isinstance(node.value.slice.value, str)):
            target = node.targets[0] if node.targets else None
            target_name = getattr(target, 'id', '?')
            self.issues.append(UnsupportedFeature(
                line=node.lineno - 1,
                column=node.col_offset,
                end_line=getattr(node, 'end_lineno', node.lineno) - 1,
                end_column=getattr(node, 'end_col_offset', 0),
                message=(
                    f"Missing type annotation on dict subscription. "
                    f"Use `{target_name}: Type = ...` instead. "
                    f"ApexScript requires explicit type annotations for dict access."
                ),
                severity='error',
            ))
        self.generic_visit(node)


class TypeReassignmentDetector(ast.NodeVisitor):
    """Detect type reassignment errors in ApexScript's strict type system.

    ApexScript does not allow changing a variable's type after its initial
    assignment. This detector tracks variable types from annotations,
    constructors, and literals, then flags reassignments with different types.
    """

    def __init__(self, callback_returns: Optional[Dict[str, str]] = None) -> None:
        self.issues: List[UnsupportedFeature] = []
        self._scopes: List[Dict[str, str]] = [{}]  # module scope
        self._callback_returns = callback_returns or {}

    def _resolve_type(self, node: ast.AST) -> Optional[str]:
        """Resolve the ApexScript type of an expression, or None if unknown."""
        # Constructor call: Int(), Vector3(), Geometry(), etc.
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in APEX_TYPES:
                return node.func.id
            # apex.ns.func() -> callback return type
            if isinstance(node.func, ast.Attribute) and self._callback_returns:
                cb = self._resolve_callback_name(node.func)
                if cb and cb in self._callback_returns:
                    return self._callback_returns[cb]
            return None

        # Literal values
        if isinstance(node, ast.Constant):
            # bool before int (bool is subclass of int in Python)
            if isinstance(node.value, bool):
                return 'Bool'
            return LITERAL_TYPE_MAP.get(type(node.value))

        # Variable reference -> look up tracked type
        if isinstance(node, ast.Name):
            for scope in reversed(self._scopes):
                if node.id in scope:
                    return scope[node.id]

        return None

    def _resolve_type_full(self, node: ast.AST) -> Optional[str]:
        """Resolve the full return type string including tuple types."""
        if isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in APEX_TYPES:
                return node.func.id
            if isinstance(node.func, ast.Attribute) and self._callback_returns:
                cb = self._resolve_callback_name(node.func)
                if cb and cb in self._callback_returns:
                    return self._callback_returns[cb]
        return None

    @staticmethod
    def _parse_tuple_types(type_str: str) -> Optional[List[str]]:
        """Parse 'tuple[T1, T2, ...]' or 'Tuple[T1, T2, ...]' into element types."""
        m = re.match(r'[Tt]uple\[(.+)\]$', type_str)
        if not m:
            return None
        # Split on top-level commas (not inside nested brackets)
        inner = m.group(1)
        types = []
        depth = 0
        current = ''
        for ch in inner:
            if ch == '[':
                depth += 1
                current += ch
            elif ch == ']':
                depth -= 1
                current += ch
            elif ch == ',' and depth == 0:
                types.append(current.strip())
                current = ''
            else:
                current += ch
        if current.strip():
            types.append(current.strip())
        return types if types else None

    def _resolve_callback_name(self, attr: ast.Attribute) -> Optional[str]:
        """Resolve apex.ns.func to 'ns::Func' callback cache key."""
        if not (isinstance(attr, ast.Attribute)
                and isinstance(attr.value, ast.Attribute)
                and isinstance(attr.value.value, ast.Name)
                and attr.value.value.id == 'apex'):
            return None

        ns = attr.value.attr
        func = attr.attr
        pascal = func[0].upper() + func[1:] if func else func

        # Try ns::PascalCase first (most common in cache)
        key = f'{ns}::{pascal}'
        if key in self._callback_returns:
            return key

        # Try original case
        key2 = f'{ns}::{func}'
        if key2 in self._callback_returns:
            return key2

        # Case-insensitive fallback
        target = key.lower()
        for k in self._callback_returns:
            if k.lower() == target:
                return k

        return None

    # Types that are placeholders and should not participate in type checking.
    _SKIP_TYPES = frozenset({'undefined'})

    def _record_or_check(self, name: str, new_type: Optional[str],
                         annotation: Optional[str], node: ast.AST) -> None:
        """Record a variable's type, or flag a mismatch if already known."""
        resolved = annotation or new_type
        if not resolved or resolved in self._SKIP_TYPES:
            return

        scope = self._scopes[-1]
        if name in scope:
            old = scope[name]
            if old != resolved:
                self.issues.append(UnsupportedFeature(
                    line=node.lineno - 1,
                    column=node.col_offset,
                    end_line=getattr(node, 'end_lineno', node.lineno) - 1,
                    end_column=getattr(node, 'end_col_offset', 0),
                    message=(
                        f"Type mismatch: `{name}` was `{old}`, "
                        f"cannot reassign as `{resolved}`. "
                        f"ApexScript does not allow type changes."
                    ),
                    severity='error',
                ))
        else:
            scope[name] = resolved

    def visit_AnnAssign(self, node: ast.AnnAssign) -> None:
        """Track annotated assignments: var: Type = value."""
        if isinstance(node.target, ast.Name) and isinstance(node.annotation, ast.Name):
            self._record_or_check(
                node.target.id, None, node.annotation.id, node
            )
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        """Track simple and tuple-unpacking assignments, check for type mismatches."""
        if len(node.targets) == 1:
            target = node.targets[0]
            if isinstance(target, ast.Name):
                # Simple: a = expr
                new_type = self._resolve_type(node.value)
                self._record_or_check(target.id, new_type, None, node)
            elif isinstance(target, ast.Tuple):
                # Tuple unpacking: a, b = expr
                # Resolve the full return type and parse tuple elements
                full_type = self._resolve_type_full(node.value)
                if full_type:
                    elem_types = self._parse_tuple_types(full_type)
                    if elem_types and len(elem_types) == len(target.elts):
                        for elt, etype in zip(target.elts, elem_types):
                            if isinstance(elt, ast.Name) and elt.id != '_':
                                self._record_or_check(elt.id, etype, None, node)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        """Enter a new scope for function body."""
        self._scopes.append({})
        # Record parameter types from annotations
        for arg in node.args.args:
            if arg.annotation and isinstance(arg.annotation, ast.Name):
                self._scopes[-1][arg.arg] = arg.annotation.id
        self.generic_visit(node)
        self._scopes.pop()


def _load_callback_returns(reference_path: str) -> Dict[str, str]:
    """Load return types from callbacks_cache.json and subgraphs_cache.json.

    Returns a {callback_name: return_type} mapping for type inference
    of apex.ns.func() calls. Includes both callbacks and subgraphs.
    """
    returns: Dict[str, str] = {}
    api_cache = os.path.join(reference_path, 'metadata', 'api-cache')

    for filename in ('callbacks_cache.json', 'subgraphs_cache.json'):
        cache_path = os.path.join(api_cache, filename)
        try:
            with open(cache_path) as f:
                data = json.load(f)
            for name, entry in data.items():
                rt = entry.get('return_type', '')
                if rt and rt != 'None':
                    returns[name] = rt
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            pass

    return returns


def detect(source: str, callback_returns: Optional[Dict[str, str]] = None) -> List[dict]:
    """Detect unsupported features and type errors in ApexScript source.

    Returns:
        List of diagnostic dicts ready for JSON serialization.
    """
    if not source.strip():
        return []

    try:
        tree = ast.parse(source)
    except SyntaxError:
        # Can't parse as Python — Pylance handles syntax errors
        return []

    # Unsupported Python features
    detector = UnsupportedFeatureDetector()
    detector.visit(tree)

    # Type reassignment errors
    type_detector = TypeReassignmentDetector(callback_returns=callback_returns)
    type_detector.visit(tree)

    return [asdict(issue) for issue in detector.issues + type_detector.issues]


def main() -> None:
    # Parse optional --reference-path argument for callback return type lookup
    reference_path = None
    args = sys.argv[1:]
    for i, arg in enumerate(args):
        if arg == '--reference-path' and i + 1 < len(args):
            reference_path = args[i + 1]

    callback_returns = {}
    if reference_path:
        callback_returns = _load_callback_returns(reference_path)

    source = sys.stdin.read()
    results = detect(source, callback_returns=callback_returns)
    json.dump(results, sys.stdout)


if __name__ == '__main__':
    main()
