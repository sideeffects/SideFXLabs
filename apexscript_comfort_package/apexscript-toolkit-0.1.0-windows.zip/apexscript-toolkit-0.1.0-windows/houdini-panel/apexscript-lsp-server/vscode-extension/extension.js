// ApexScript Language Support extension for VS Code
//
// Supports two modes:
// - "pylance": Companion mode - .apex files use Python language ID so Pylance
//   provides type checking. Extension adds ApexScript-specific snippets and
//   unsupported-feature diagnostics alongside Pylance.
// - "standalone": Custom LSP mode - .apex files use apexscript language ID
//   with the built-in language server (for non-VS-Code editors or without Pylance).
//
// On Windows, the standalone LSP server runs via WSL since Cygwin Python lacks
// required libraries for pygls/lsprotocol.

const vscode = require('vscode');
const path = require('path');

// Guard for serve-web (browser) compatibility — Node.js built-ins may not exist
const isNode = typeof process !== 'undefined' && process.versions != null && process.versions.node != null;
const cp = isNode ? require('child_process') : null;
const fs = isNode ? require('fs') : null;
let LanguageClient, TransportKind;
if (isNode) {
    ({ LanguageClient, TransportKind } = require('vscode-languageclient/node'));
}

let client;
let diagnosticCollection;
let diagnosticTimer;
let callbackDataCache = null;

function activate(context) {
    const config = vscode.workspace.getConfiguration('apexscript');
    const mode = config.get('mode', 'pylance');

    if (mode === 'pylance') {
        activatePylanceMode(context);
    } else {
        activateStandaloneMode(context);
    }

    // Prompt reload when mode changes
    context.subscriptions.push(
        vscode.workspace.onDidChangeConfiguration(e => {
            if (e.affectsConfiguration('apexscript.mode')) {
                vscode.window.showInformationMessage(
                    'ApexScript mode changed. Reload window to apply.',
                    'Reload'
                ).then(selection => {
                    if (selection === 'Reload') {
                        vscode.commands.executeCommand('workbench.action.reloadWindow');
                    }
                });
            }
        })
    );
}

// ---------------------------------------------------------------------------
// Pylance Companion Mode
// ---------------------------------------------------------------------------

function activatePylanceMode(context) {
    // 1. Switch .apex files to Python language so Pylance handles them
    setApexAsPython(context);

    // 2. Configure Pylance stub path for ApexScript type stubs
    configureStubPath(context);

    // 2b. Ensure `from apexscript import *` is present in every .apex file
    registerApexImportInjection(context);

    // 3. Register snippet completion provider for .apex-as-Python files
    const snippetProvider = new ApexSnippetProvider(context.extensionPath);
    context.subscriptions.push(
        vscode.languages.registerCompletionItemProvider(
            { language: 'python', pattern: '**/*.apex' },
            snippetProvider,
            '@'  // trigger character for decorator snippets (@ns, @sg)
        )
    );

    // 4. Register bind completion provider for bindInput pattern snippets
    const bindProvider = new BindCompletionProvider();
    context.subscriptions.push(
        vscode.languages.registerCompletionItemProvider(
            { language: 'python', pattern: '**/*.apex' },
            bindProvider,
        )
    );

    // 5. Register port completion provider for callback-aware port suggestions
    const config = vscode.workspace.getConfiguration('apexscript');
    const referencePath = resolveReferencePath(config, context);
    if (config.get('portCompletion.enabled', true)) {
        if (referencePath) {
            const portProvider = new PortCompletionProvider(referencePath);
            context.subscriptions.push(
                vscode.languages.registerCompletionItemProvider(
                    { language: 'python', pattern: '**/*.apex' },
                    portProvider,
                    '.'  // trigger on dot for port attribute access
                )
            );

            // 6. Register kwarg + fill-all-args completion provider
            const kwargProvider = new KwargCompletionProvider(referencePath);
            context.subscriptions.push(
                vscode.languages.registerCompletionItemProvider(
                    { language: 'python', pattern: '**/*.apex' },
                    kwargProvider, '(', ','
                )
            );

            // 7. Auto-trigger kwarg completions when cursor lands inside empty ()
            //    Covers the case where Pylance inserts func() — the ( isn't typed
            //    by the user so our trigger character doesn't fire.
            let kwargTriggerTimer;
            context.subscriptions.push(
                vscode.workspace.onDidChangeTextDocument(event => {
                    if (!isApexFile(event.document)) return;
                    if (!event.contentChanges.some(c => c.text.includes('('))) return;

                    if (kwargTriggerTimer) clearTimeout(kwargTriggerTimer);
                    kwargTriggerTimer = setTimeout(() => {
                        const editor = vscode.window.activeTextEditor;
                        if (!editor || editor.document !== event.document) return;

                        const pos = editor.selection.active;
                        const line = event.document.lineAt(pos.line).text;
                        const before = line.substring(0, pos.character);
                        const after = line.substring(pos.character);

                        // Cursor between empty parens after a function call pattern
                        if (before.endsWith('(') && after.startsWith(')') && /\w+\.\w+\s*\($/.test(before)) {
                            vscode.commands.executeCommand('editor.action.triggerSuggest');
                        }
                    }, 100);
                })
            );

            // 8. Register hover provider for callback documentation
            const hoverProvider = new ApexHoverProvider(referencePath);
            context.subscriptions.push(
                vscode.languages.registerHoverProvider(
                    { language: 'python', pattern: '**/*.apex' },
                    hoverProvider
                )
            );
        }
    }

    // 9. Set up unsupported-feature and type-system diagnostics
    if (config.get('diagnostics.enabled', true)) {
        diagnosticCollection = vscode.languages.createDiagnosticCollection('apexscript');
        context.subscriptions.push(diagnosticCollection);

        // Run diagnostics on save
        context.subscriptions.push(
            vscode.workspace.onDidSaveTextDocument(doc => {
                if (isApexFile(doc)) {
                    runDiagnostics(doc, context.extensionPath, referencePath);
                }
            })
        );

        // Run diagnostics on change (debounced 500ms)
        context.subscriptions.push(
            vscode.workspace.onDidChangeTextDocument(event => {
                if (isApexFile(event.document)) {
                    if (diagnosticTimer) {
                        clearTimeout(diagnosticTimer);
                    }
                    diagnosticTimer = setTimeout(() => {
                        runDiagnostics(event.document, context.extensionPath, referencePath);
                    }, 500);
                }
            })
        );

        // Clear diagnostics when a document closes
        context.subscriptions.push(
            vscode.workspace.onDidCloseTextDocument(doc => {
                if (isApexFile(doc)) {
                    diagnosticCollection.delete(doc.uri);
                }
            })
        );

        // Diagnose already-open .apex documents
        for (const doc of vscode.workspace.textDocuments) {
            if (isApexFile(doc)) {
                runDiagnostics(doc, context.extensionPath, referencePath);
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Apex Import Injection
// ---------------------------------------------------------------------------

const APEX_IMPORT_LINE = 'from apexscript import *';

/**
 * Returns true if the document already contains `from apexscript import *`
 * within its first 200 lines. Scanning this far (rather than just the first
 * few) means we won't inject a duplicate into a file that already imports it
 * lower down — e.g. after a comment header or docstring.
 */
function hasApexImport(doc) {
    const limit = Math.min(doc.lineCount, 200);
    for (let i = 0; i < limit; i++) {
        if (doc.lineAt(i).text.trim() === APEX_IMPORT_LINE) return true;
    }
    return false;
}

/**
 * Insert `from apexscript import *` at the top of a document if missing.
 * Called on open so Pylance can resolve bare names immediately.
 */
async function ensureApexImport(doc) {
    if (!isApexFile(doc) || doc.isUntitled || hasApexImport(doc)) return;
    const edit = new vscode.WorkspaceEdit();
    edit.insert(doc.uri, new vscode.Position(0, 0), APEX_IMPORT_LINE + '\n');
    await vscode.workspace.applyEdit(edit);
}

/**
 * Register the will-save hook that injects `from apexscript import *` just
 * before the file is written to disk — transparent to the user.
 */
function registerApexImportInjection(context) {
    // Inject on save (transparent — no dirty-state side-effect)
    context.subscriptions.push(
        vscode.workspace.onWillSaveTextDocument(event => {
            if (!isApexFile(event.document) || hasApexImport(event.document)) return;
            const insertEdit = vscode.TextEdit.insert(
                new vscode.Position(0, 0),
                APEX_IMPORT_LINE + '\n'
            );
            event.waitUntil(Promise.resolve([insertEdit]));
        })
    );

    // Also inject on open (with a short delay to let language-switching settle)
    // so Pylance can resolve bare type names without requiring a save first.
    context.subscriptions.push(
        vscode.workspace.onDidOpenTextDocument(doc => {
            if (isApexFile(doc)) {
                setTimeout(() => ensureApexImport(doc), 300);
            }
        })
    );

    // Handle already-open .apex documents at activation time
    for (const doc of vscode.workspace.textDocuments) {
        if (isApexFile(doc)) {
            setTimeout(() => ensureApexImport(doc), 300);
        }
    }
}

// ---------------------------------------------------------------------------

/**
 * Switch .apex documents from apexscript to Python language ID.
 * This lets Pylance (the Python LSP) provide type checking via stubs.
 */
function setApexAsPython(context) {
    // Switch already-open .apex documents
    for (const doc of vscode.workspace.textDocuments) {
        if (isApexFile(doc) && doc.languageId !== 'python') {
            vscode.languages.setTextDocumentLanguage(doc, 'python');
        }
    }

    // Switch newly opened .apex documents
    context.subscriptions.push(
        vscode.workspace.onDidOpenTextDocument(doc => {
            if (isApexFile(doc) && doc.languageId !== 'python') {
                vscode.languages.setTextDocumentLanguage(doc, 'python');
            }
        })
    );
}

// ---------------------------------------------------------------------------
// Pylance Stub Path Configuration
// ---------------------------------------------------------------------------

/**
 * Configure python.analysis.stubPath so Pylance discovers apexscript-stubs.
 *
 * Resolution order:
 *   1. Bundled with extension: {extensionPath}/typings/apexscript-stubs/
 *   2. Workspace discovery: scan workspace folders for apexscript-stubs/
 *   3. Known development path (Cygwin layout)
 *
 * The stubPath is set at workspace scope so it doesn't pollute user settings.
 */
function configureStubPath(context) {
    const stubsDir = resolveStubsPath(context);
    if (!stubsDir) {
        console.warn('ApexScript: could not find apexscript-stubs directory');
        return;
    }

    // stubPath must point to the PARENT of the apexscript-stubs/ directory
    const stubParent = path.dirname(stubsDir);

    const pythonConfig = vscode.workspace.getConfiguration('python.analysis');
    const current = pythonConfig.get('stubPath', '');

    // Don't overwrite if already pointing at the right place
    if (current && fs.existsSync(path.join(current, 'apexscript-stubs'))) {
        return;
    }

    pythonConfig.update('stubPath', stubParent, vscode.ConfigurationTarget.Workspace);
}

/**
 * Find the apexscript-stubs directory.
 * Returns the full path to apexscript-stubs/ or null.
 */
function resolveStubsPath(context) {
    // 1. Bundled with extension
    const bundled = path.join(context.extensionPath, 'typings', 'apexscript-stubs');
    if (fs.existsSync(path.join(bundled, '__init__.pyi'))) {
        return bundled;
    }

    // 2. Workspace discovery
    if (vscode.workspace.workspaceFolders) {
        for (const folder of vscode.workspace.workspaceFolders) {
            const candidates = [
                path.join(folder.uri.fsPath, 'apexscript-stubs'),
                path.join(folder.uri.fsPath, 'houdini', 'custom', 'packages', 'apex', 'apexscript-stubs'),
            ];
            for (const candidate of candidates) {
                if (fs.existsSync(path.join(candidate, '__init__.pyi'))) {
                    return candidate;
                }
            }
        }
    }

    // 3. Known development paths
    const devPaths = [
        'c:/cygwin/repos/dev/src/admin/AI/Claude/esthert/projects/apexscript-comfort-package/packages/apexscript-stubs',
        'C:\\cygwin\\repos\\dev\\src\\admin\\AI\\Claude\\esthert\\projects\\apexscript-comfort-package\\packages\\apexscript-stubs',
    ];
    for (const devPath of devPaths) {
        if (fs.existsSync(path.join(devPath, '__init__.pyi'))) {
            return devPath;
        }
    }

    return null;
}

// ---------------------------------------------------------------------------
// Snippet Completion Provider
// ---------------------------------------------------------------------------

class ApexSnippetProvider {
    constructor(extensionPath) {
        this.snippets = [];
        this._loadSnippets(extensionPath);
    }

    _loadSnippets(extensionPath) {
        const snippetPath = path.join(extensionPath, 'snippets', 'apexscript.json');
        try {
            const raw = fs.readFileSync(snippetPath, 'utf-8');
            const data = JSON.parse(raw);
            for (const [name, snippet] of Object.entries(data)) {
                const prefix = snippet.prefix;
                const body = Array.isArray(snippet.body)
                    ? snippet.body.join('\n')
                    : snippet.body;

                const item = new vscode.CompletionItem(
                    prefix,
                    vscode.CompletionItemKind.Snippet
                );
                item.detail = `[ApexScript] ${name}`;
                item.documentation = new vscode.MarkdownString(snippet.description);
                item.insertText = new vscode.SnippetString(body);
                // Sort ApexScript snippets after Pylance completions
                item.sortText = `zzz_apex_${prefix}`;
                // Filter text lets VS Code match on the prefix
                item.filterText = prefix;
                this.snippets.push(item);
            }
        } catch (err) {
            console.error('Failed to load ApexScript snippets:', err.message);
        }
    }

    provideCompletionItems(document, _position, _token, _context) {
        // Only provide snippets for .apex files, not regular .py files
        if (!isApexFile(document)) {
            return [];
        }
        return this.snippets;
    }
}

// ---------------------------------------------------------------------------
// Bind Completion Provider (context-aware bindInput snippets)
// ---------------------------------------------------------------------------

/**
 * Default values for bindInput() by ApexScript type annotation.
 * Uses tuple literals for vectors (matches real .apex conventions).
 */
const BIND_TYPE_DEFAULTS = {
    'Float': '0.0',
    'Int': '0',
    'Bool': 'False',
    'String': "''",
    'Vector2': '(0, 0)',
    'Vector3': '(0, 0, 0)',
    'Vector4': '(0, 0, 0, 0)',
    'Matrix3': 'Matrix3()',
    'Matrix4': 'Matrix4()',
    'Geometry': 'Geometry()',
    'Dict': 'Dict()',
    'Quaternion': 'Quaternion()',
    'ColorRamp': 'ColorRamp()',
    'FloatRamp': 'FloatRamp()',
};

/**
 * Convert a variable name to a human-readable label.
 * Splits on underscores and camelCase boundaries, then title-cases each word.
 *   myVar       -> 'My Var'
 *   world_space -> 'World Space'
 *   worldspace  -> 'Worldspace'
 */
function varNameToLabel(name) {
    const words = name
        .replace(/_/g, ' ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .trim()
        .split(/\s+/);
    return words.map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
}

/**
 * Provides context-aware bindInput() snippet completions.
 * When the cursor is after "varname: Type = ", offers bind/bindLabel/bindTag/etc.
 * String-only presets (bindTag, bindControl, bindPython) are filtered by type.
 */
class BindCompletionProvider {
    provideCompletionItems(document, position, _token, _context) {
        if (!isApexFile(document)) return [];

        const line = document.lineAt(position.line).text;
        const textBefore = line.substring(0, position.character);

        // Match "varname: Type = <cursor>" or "varname = <cursor>"
        const match = textBefore.match(/(\w+)\s*(?::\s*(\w+)\s*)?=\s*\w*$/);
        if (!match) return [];

        const varName = match[1];
        const typeName = match[2] || null;
        const defaultVal = typeName ? (BIND_TYPE_DEFAULTS[typeName] || '') : '';
        const label = varNameToLabel(varName);
        const isString = typeName === 'String';

        const items = [];

        // 1. bind -> bindInput(DEFAULT)
        const bindDefault = defaultVal || '${1}';
        items.push(this._makeItem(
            'bind',
            'bindInput with default value',
            `bindInput(${bindDefault})`,
            `bindInput(${defaultVal || '...'})`,
        ));

        // 2. bindLabel -> bindInput(DEFAULT, preset_kwargs={'label': 'LABEL'})
        items.push(this._makeItem(
            'bindLabel',
            'bindInput with label',
            `bindInput(\n    ${bindDefault},\n    preset_kwargs={'label': '${label}'}\n)`,
            `bindInput(${defaultVal || '...'}, preset_kwargs={'label': '${label}'})`,
        ));

        // 3. bindTag -> String only
        if (!typeName || isString) {
            items.push(this._makeItem(
                'bindTag',
                'bindInput with tags preset (String)',
                `bindInput('', preset='tags', preset_kwargs={'label': '${label}', 'usepattern': True, 'prompt_text': ''})`,
                `bindInput('', preset='tags', preset_kwargs={...})`,
            ));
        }

        // 4. bindControl -> String only
        if (!typeName || isString) {
            items.push(this._makeItem(
                'bindControl',
                'bindInput with controlshapes preset (String)',
                `bindInput('box_wires', preset='controlshapes')`,
                `bindInput('box_wires', preset='controlshapes')`,
            ));
        }

        // 5. bindPython -> String only
        if (!typeName || isString) {
            items.push(this._makeItem(
                'bindPython',
                'bindInput with python preset (String)',
                `bindInput('', preset='python')`,
                `bindInput('', preset='python')`,
            ));
        }

        return items;
    }

    _makeItem(prefix, description, insertText, detail) {
        const item = new vscode.CompletionItem(
            prefix,
            vscode.CompletionItemKind.Snippet,
        );
        item.detail = `[ApexScript] ${detail}`;
        item.documentation = new vscode.MarkdownString(description);
        item.insertText = new vscode.SnippetString(insertText);
        item.sortText = `aaa_bind_${prefix}`;
        item.filterText = prefix;
        return item;
    }
}

// ---------------------------------------------------------------------------
// Unsupported Feature Diagnostics (Python subprocess)
// ---------------------------------------------------------------------------

/**
 * Run the diagnostics companion script on a document and publish results.
 * When referencePath is provided, callback return types are used for
 * type reassignment detection on apex.ns.func() calls.
 */
function runDiagnostics(document, extensionPath, referencePath) {
    const scriptPath = path.join(extensionPath, 'diagnostics-companion.py');
    const config = vscode.workspace.getConfiguration('apexscript');
    const pythonPath = config.get('diagnostics.pythonPath', '') || findNativePython();

    if (!pythonPath) {
        return;
    }

    const args = [scriptPath];
    if (referencePath) {
        args.push('--reference-path', referencePath);
    }
    const proc = cp.spawn(pythonPath, args, { timeout: 10000 });

    proc.stdin.write(document.getText());
    proc.stdin.end();

    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', chunk => { stdout += chunk; });
    proc.stderr.on('data', chunk => { stderr += chunk; });

    proc.on('error', err => {
        // python3 not found or similar — log quietly, don't spam user
        console.error('ApexScript diagnostics: failed to spawn Python:', err.message);
    });

    proc.on('close', code => {
        if (code !== 0) {
            if (stderr) {
                console.error('ApexScript diagnostics error:', stderr);
            }
            return;
        }

        try {
            const issues = JSON.parse(stdout);
            const diagnostics = issues.map(issue => {
                const range = new vscode.Range(
                    issue.line, issue.column,
                    issue.end_line, issue.end_column
                );
                const severity = issue.severity === 'error'
                    ? vscode.DiagnosticSeverity.Error
                    : vscode.DiagnosticSeverity.Warning;
                const diag = new vscode.Diagnostic(range, issue.message, severity);
                diag.source = 'apexscript';
                return diag;
            });
            diagnosticCollection.set(document.uri, diagnostics);
        } catch (err) {
            console.error('ApexScript diagnostics: failed to parse output:', err.message);
        }
    });
}

// ---------------------------------------------------------------------------
// Port Completion Provider
// ---------------------------------------------------------------------------

/**
 * Provides context-aware autocomplete for port attributes on ApexNodeID variables.
 * When a user types `node.` after `node = graph.addNode('name', 'TransformObject')`,
 * suggests port names (e.g., xform_in, xform_out) derived from the callback signature.
 *
 * Two-layer architecture:
 *   Layer 1 (Stubs): ApexNodeID.__getattr__ -> ApexPortID prevents Pylance false errors
 *   Layer 2 (This):  CompletionItemProvider suggests actual port names based on callback type
 */
class PortCompletionProvider {
    constructor(referencePath) {
        this._callbacks = {};
        this._subgraphs = {};
        this._loadData(referencePath);
    }

    _loadData(referencePath) {
        if (callbackDataCache) {
            this._callbacks = callbackDataCache.callbacks;
            this._subgraphs = callbackDataCache.subgraphs;
            return;
        }

        const callbacksPath = path.join(
            referencePath, 'metadata', 'api-cache', 'callbacks_cache.json'
        );
        const subgraphsPath = path.join(
            referencePath, 'metadata', 'api-cache', 'subgraphs_cache.json'
        );

        try {
            this._callbacks = JSON.parse(fs.readFileSync(callbacksPath, 'utf-8'));
        } catch (err) {
            console.error('PortCompletionProvider: failed to load callbacks_cache.json:', err.message);
        }

        try {
            this._subgraphs = JSON.parse(fs.readFileSync(subgraphsPath, 'utf-8'));
        } catch (err) {
            console.error('PortCompletionProvider: failed to load subgraphs_cache.json:', err.message);
        }

        callbackDataCache = {
            callbacks: this._callbacks,
            subgraphs: this._subgraphs,
        };
    }

    provideCompletionItems(document, position, _token, _context) {
        if (!isApexFile(document)) {
            return [];
        }

        const lineText = document.lineAt(position.line).text;
        const textBeforeCursor = lineText.substring(0, position.character);

        // 1. Check for chained dot: "node.port_attr." → ApexPortID method completions
        const chainedMatch = textBeforeCursor.match(/(\w+)\.(\w+)\.\s*$/);
        if (chainedMatch) {
            const nodeVarName = chainedMatch[1];
            const callbackName = findCallbackForVariable(document, nodeVarName);
            if (callbackName) {
                // The first part is a tracked ApexNodeID, so the second part
                // is a port attribute (ApexPortID). Suggest port methods.
                return generatePortMethodCompletions();
            }
        }

        // 2. Check for single dot: "variable." → port name completions
        const dotMatch = textBeforeCursor.match(/(\w+)\.\s*$/);
        if (!dotMatch) {
            return [];
        }

        const varName = dotMatch[1];
        const callbackName = findCallbackForVariable(document, varName);
        if (!callbackName) {
            return [];
        }

        // Look up callback in both caches (callbacks first, then subgraphs)
        const callbackData = this._callbacks[callbackName] || this._subgraphs[callbackName];
        if (!callbackData || !callbackData.parameters) {
            return [];
        }

        return generatePortCompletions(callbackData.parameters, callbackName);
    }
}

// ---------------------------------------------------------------------------
// Variable-to-Callback Tracking
// ---------------------------------------------------------------------------

/**
 * Regex pattern to match addNode/addOrUpdateNode positional-args assignments.
 *
 * Matches the simple positional form only:
 *   node = graph.addNode('name', 'CallbackName')
 *   node = graph.addOrUpdateNode('name', 'CallbackName')
 *   node: ApexNodeID = graph.addNode('name', 'CallbackName')
 *
 * For callback= kwarg forms see findCallbackKwarg().
 */
const ADD_NODE_PATTERN = /(\w+)\s*(?::\s*\w+\s*)?=\s*\w+\.(?:addNode|addOrUpdateNode)\s*\(\s*['"][^'"]*['"]\s*,\s*['"]([^'"]+)['"]\s*\)/gi;

/**
 * The method names recognized as node-creation calls.
 * Case-insensitive matching covers both addNode and AddNode, etc.
 */
const NODE_METHODS = '(?:addNode|addOrUpdateNode)';

/**
 * Scan the document for node-creation calls and find the callback name
 * associated with a given variable name.
 *
 * Checks (in order):
 *   1. Positional pattern: var = graph.addNode('name', 'CallbackName')
 *   2. Kwarg pattern: var = graph.addNode(callback='CallbackName', ...) — supports multiline
 *   3. controlsFromGuides loop: for var in array_from_ControlsFromGuides → TransformObject
 */
function findCallbackForVariable(document, varName) {
    const text = document.getText();
    const escaped = escapeRegExp(varName);

    // 1. Positional pattern — var = graph.addNode('name', 'CallbackName')
    const positionalPattern = new RegExp(
        escaped + '\\s*(?::\\s*\\w+\\s*)?=\\s*\\w+\\.' + NODE_METHODS + '\\s*\\(\\s*[\'"][^\'"]*[\'"]\\s*,\\s*[\'"]([^\'"]+)[\'"]\\s*\\)',
        'gi'
    );
    const positionalMatch = positionalPattern.exec(text);
    if (positionalMatch) {
        return positionalMatch[1];
    }

    // 2. Kwarg pattern — callback='...' inside addNode/addOrUpdateNode call
    //    Handles multiline and tuple unpacking (var, exists = ...)
    const callbackName = findCallbackKwarg(text, escaped);
    if (callbackName) {
        return callbackName;
    }

    // 3. For-loop over controlsFromGuides node array (all nodes are TransformObject)
    const forPattern = new RegExp(
        'for\\s+' + escaped + '\\s+in\\s+(\\w+)\\s*:'
    );
    const forMatch = forPattern.exec(text);
    if (forMatch) {
        const arrayVarName = forMatch[1];
        if (isControlsFromGuidesArray(text, arrayVarName)) {
            return 'TransformObject';
        }
    }

    return null;
}

/**
 * Find callback= kwarg value in addNode/addOrUpdateNode calls where
 * varName appears on the LHS of the assignment.
 *
 * Handles:
 *   rest = graph.addOrUpdateNode(callback='Value<Geometry>', name=...)
 *   pttrans, exists = graph.addOrUpdateNode(\n    callback='TransformObject', ...)
 *   node = graph.addNode('name', callback='Value<Float>')
 *   node = graph.AddOrUpdateNode(callback='TransformObject', ...)
 *
 * Uses paren-depth matching to handle multiline calls.
 */
function findCallbackKwarg(text, escapedVarName) {
    // Match assignment LHS containing varName, then the call opening paren
    // Handles: varName = ..., varName, x = ..., varName: Type = ...
    const lhsPattern = new RegExp(
        '(?:(?:\\w+\\s*,\\s*)*' + escapedVarName + '(?:\\s*,\\s*\\w+)*)' +
        '\\s*(?::\\s*\\w+\\s*)?=\\s*(?:\\w+\\.)+' + NODE_METHODS + '\\s*\\(',
        'gi'
    );

    let match;
    while ((match = lhsPattern.exec(text)) !== null) {
        const bodyStart = match.index + match[0].length;
        const callBody = extractCallBody(text, bodyStart);
        if (callBody) {
            const cbMatch = callBody.match(/callback\s*=\s*['"]([^'"]+)['"]/);
            if (cbMatch) {
                return cbMatch[1];
            }
        }
    }
    return null;
}

/**
 * Extract the body of a function call (everything between the opening paren
 * and its matching closing paren). Handles nested parens.
 *
 * @param {string} text - Full document text
 * @param {number} startIdx - Index right after the opening '('
 * @returns {string|null} Text between parens, or null if unbalanced
 */
function extractCallBody(text, startIdx) {
    let depth = 1;
    let i = startIdx;
    while (i < text.length && depth > 0) {
        if (text[i] === '(') depth++;
        else if (text[i] === ')') depth--;
        i++;
    }
    return depth === 0 ? text.substring(startIdx, i - 1) : null;
}

/**
 * Check if a variable is the ApexNodeIDArray returned by controlsFromGuides.
 * Matches the 3rd element of tuple-unpacking from ControlsFromGuides:
 *   graph, geo, arrayVar = graph.ControlsFromGuides(...)
 *   _, _, arrayVar = apex.guide.ControlsFromGuides(...)
 */
function isControlsFromGuidesArray(text, arrayVarName) {
    const escaped = escapeRegExp(arrayVarName);
    const pattern = new RegExp(
        '\\w+\\s*,\\s*\\w+\\s*,\\s*' + escaped + '\\s*=\\s*\\w+\\.ControlsFromGuides\\s*\\('
    );
    return pattern.test(text);
}

// ---------------------------------------------------------------------------
// Port Completion Generation
// ---------------------------------------------------------------------------

/**
 * Generate CompletionItem objects for port attributes from callback parameters.
 *
 * For each parameter, generates:
 *   - param_in  (input port)  — typed as ApexPortID
 *   - param_out (output port) — typed as ApexPortID
 *
 * The ApexPortID type enables further chaining (e.g., node.xform_out.connect(...))
 * since ApexNodeID.__getattr__ -> ApexPortID in the Pylance stubs.
 */
function generatePortCompletions(parameters, callbackName) {
    const items = [];

    for (let i = 0; i < parameters.length; i++) {
        const param = parameters[i];
        const paramName = param.name;
        const paramType = param.type || 'Any';
        const padIdx = String(i).padStart(3, '0');

        // Input port
        const inItem = new vscode.CompletionItem(
            `${paramName}_in`,
            vscode.CompletionItemKind.Field
        );
        inItem.detail = `ApexPortID (${paramType} input)`;
        inItem.documentation = new vscode.MarkdownString(
            `Input port \`${paramName}\` on **${callbackName}** node\n\nType: \`ApexPortID\` — data type: \`${paramType}\``
        );
        inItem.sortText = `0_${padIdx}_${paramName}_in`;
        items.push(inItem);

        // Output port
        const outItem = new vscode.CompletionItem(
            `${paramName}_out`,
            vscode.CompletionItemKind.Field
        );
        outItem.detail = `ApexPortID (${paramType} output)`;
        outItem.documentation = new vscode.MarkdownString(
            `Output port \`${paramName}\` on **${callbackName}** node\n\nType: \`ApexPortID\` — data type: \`${paramType}\``
        );
        outItem.sortText = `0_${padIdx}_${paramName}_out`;
        items.push(outItem);
    }

    return items;
}

// ---------------------------------------------------------------------------
// Port Method Completion (ApexPortID methods)
// ---------------------------------------------------------------------------

/**
 * ApexPortID methods with their signatures and descriptions.
 * These are the operations available on any port attribute (e.g., node.xform_out.connect(...)).
 * Derived from apexscript-stubs/_types.pyi ApexPortID class.
 */
const APEX_PORT_METHODS = [
    { name: 'connect', signature: '(dstport: ApexPortID, name: String)', returnType: 'None', description: 'Connect this port to a destination port' },
    { name: 'connectInput', signature: '(dstport: ApexPortID, name: String)', returnType: 'None', description: 'Connect input to a destination port' },
    { name: 'connectPath', signature: '(dstport, name)', returnType: 'Any', description: 'Connect this port via path' },
    { name: 'connected', signature: '()', returnType: 'ApexPortIDArray', description: 'Get all ports connected to this port' },
    { name: 'data', signature: '()', returnType: 'Tuple[String, String, String, String, Bool, Bool, ApexPortID]', description: 'Get port data tuple' },
    { name: 'disconnect', signature: '(removedynamic: Bool)', returnType: 'None', description: 'Disconnect this port' },
    { name: 'disconnectPort', signature: '(removedynamic: Bool)', returnType: 'None', description: 'Disconnect this port (alias)' },
    { name: 'findAndRemoveWire', signature: '(dst: ApexPortID, removedynamic: Bool)', returnType: 'None', description: 'Find and remove a wire to the destination port' },
    { name: 'getConnectedNodes', signature: '()', returnType: 'ApexNodeIDArray', description: 'Get all nodes connected to this port' },
    { name: 'getConnectedPort', signature: '()', returnType: 'ApexPortID', description: 'Get the single connected port' },
    { name: 'getConnectedPorts', signature: '()', returnType: 'ApexPortIDArray', description: 'Get all connected ports' },
    { name: 'getPromotedPort', signature: '()', returnType: 'ApexPortID', description: 'Get the promoted port on the parent graph' },
    { name: 'isValidID', signature: '()', returnType: 'Bool', description: 'Check if this port ID is valid' },
    { name: 'node', signature: '()', returnType: 'ApexNodeID', description: 'Get the node this port belongs to' },
    { name: 'outerPort', signature: '()', returnType: 'ApexPortID', description: 'Get the outer port' },
    { name: 'portData', signature: '()', returnType: 'Tuple[String, String, String, String, Bool, Bool, ApexPortID]', description: 'Get port data (alias for data)' },
    { name: 'portNode', signature: '()', returnType: 'ApexNodeID', description: 'Get the node this port belongs to (alias)' },
    { name: 'portPath', signature: '(qualify: Bool)', returnType: 'String', description: 'Get the path string for this port' },
    { name: 'promote', signature: '(name)', returnType: 'Any', description: 'Promote this port' },
    { name: 'promoteInput', signature: '(subportname: String, parmnodeid: ApexNodeID, parmname: String)', returnType: 'ApexPortID', description: 'Promote this port as an input on the parent graph' },
    { name: 'promoteOutput', signature: '(outputname: String, outputnodeid: ApexNodeID)', returnType: 'ApexPortID', description: 'Promote this port as an output on the parent graph' },
    { name: 'promotePort', signature: '(name: String)', returnType: 'ApexGraphHandle', description: 'Promote this port with a given name' },
    { name: 'promoted', signature: '()', returnType: 'ApexPortID', description: 'Get the promoted version of this port' },
    { name: 'renamePort', signature: '(name: String)', returnType: 'None', description: 'Rename this port' },
    { name: 'rewireOutputs', signature: '(targetport: ApexPortID)', returnType: 'None', description: 'Rewire all outputs to a target port' },
    { name: 'subport', signature: '(portname: String)', returnType: 'ApexPortID', description: 'Get a named subport' },
    { name: 'acceptsSubport', signature: '()', returnType: 'Bool', description: 'Check if this port accepts subports' },
    { name: 'addAbstractControl', signature: '(name: String, promote: String, parmnames: String, properties: Dict)', returnType: 'Tuple[ApexGraphHandle, ApexNodeID]', description: 'Add an abstract control to this port' },
    { name: 'getSubPort', signature: '(portname: String)', returnType: 'None', description: 'Get a named subport (alias)' },
];

/**
 * Generate CompletionItem objects for ApexPortID methods.
 * Used when the user types `node.port_attr.` (chained dot after a port attribute).
 */
function generatePortMethodCompletions() {
    const items = [];

    for (let i = 0; i < APEX_PORT_METHODS.length; i++) {
        const method = APEX_PORT_METHODS[i];
        const padIdx = String(i).padStart(3, '0');

        const item = new vscode.CompletionItem(
            method.name,
            vscode.CompletionItemKind.Method
        );
        item.detail = `ApexPortID.${method.name}${method.signature} → ${method.returnType}`;
        item.documentation = new vscode.MarkdownString(
            `${method.description}\n\n**Signature**: \`${method.name}${method.signature}\`\n\n**Returns**: \`${method.returnType}\``
        );
        item.sortText = `0_${padIdx}_${method.name}`;
        items.push(item);
    }

    return items;
}

// ---------------------------------------------------------------------------
// Hover Provider
// ---------------------------------------------------------------------------

/**
 * Provides hover documentation for ApexScript callbacks using the reference
 * data cache. Shows the callback description and all overload signatures.
 */
class ApexHoverProvider {
    constructor(referencePath) {
        this.referencePath = referencePath;
        this.callbackData = null;
    }

    _loadCallbackData() {
        if (this.callbackData) return this.callbackData;
        try {
            const cachePath = path.join(this.referencePath, 'metadata', 'api-cache', 'callbacks_cache.json');
            this.callbackData = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
        } catch (e) {
            this.callbackData = {};
        }
        return this.callbackData;
    }

    provideHover(document, position) {
        if (!isApexFile(document)) return null;

        const line = document.lineAt(position).text;
        const col = position.character;

        // Find the ns.func token that the cursor is on.
        // Walk back from cursor to find a word boundary that includes ns.func.
        const before = line.substring(0, col);
        const after = line.substring(col);

        // Extend word forward
        const wordAfter = (after.match(/^[\w]*/)?.[0]) || '';
        // Extend word+dot+word backward
        const wordBefore = (before.match(/[\w.]*$/)?.[0]) || '';

        const token = wordBefore + wordAfter;  // e.g. "geo.setPointAttribValue" or just "setPointAttribValue"

        const dotIdx = token.lastIndexOf('.');
        if (dotIdx < 0) return null;

        const ns = token.substring(0, dotIdx).replace(/^.*\./, ''); // last segment before the dot
        const func = token.substring(dotIdx + 1);
        if (!ns || !func) return null;

        const data = this._loadCallbackData();

        // Try to find the base callback key (without type param)
        const funcPascal = func.charAt(0).toUpperCase() + func.slice(1);
        const baseKey = this._resolveBaseKey(data, ns, funcPascal, func);
        if (!baseKey) return null;

        // Collect all overloads sharing the same base name
        const baseName = baseKey.replace(/<[^>]*>$/, '');  // strip <Type>
        const overloads = Object.entries(data).filter(([k]) =>
            k === baseKey || k.startsWith(baseName + '<') || k === baseName
        );

        if (overloads.length === 0) return null;

        // Build hover markdown
        const description = overloads[0][1].description || '';
        const lines = [];

        if (description) {
            lines.push(description);
            lines.push('');
        }

        if (overloads.length === 1) {
            const [, cb] = overloads[0];
            lines.push('```apexscript');
            lines.push(cb.signature || baseKey);
            lines.push('```');
        } else {
            const [, first] = overloads[0];
            lines.push('```apexscript');
            lines.push(first.signature || '');
            lines.push('```');
            lines.push(`*+${overloads.length - 1} overload${overloads.length > 2 ? 's' : ''}*`);
        }

        return new vscode.Hover(new vscode.MarkdownString(lines.join('\n')));
    }

    _resolveBaseKey(data, ns, funcPascal, func) {
        // 1. Exact namespace-qualified match (with or without type param)
        const candidates = [`${ns}::${funcPascal}`, `${ns}::${func}`];
        for (const c of candidates) {
            if (data[c]) return c;
            // Check if any key starts with this (overloaded)
            const prefixed = Object.keys(data).find(k => k === c || k.startsWith(c + '<'));
            if (prefixed) return prefixed;
        }

        // 2. Case-insensitive namespace-qualified
        const targetLower = `${ns}::${func}`.toLowerCase();
        const found = Object.keys(data).find(k =>
            k.toLowerCase() === targetLower ||
            k.toLowerCase().startsWith(targetLower + '<')
        );
        if (found) return found;

        // 3. Any namespace — match by function name only
        const funcLower = func.toLowerCase();
        return Object.keys(data).find(k => {
            const sep = k.lastIndexOf('::');
            if (sep < 0) return false;
            const keyFunc = k.substring(sep + 2).replace(/<[^>]*>$/, '');
            return keyFunc === funcPascal || keyFunc === func || keyFunc.toLowerCase() === funcLower;
        }) || null;
    }
}

// ---------------------------------------------------------------------------
// Keyword Argument Completion Provider
// ---------------------------------------------------------------------------

/**
 * Provides keyword argument completions inside function calls.
 * When a user types inside `apex.sop.box(|)`, suggests `size=`, `type=`, etc.
 * Also provides a "Fill all arguments" snippet that inserts all params with defaults.
 */
class KwargCompletionProvider {
    constructor(referencePath) {
        this.referencePath = referencePath;
        this.callbackData = null;
    }

    _loadCallbackData() {
        if (this.callbackData) return this.callbackData;
        try {
            const cachePath = path.join(this.referencePath, 'metadata', 'api-cache', 'callbacks_cache.json');
            this.callbackData = JSON.parse(fs.readFileSync(cachePath, 'utf8'));
        } catch (e) {
            this.callbackData = {};
        }
        return this.callbackData;
    }

    provideCompletionItems(document, position, _token, _context) {
        if (!isApexFile(document)) return [];

        const line = document.lineAt(position).text;
        const textBefore = line.substring(0, position.character);

        // Detect function call context: find "apex.ns.func(" or "func("
        const callbackName = this._resolveCallbackName(textBefore);
        if (!callbackName) return [];

        const data = this._loadCallbackData();
        const cb = data[callbackName];
        if (!cb || !cb.parameters) return [];

        // Find already-typed kwargs to exclude
        const openParen = textBefore.lastIndexOf('(');
        const typed = openParen >= 0 ? textBefore.substring(openParen) : '';
        const typedKwargs = new Set((typed.match(/(\w+)\s*=/g) || []).map(m => m.replace(/\s*=/, '')));

        const items = [];

        // Individual kwarg completions
        cb.parameters.forEach((param, i) => {
            const name = param.name.replace(/^[*+]/, '');
            if (!name || name === '__spare__' || typedKwargs.has(name)) return;

            const item = new vscode.CompletionItem(
                `${name}=`,
                vscode.CompletionItemKind.Field
            );
            item.insertText = new vscode.SnippetString(`\n    ${name}=\$1`);
            item.sortText = String(i).padStart(3, '0');
            item.detail = `${name}: ${param.type}${param.default ? ' = ' + param.default : ''}`;
            items.push(item);
        });

        // "Fill all arguments" snippet
        const fillSnippet = this._buildFillAllSnippet(cb.parameters, typedKwargs);
        if (fillSnippet) {
            const fillItem = new vscode.CompletionItem(
                'Fill all arguments',
                vscode.CompletionItemKind.Snippet
            );
            fillItem.insertText = fillSnippet;
            fillItem.sortText = '000';
            fillItem.detail = 'Insert all parameters with default values';
            items.push(fillItem);
        }

        return items;
    }

    _resolveCallbackName(textBefore) {
        // Match patterns like "apex.sop.box(" or "variable.method(" etc.
        const match = textBefore.match(/(?:apex\.)?(\w+)\.(\w+)\s*\(/);
        if (!match) return null;
        const ns = match[1];
        const func = match[2];
        const data = this._loadCallbackData();

        // 1. Namespace-specific: try ns::FuncPascal, ns::func
        const funcPascal = func.charAt(0).toUpperCase() + func.slice(1);
        const candidates = [`${ns}::${funcPascal}`, `${ns}::${func}`];
        for (const c of candidates) {
            if (data[c]) return c;
        }

        // 2. Namespace-specific case-insensitive
        const target = `${ns}::${func}`.toLowerCase();
        for (const key of Object.keys(data)) {
            if (key.toLowerCase() === target) return key;
        }

        // 3. Namespace-agnostic fallback — handles OO calls like
        //    mygraph.addNode() where "mygraph" is a variable, not a namespace.
        //    Search for any callback whose function part matches.
        const funcLower = func.toLowerCase();
        for (const key of Object.keys(data)) {
            const sep = key.lastIndexOf('::');
            if (sep < 0) continue;
            const keyFunc = key.substring(sep + 2);
            if (keyFunc === funcPascal || keyFunc === func || keyFunc.toLowerCase() === funcLower) {
                return key;
            }
        }

        return null;
    }

    _buildFillAllSnippet(params, typedKwargs) {
        const ZERO_DEFAULTS = {
            'Int': '0', 'Float': '0.0', 'Bool': 'False', 'String': '""',
            'Vector2': 'Vector2(0, 0)', 'Vector3': 'Vector3(0, 0, 0)',
            'Vector4': 'Vector4(0, 0, 0, 0)', 'Matrix3': 'Matrix3(1)',
            'Matrix4': 'Matrix4(1)', 'Dict': 'Dict()',
        };
        const parts = [];
        let tabIdx = 1;
        for (const param of params) {
            const name = param.name.replace(/^[*+]/, '');
            if (!name || name === '__spare__' || typedKwargs.has(name)) continue;
            const defaultVal = param.default || ZERO_DEFAULTS[param.type] || '';
            parts.push(`${name}=\${${tabIdx}:${defaultVal}}`);
            tabIdx++;
        }
        if (parts.length === 0) return null;
        return new vscode.SnippetString('\n    ' + parts.join(',\n    ') + '\n');
    }
}

// ---------------------------------------------------------------------------
// Reference Path Resolution
// ---------------------------------------------------------------------------

/**
 * Resolve the path to reference data for port completion.
 * Tries: explicit config > languageServer.referencePath > workspace auto-discovery.
 */
function resolveReferencePath(config, context) {
    // 0. Bundled with extension
    if (context) {
        const bundledRef = path.join(context.extensionPath, 'reference-data');
        const bundledCache = path.join(bundledRef, 'metadata', 'api-cache', 'callbacks_cache.json');
        if (fs.existsSync(bundledCache)) {
            return bundledRef;
        }
    }

    // 1. Explicit port completion reference path
    const portPath = config.get('portCompletion.referencePath', '');
    if (portPath && fs.existsSync(portPath)) {
        return portPath;
    }

    // 2. Reuse languageServer reference path (may be WSL path — convert if needed)
    const lspPath = config.get('languageServer.referencePath', '');
    if (lspPath) {
        const resolved = resolveWindowsPath(lspPath);
        if (resolved && fs.existsSync(resolved)) {
            return resolved;
        }
    }

    // 3. Auto-discover from workspace folders
    if (vscode.workspace.workspaceFolders) {
        for (const folder of vscode.workspace.workspaceFolders) {
            const candidates = [
                path.join(folder.uri.fsPath, 'apexscript-reference-loader', 'reference-data'),
                path.join(folder.uri.fsPath, 'apexscript-reference'),
            ];
            for (const candidate of candidates) {
                const cacheFile = path.join(
                    candidate, 'metadata', 'api-cache', 'callbacks_cache.json'
                );
                if (fs.existsSync(cacheFile)) {
                    return candidate;
                }
            }
        }
    }

    // 4. Try known development location (Cygwin)
    const devPaths = [
        'c:/cygwin/repos/dev/src/admin/AI/Claude/esthert/projects/apexscript-comfort-package/packages/apexscript-reference-loader/reference-data',
        'C:\\cygwin\\repos\\dev\\src\\admin\\AI\\Claude\\esthert\\projects\\apexscript-comfort-package\\packages\\apexscript-reference-loader\\reference-data',
    ];
    for (const devPath of devPaths) {
        if (fs.existsSync(devPath)) {
            return devPath;
        }
    }

    return null;
}

/**
 * Convert a WSL path to a Windows path if needed.
 * /mnt/c/foo/bar -> C:/foo/bar
 */
function resolveWindowsPath(p) {
    if (!isNode || process.platform !== 'win32') {
        return p;
    }
    const wslMatch = p.match(/^\/mnt\/([a-z])\/(.*)$/);
    if (wslMatch) {
        return `${wslMatch[1].toUpperCase()}:/${wslMatch[2]}`;
    }
    return p;
}

// ---------------------------------------------------------------------------
// Standalone LSP Mode
// ---------------------------------------------------------------------------

function activateStandaloneMode(context) {
    const config = vscode.workspace.getConfiguration('apexscript');

    if (!config.get('languageServer.enabled', true)) {
        return;
    }

    const referencePath = config.get('languageServer.referencePath', '') ||
        '/mnt/c/cygwin/repos/dev/src/admin/AI/Claude/esthert/projects/apexscript-comfort-package/reference/apexscript-reference';

    let serverCommand, serverArgs;
    if (isNode && process.platform === 'win32') {
        serverCommand = 'wsl';
        serverArgs = ['python3', '-m', 'apexscript_lsp_server', referencePath];
    } else {
        serverCommand = 'python3';
        serverArgs = ['-m', 'apexscript_lsp_server', referencePath];
    }

    const serverOptions = {
        run: {
            command: serverCommand,
            args: serverArgs,
            transport: TransportKind.stdio,
        },
        debug: {
            command: serverCommand,
            args: serverArgs,
            transport: TransportKind.stdio,
        },
    };

    const clientOptions = {
        documentSelector: [
            { scheme: 'file', language: 'apexscript' },
        ],
        synchronize: {
            fileEvents: vscode.workspace.createFileSystemWatcher('**/*.apex'),
        },
    };

    client = new LanguageClient(
        'apexscriptLsp',
        'ApexScript Language Server',
        serverOptions,
        clientOptions,
    );

    client.start();
}

// ---------------------------------------------------------------------------
// Utilities
// ---------------------------------------------------------------------------

/**
 * Find a native Windows Python interpreter, skipping Cygwin binaries.
 * On non-Windows platforms, returns 'python3'.
 * Caches the result after first call.
 */
let _cachedPython = undefined;
function findNativePython() {
    if (_cachedPython !== undefined) {
        return _cachedPython;
    }

    if (!isNode || process.platform !== 'win32') {
        _cachedPython = 'python3';
        return _cachedPython;
    }

    // Well-known install locations for native Windows Python
    const candidates = [];

    // Python Launcher (py.exe) - works with any python.org install
    candidates.push('py');

    // Standard python.org install paths
    const localPrograms = (isNode && process.env.LOCALAPPDATA) || '';
    if (localPrograms) {
        for (const ver of ['313', '312', '311', '310']) {
            candidates.push(path.join(localPrograms, 'Programs', 'Python', `Python${ver}`, 'python.exe'));
        }
    }

    // System-wide installs
    for (const ver of ['313', '312', '311', '310']) {
        candidates.push(`C:\\Python${ver}\\python.exe`);
        candidates.push(`C:\\Program Files\\Python${ver}\\python.exe`);
    }

    for (const candidate of candidates) {
        try {
            const result = cp.spawnSync(candidate, ['--version'], {
                timeout: 3000,
                windowsHide: true,
            });
            if (result.status === 0) {
                _cachedPython = candidate;
                return _cachedPython;
            }
        } catch {
            // try next
        }
    }

    console.error('ApexScript: no native Python found for diagnostics');
    _cachedPython = null;
    return null;
}

/**
 * Check if a document is an ApexScript file (by extension, not language ID).
 */
function isApexFile(document) {
    return document.fileName.endsWith('.apex');
}

/**
 * Escape special regex characters in a string for use in RegExp constructor.
 */
function escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function deactivate() {
    if (diagnosticTimer) {
        clearTimeout(diagnosticTimer);
    }
    if (diagnosticCollection) {
        diagnosticCollection.dispose();
    }
    if (client) {
        return client.stop();
    }
}

module.exports = {
    activate,
    deactivate,
    // Exported for testing
    _internal: {
        ADD_NODE_PATTERN,
        APEX_PORT_METHODS,
        BIND_TYPE_DEFAULTS,
        BindCompletionProvider,
        KwargCompletionProvider,
        generatePortCompletions,
        generatePortMethodCompletions,
        findCallbackKwarg,
        extractCallBody,
        isControlsFromGuidesArray,
        resolveWindowsPath,
        escapeRegExp,
        varNameToLabel,
    },
};
