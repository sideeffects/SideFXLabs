"""Self-contained Python/ApexScript syntax highlighter for the fallback editor.
No imports from apex.* — this module must be fully standalone.
"""
from __future__ import annotations

import re

from hutil.PySide.QtGui import QColor, QTextCharFormat, QFont, QSyntaxHighlighter


def _fmt(color: str, style: str = '') -> QTextCharFormat:
    fmt = QTextCharFormat()
    fmt.setForeground(QColor(color))
    if 'bold' in style:
        fmt.setFontWeight(QFont.Bold)
    if 'italic' in style:
        fmt.setFontItalic(True)
    return fmt


STYLES = {
    'keyword': _fmt('lightBlue'),
    'operator': _fmt('red'),
    'brace': _fmt('darkGray'),
    'defclass': _fmt('orange', 'bold'),
    'string': _fmt('gray'),
    'string2': _fmt('darkGray'),
    'comment': _fmt('green', 'italic'),
    'self': _fmt('orange', 'italic'),
    'numbers': _fmt('darkOrange'),
    'decorator': _fmt('yellow'),
}


class PythonHighlighter(QSyntaxHighlighter):
    keywords = [
        'and', 'assert', 'break', 'class', 'continue', 'def',
        'del', 'elif', 'else', 'except', 'finally',
        'for', 'from', 'global', 'if', 'import', 'in',
        'is', 'lambda', 'not', 'or', 'pass',
        'raise', 'return', 'try', 'while', 'yield',
        'None', 'True', 'False',
    ]

    operators = [
        r'==', r'!=', r'<=', r'>=', r'\+=', r'-=', r'\*=', r'/=', r'\%=',
        r'\*\*', r'//', r'<<', r'>>',
        r'=', r'<', r'>',
        r'\+', r'-', r'\*', r'/', r'\%',
        r'\^', r'\|', r'\&', r'\~',
    ]

    braces = [r'\{', r'\}', r'\(', r'\)', r'\[', r'\]']

    def __init__(self, document):
        super().__init__(document)

        rules = []
        rules += [(r'\b%s\b' % w, 0, STYLES['keyword']) for w in self.keywords]
        rules += [(r'%s' % o, 0, STYLES['operator']) for o in self.operators]
        rules += [(r'%s' % b, 0, STYLES['brace']) for b in self.braces]
        rules += [
            (r'\bself\b', 0, STYLES['self']),
            (r'@\w+', 0, STYLES['decorator']),
            (r'"[^"\\]*(\\.[^"\\]*)*"', 0, STYLES['string']),
            (r"'[^'\\]*(\\.[^'\\]*)*'", 0, STYLES['string']),
            (r'\bdef\b\s*(\w+)', 1, STYLES['defclass']),
            (r'\bclass\b\s*(\w+)', 1, STYLES['defclass']),
            (r'#[^\n]*', 0, STYLES['comment']),
            (r'\b[+-]?0[xX][0-9A-Fa-f]+[lL]?\b', 0, STYLES['numbers']),
            (r'\b[+-]?[0-9]+(?:\.[0-9]+)?(?:[eE][+-]?[0-9]+)?\b', 0, STYLES['numbers']),
        ]

        self.rules = [(re.compile(pat), idx, fmt) for pat, idx, fmt in rules]
        self._tri_single = re.compile(r"'''")
        self._tri_double = re.compile(r'"""')

    def highlightBlock(self, text):
        for expression, nth, fmt in self.rules:
            for m in expression.finditer(text):
                start = m.start(nth)
                length = m.end(nth) - start
                self.setFormat(start, length, fmt)

        self.setCurrentBlockState(0)
        if not self._match_multiline(text, self._tri_single, 1, STYLES['string2']):
            self._match_multiline(text, self._tri_double, 2, STYLES['string2'])

    def _match_multiline(self, text, delimiter, in_state, style):
        if self.previousBlockState() == in_state:
            start = 0
            add = 0
        else:
            m = delimiter.search(text)
            if m is None:
                return False
            start = m.start()
            add = m.end() - m.start()

        while start >= 0:
            m = delimiter.search(text, start + add)
            if m is not None:
                length = m.end() - start
                self.setCurrentBlockState(0)
            else:
                self.setCurrentBlockState(in_state)
                length = len(text) - start
            self.setFormat(start, length, style)
            m2 = delimiter.search(text, start + length)
            if m2 is None:
                break
            start = m2.start()
            add = m2.end() - m2.start()

        return self.currentBlockState() == in_state
