"""VS Code settings + workspace-trust + per-profile state writers.

Owns everything that gets written into ``$USERPROFILE/.vscode-serve-web/data/``
and into the named QtWebEngine profile dir. The trust-handling here is
load-bearing: see :func:`ensure_trust` for the 4-layer documentation, and
``feedback_trust_uri_canonicalization.md`` / ``feedback_webview_indexeddb_clear.md``
in the project memory for the regression history that made each layer
necessary.

Settings are split into 4 named sub-tables (``_TRUST_SUPPRESSION``,
``_EXTENSION_BEHAVIOUR``, ``_WELCOME_SUPPRESSION``, ``_VISUAL_CHROME``)
whose union forms ``_UI_SETTINGS`` — the User-scope writer consumes the
union, the Machine-scope writer consumes only the trust subset + 3 of the 4
extension keys, and the workspace writer none of it.

All path lookups (``get_server_data_dir``, ``find_stubs_path``, etc.)
are lazy-imported from ``paths`` so paths.py can re-export from this
module without a circular load.
"""
from __future__ import annotations
import json
from pathlib import Path


# ---------------------------------------------------------------------------
# VS Code settings tables
#
# Split into purpose-named sub-tables so each setting has a single source of
# truth and Machine / User / workspace writers can compose the right slice
# instead of duplicating literals. ``_UI_SETTINGS`` (the union) is what the
# User-scope writer uses; ``ensure_machine_settings`` composes a tighter
# subset.
# ---------------------------------------------------------------------------

# Workspace trust — written at Machine scope (read first by
# WorkspaceTrustManagementService before any extension activates) AND at
# User scope (belt-and-suspenders). The per-folder trust grant
# is a separate mechanism handled in ``ensure_workspace_trusted``.
_TRUST_SUPPRESSION = {
    'security.workspace.trust.enabled': False,
    'security.workspace.trust.startupPrompt': 'never',
    'security.workspace.trust.banner': 'never',
    'security.workspace.trust.emptyWindow': True,
    'security.workspace.trust.untrustedFiles': 'open',
}

# Extension behaviour — suppress local-extension signature checks (VS Code
# 1.96+), block auto-update prompts, and silence the recommendations popup.
_EXTENSION_BEHAVIOUR = {
    'extensions.verifySignature': False,
    'extensions.autoUpdate': False,
    'extensions.autoCheckUpdates': False,
    'extensions.ignoreRecommendations': True,
}

# Welcome / startup / chat screens added in VS Code 1.96+. Only
# ``chat.commandCenter.enabled`` is the known-valid chat key in VS Code
# 1.118.1 — the experimental ones (``chat.agent.enabled``,
# ``chat.welcomeMessage``, ``github.copilot.chat.*``) don't exist in 1.118.1
# and writing them triggers a "settings have errors" toast that stays
# visible. Hide the chat panel via the close commands in ``extension.js``
# instead.
_WELCOME_SUPPRESSION = {
    'workbench.welcomePage.enabled': False,
    'workbench.welcomePage.walkthroughs.openOnInstall': False,
    'workbench.startupEditor': 'none',
    'chat.commandCenter.enabled': False,
}

# Embedded-panel visual chrome — hide everything that isn't the editor.
_VISUAL_CHROME = {
    'window.menuBarVisibility': 'classic',
    'workbench.sideBar.visible': False,
    'workbench.activityBar.location': 'hidden',
    'workbench.statusBar.visible': False,
    'editor.minimap.enabled': False,
    'breadcrumbs.enabled': False,
    'workbench.editor.showTabs': 'none',
    'workbench.editor.enablePreview': False,   # always-permanent tabs
    'explorer.openEditors.visible': 0,
    'workbench.colorTheme': 'Default Dark Modern',
    'window.autoDetectColorScheme': False,
    'zenMode.centerLayout': False,
}

# Composite used by the User-scope settings.json writer.
_UI_SETTINGS = {
    **_TRUST_SUPPRESSION,
    **_EXTENSION_BEHAVIOUR,
    **_WELCOME_SUPPRESSION,
    **_VISUAL_CHROME,
}

# Machine-scope settings.json subset. Trust suppression must live here
# because VS Code 1.97+ reads Machine scope before User scope and before
# any extension can activate. The extensions subset deliberately excludes
# ``extensions.ignoreRecommendations`` because the recommendations popup
# is a User-scope concern (irrelevant at boot, before the trust manager
# runs); keeping Machine tighter mirrors prior shipped behaviour.
_MACHINE_EXTENSION_KEYS = (
    'extensions.verifySignature',
    'extensions.autoUpdate',
    'extensions.autoCheckUpdates',
)


# ---------------------------------------------------------------------------
# Settings writers
# ---------------------------------------------------------------------------


def ensure_workspace(workspace: Path | None = None) -> Path:
    """Create workspace dir with .vscode/settings.json.

    If *workspace* is None, falls back to ``get_workspace_dir()`` (the legacy
    shared workspace).  Pass an explicit path (e.g. from
    ``vscode_server.next_workspace_dir()``) for per-panel isolation.
    """
    from .paths import (get_workspace_dir, find_stubs_path,
                        _find_system_python)
    if workspace is None:
        workspace = get_workspace_dir()
    vscode_dir = workspace / '.vscode'
    vscode_dir.mkdir(parents=True, exist_ok=True)
    settings_file = vscode_dir / 'settings.json'

    stubs_parent = find_stubs_path() or ''
    # No _UI_SETTINGS here: "Open External" can open this folder in the
    # user's desktop VS Code, where the embedded view's chrome hiding would
    # apply too. serve-web gets them from its User settings (ensure_user_settings).
    settings = {
        'files.associations': {'*.apex': 'python'},
        'python.analysis.stubPath': stubs_parent,
        'apexscript.mode': 'pylance',
        'apexscript.diagnostics.pythonPath': _find_system_python(),
        'files.autoSave': 'off',
    }
    settings_file.write_text(json.dumps(settings, indent=4))
    return workspace


def ensure_user_settings(data_dir: Path | None = None):
    """Write user-level settings into the serve-web server data dir.

    Since we don't open a workspace folder via ?folder=, workspace-level
    settings in .vscode/settings.json are NOT loaded by serve-web.
    All important settings must go into user-level settings.

    *data_dir* is the per-slot ``instance-N`` server-data-dir (see
    ``paths.get_instance_data_dir``); falls back to the shared root for
    backwards compatibility.
    """
    from .paths import (get_server_data_dir, find_stubs_path,
                        find_reference_path, _find_system_python)
    base = data_dir if data_dir is not None else get_server_data_dir()
    user_dir = base / 'data' / 'User'
    user_dir.mkdir(parents=True, exist_ok=True)
    settings_file = user_dir / 'settings.json'

    stubs_parent = find_stubs_path() or ''
    ref_path = find_reference_path() or ''
    settings = {
        'files.associations': {'*.apex': 'python'},
        'python.analysis.stubPath': stubs_parent,
        'apexscript.mode': 'pylance',
        'apexscript.diagnostics.pythonPath': _find_system_python(),
        'apexscript.portCompletion.referencePath': ref_path,
        'apexscript.languageServer.referencePath': ref_path,
        'files.autoSave': 'off',
    }
    settings.update(_UI_SETTINGS)
    settings_file.write_text(json.dumps(settings, indent=4))


def ensure_workspace_trusted(workspace_vscode_path: str, port: int,
                             data_dir: Path | None = None):
    """Pre-trust the workspace in VS Code's server-side SQLite state database.

    VS Code's WorkspaceTrustManagementService reads per-folder trust decisions
    from ``data/User/globalStorage/state.vscdb`` before reading any settings
    files, so settings-level suppression (``security.workspace.trust.enabled``)
    can lose the race.  Writing ``trusted: true`` directly to the database
    ensures VS Code finds the workspace already trusted and never prompts.

    We try multiple storage keys used across VS Code versions and both the
    ``vscode-remote://`` URI (serve-web) and ``file:///`` URI (fallback).
    Writes are best-effort; errors are printed but do not abort startup.
    """
    import sqlite3
    from .paths import get_server_data_dir
    base = data_dir if data_dir is not None else get_server_data_dir()
    db_path = base / 'data' / 'User' / 'globalStorage' / 'state.vscdb'
    db_path.parent.mkdir(parents=True, exist_ok=True)

    ws = workspace_vscode_path.replace('\\', '/')
    # VS Code internally canonicalises Windows file URIs to lowercase drive
    # letter + URL-encoded colon (e.g. ``file:///c%3A/Users/...``). The init
    # extension's log confirms this: ``workspaceFolders:
    # ["file:///c%3A/Users/esthe/.vscode-serve-web/workspace-0"]``. If the
    # trust DB only stores the literal ``C:`` form, VS Code's URI compare
    # misses every session and shows the trust dialog. We pre-write every
    # plausible variant so the trust check matches regardless of which form
    # VS Code computes on a given build.
    def _uri_variants(p: str):
        """Yield (uppercase, lowercase) × (literal colon, %3A) — 4 forms."""
        if len(p) >= 2 and p[1] == ':':
            drive = p[0]
            tail = p[2:]
            for d in (drive, drive.lower()):
                for colon in (':', '%3A'):
                    yield f'{d}{colon}{tail}'
        else:
            yield p

    uris = []
    for v in _uri_variants(ws):
        uris.append({'uri': f'vscode-remote://127.0.0.1:{port}/{v}', 'trusted': True})
        uris.append({'uri': f'file:///{v}', 'trusted': True})
    trust_entries = json.dumps(uris)
    # Key names used across VS Code versions
    keys = [
        'workspaceTrustFolders',
        'workspaceTrustManagementService.workspacesTrust',
        'workspaceTrust',
    ]
    try:
        conn = sqlite3.connect(str(db_path))
        try:
            conn.execute('''
                CREATE TABLE IF NOT EXISTS ItemTable (
                    key TEXT NOT NULL UNIQUE,
                    value BLOB
                )
            ''')
            for key in keys:
                try:
                    conn.execute(
                        'INSERT OR REPLACE INTO ItemTable (key, value) VALUES (?, ?)',
                        (key, trust_entries),
                    )
                except Exception:
                    pass
            conn.commit()
        finally:
            conn.close()
    except Exception:
        pass


def ensure_machine_settings(data_dir: Path | None = None):
    """Write Machine-scope settings into the serve-web server data dir.

    VS Code 1.97+ reads Machine-scope settings before User-scope for certain
    security and trust settings. Writing trust suppression here ensures it
    takes effect before the workspace trust modal can appear.

    Content is derived from ``_TRUST_SUPPRESSION`` + the Machine-scope
    subset of ``_EXTENSION_BEHAVIOUR`` so this stays in sync with the
    User-scope writer automatically.
    """
    from .paths import get_server_data_dir
    base = data_dir if data_dir is not None else get_server_data_dir()
    machine_dir = base / 'data' / 'Machine'
    machine_dir.mkdir(parents=True, exist_ok=True)
    settings = dict(_TRUST_SUPPRESSION)
    for key in _MACHINE_EXTENSION_KEYS:
        settings[key] = _EXTENSION_BEHAVIOUR[key]
    (machine_dir / 'settings.json').write_text(json.dumps(settings, indent=4))


def ensure_trust(workspace_vscode_path: str, port: int,
                 data_dir: Path | None = None):
    """Configure workspace trust through every mechanism VS Code consults.

    Trust suppression in the embedded panel relies on FOUR distinct
    layers, applied in the order VS Code reads them. This function owns
    the two server-side mechanisms (1 and 2); the other two are handled
    elsewhere and are listed here for orientation:

    **1. Machine-scope settings.json** *(written here via*
    ``ensure_machine_settings``\\ *)*. ``security.workspace.trust.enabled =
    false`` at Machine scope disables the trust manager *before* any
    extension can activate; VS Code 1.97+ reads Machine before User.
    Without this layer the trust modal can appear during the trust-manager
    init race even with User-scope suppression in place. As a side effect
    this also writes the Machine subset of ``_EXTENSION_BEHAVIOUR`` —
    incidental, kept here because they share the file.

    **2. ``state.vscdb`` pre-write** *(written here via*
    ``ensure_workspace_trusted``\\ *)*. Inserts 8 URI variants
    (``{C,c} × {':','%3A'} × {vscode-remote://, file:///}``\\ ) into
    ``workspaceTrustFolders`` / ``workspaceTrustManagementService.workspacesTrust``
    / ``workspaceTrust``. VS Code's URI compare is case-and-encoding
    sensitive — without the canonical ``c%3A`` variant the trust check
    misses every session. See ``feedback_trust_uri_canonicalization.md``.

    **3. QtWebEngine IndexedDB ``uriTrustInfo``** *(written by VS Code
    itself when the user accepts trust; preserved across normal
    sessions; only wiped by* ``clear_webengine_profile_if_vscode_updated``
    *on VS Code upgrade).* Layers 1+2 should make this acceptance
    unnecessary, but if the user does click "Yes, I trust the authors"
    the grant still sticks.

    **4. User-scope settings.json + runtime ``config.update``** *(written
    by ``ensure_user_settings`` and by* ``extension.js`` *activate())*.
    Belt-and-suspenders; survives any of the above being reset.

    All four must remain working to avoid the regression where the trust
    dialog appears on every Houdini restart. Do not collapse layers
    without a plan for what replaces them.
    """
    ensure_machine_settings(data_dir)
    ensure_workspace_trusted(workspace_vscode_path, port, data_dir)


def clear_webengine_profile_if_vscode_updated():
    """Delete the QtWebEngine profile storage if VS Code was updated.

    VS Code stores workspace trust decisions and other state in the browser's
    IndexedDB, which lives inside the named QtWebEngine profile directory.
    When VS Code updates, this cached state can become stale or incompatible,
    causing the trust dialog to appear even with trust disabled in settings.

    Detecting a VS Code version change and deleting the profile directory
    forces a clean browser state.  VS Code will re-read all settings from
    the file-based data dir (which we write fresh at every startup).

    The profile directory location is determined from Qt's standard paths,
    using the same profile name passed to QWebEngineProfile().
    """
    import shutil
    from .paths import get_server_data_dir
    from .vscode_server import _find_code_cli

    cli = _find_code_cli()
    if not cli:
        return

    # Read VS Code version from its package.json
    cli_path = Path(cli)
    # code.cmd sits in bin/; VS Code resources are two levels up
    vscode_dir = cli_path.parent.parent
    version_file = vscode_dir / 'resources' / 'app' / 'package.json'
    if not version_file.exists():
        return
    try:
        pkg = json.loads(version_file.read_text(encoding='utf-8'))
        vscode_version = pkg.get('version', '')
    except Exception:
        return
    if not vscode_version:
        return

    data_dir = get_server_data_dir()
    version_marker = data_dir / '.vscode-version'
    stored_version = ''
    try:
        stored_version = version_marker.read_text(encoding='utf-8').strip()
    except Exception:
        pass

    if vscode_version == stored_version:
        return  # Same version — nothing to do

    # VS Code version changed: clear the named QtWebEngine profile directory
    # so stale IndexedDB trust state doesn't survive the update.
    try:
        from hutil.PySide import QtCore
        loc = QtCore.QStandardPaths.writableLocation(
            getattr(getattr(QtCore.QStandardPaths, 'StandardLocation',
                            QtCore.QStandardPaths),
                    'AppDataLocation',
                    QtCore.QStandardPaths.AppDataLocation)
        )
        profile_dir = Path(loc) / 'QtWebEngine' / 'apexscript_vscode'
        if profile_dir.exists():
            shutil.rmtree(profile_dir, ignore_errors=True)
    except Exception:
        pass

    try:
        version_marker.write_text(vscode_version, encoding='utf-8')
    except Exception:
        pass


def _webengine_profiles_root() -> Path | None:
    """Return the QtWebEngine profiles dir (parent of the named profile dirs)."""
    try:
        from hutil.PySide import QtCore
        loc = QtCore.QStandardPaths.writableLocation(
            getattr(getattr(QtCore.QStandardPaths, 'StandardLocation',
                            QtCore.QStandardPaths),
                    'AppDataLocation',
                    QtCore.QStandardPaths.AppDataLocation)
        )
        return Path(loc) / 'QtWebEngine'
    except Exception:
        return None


def reap_dead_webengine_profiles():
    """Remove per-PID QtWebEngine profile dirs whose owner process is dead.

    The per-PID profile scheme (plan item 4) names each session's profile
    ``apexscript_vscode_{pid}`` so concurrent Houdini sessions don't fight over
    one Chromium profile dir. Because those dirs are keyed by PID they are never
    reused, so an exited session's profile must be reaped or they accumulate.
    The shared, non-suffixed ``apexscript_vscode`` profile is left untouched.
    """
    import shutil
    from .process import _is_pid_alive
    root = _webengine_profiles_root()
    if root is None or not root.is_dir():
        return
    for d in root.glob('apexscript_vscode_*'):
        if not d.is_dir():
            continue
        try:
            pid = int(d.name.rsplit('_', 1)[-1])
        except (ValueError, IndexError):
            continue
        if not _is_pid_alive(pid):
            shutil.rmtree(d, ignore_errors=True)
