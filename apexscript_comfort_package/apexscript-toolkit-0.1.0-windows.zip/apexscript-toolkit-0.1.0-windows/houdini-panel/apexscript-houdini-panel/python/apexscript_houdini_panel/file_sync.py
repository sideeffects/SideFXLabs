from __future__ import annotations
import hashlib
from pathlib import Path

import hou
from hutil.PySide import QtCore

from .paths import get_apex_file, ensure_workspace

# Timer intervals (milliseconds).
_WATCHER_REASSERT_INTERVAL_MS = 2000  # re-add watches Qt loses on rename-replace saves
_FILE_CHANGE_DEBOUNCE_MS = 300        # debounce file→parm flush after fileChanged fires
_SUPPRESS_CLEAR_DELAY_MS = 50         # delay before clearing a suppression flag (absorbs follow-up events)


def _md5(text: str) -> str:
    return hashlib.md5(text.encode('utf-8')).hexdigest()


# ---------------------------------------------------------------------------
# Session-level watcher registry
#
# Watches every .apex temp file we have ever bound in this Houdini session,
# regardless of which node the panel is currently showing. This is what makes
# "switching back and forth between two nodes while an external editor has
# both files open" work — each external save still finds its matching
# Houdini parm even after the panel has rebound to a different node.
# ---------------------------------------------------------------------------


class _Pinned:
    """A single file→parm pinning, kept alive for the whole session."""
    __slots__ = ('node', 'parm_name', 'last_hash', 'debounce', 'suppressing')

    def __init__(self, node: 'hou.Node', parm_name: str):
        self.node = node
        self.parm_name = parm_name
        self.last_hash: str | None = None
        self.debounce: 'QtCore.QTimer | None' = None
        self.suppressing = False


class _SessionWatchers(QtCore.QObject):
    """Module-singleton: one QFileSystemWatcher + table of pinned files.

    A single watcher avoids hitting Windows' inotify-style watch-count limits
    when many nodes are bound in one session, and keeps the file→parm path
    independent of the panel's currently-selected node.
    """

    _instance: '_SessionWatchers | None' = None

    @classmethod
    def instance(cls) -> '_SessionWatchers':
        if cls._instance is None:
            cls._instance = _SessionWatchers()
        return cls._instance

    def __init__(self):
        super().__init__()
        self._watcher = QtCore.QFileSystemWatcher(self)
        self._watcher.fileChanged.connect(self._on_file_changed)
        self._pinned: dict[str, _Pinned] = {}
        # Periodic re-arm: Qt loses watches when editors save via
        # rename-replace. Every 2 s we re-add any path that has dropped off.
        self._reassert = QtCore.QTimer(self)
        self._reassert.setInterval(_WATCHER_REASSERT_INTERVAL_MS)
        self._reassert.timeout.connect(self._reassert_all)
        self._reassert.start()

    # ----- pin lifecycle ---------------------------------------------------

    def pin(self, file_path: Path, node: 'hou.Node', parm_name: str,
            initial_hash: str | None) -> _Pinned:
        """Add (or refresh) a pinning for *file_path*."""
        key = str(file_path)
        pin = self._pinned.get(key)
        if pin is None:
            pin = _Pinned(node, parm_name)
            pin.debounce = QtCore.QTimer(self)
            pin.debounce.setSingleShot(True)
            pin.debounce.setInterval(_FILE_CHANGE_DEBOUNCE_MS)
            pin.debounce.timeout.connect(
                lambda k=key: self._flush_to_parm(k)
            )
            self._pinned[key] = pin
            self._watcher.addPath(key)
        else:
            # Rebinding the same file to a (possibly different) node — update
            # the target so external edits route to the right parm.
            pin.node = node
            pin.parm_name = parm_name
        if initial_hash is not None:
            pin.last_hash = initial_hash
        return pin

    def get(self, file_path: Path) -> '_Pinned | None':
        return self._pinned.get(str(file_path))

    # ----- watcher callbacks ----------------------------------------------

    def _on_file_changed(self, path: str):
        # Qt loses the watched inode on atomic-rename saves — re-add.
        self._watcher.removePath(path)
        self._watcher.addPath(path)
        pin = self._pinned.get(path)
        if pin is None or pin.suppressing:
            return
        pin.debounce.start()

    def _reassert_all(self):
        watched = set(self._watcher.files())
        for path in list(self._pinned.keys()):
            if path not in watched:
                try:
                    self._watcher.addPath(path)
                except Exception:
                    pass

    def _flush_to_parm(self, key: str):
        pin = self._pinned.get(key)
        if pin is None:
            return
        try:
            content = Path(key).read_text(encoding='utf-8')
        except Exception:
            return
        h = _md5(content)
        if h == pin.last_hash:
            return
        pin.last_hash = h
        # Houdini node may have been deleted — guard with try/except.
        try:
            parm = pin.node.parm(pin.parm_name)
            if parm is None:
                return
            pin.suppressing = True
            try:
                parm.set(content)
            finally:
                QtCore.QTimer.singleShot(_SUPPRESS_CLEAR_DELAY_MS,
                                          lambda: self._clear_suppress(key))
        except (hou.ObjectWasDeleted, AttributeError):
            # Node was deleted from the scene — drop the pinning.
            self._pinned.pop(key, None)
            self._watcher.removePath(key)

    def _clear_suppress(self, key: str):
        pin = self._pinned.get(key)
        if pin is not None:
            pin.suppressing = False


class ParameterFileSync(QtCore.QObject):
    """Keeps a Houdini string parameter in sync with a temp .apex file.

    Lifecycle properties that make the sync robust:

    - Temp files are session-scoped, not bind-scoped: unbind() leaves the
      file on disk so external editors that still have it open keep working.
    - file→parm: handled by the session-level watcher, which keeps every
      ever-bound file in sync regardless of the currently-selected node.
    - parm→file: handled here, via the Houdini parm callback, only for the
      currently-bound (node, parm).
    - Bind reconciles file vs parm via a hash so re-binding to a node whose
      file was edited externally while we were away does not lose those
      edits.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._node: hou.Node | None = None
        self._parm_name: str | None = None
        self._file_path: Path | None = None
        self._slot: int = 0
        self._workspace: 'Path | None' = None
        self._parm_suppressing = False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def configure(self, slot: int, workspace: 'Path'):
        """Set the panel slot and workspace dir before bind() is called."""
        self._slot = slot
        self._workspace = workspace

    def bind(self, node: hou.Node, parm_name: str, hip_path: str = ''):
        # Detach the previous parm callback but leave the file pinned in the
        # session watcher so external edits to it keep flowing to its parm.
        self._detach_parm_callback()

        self._node = node
        self._parm_name = parm_name
        self._parm_suppressing = False
        ensure_workspace(self._workspace)
        self._file_path = get_apex_file(node.path(), parm_name, self._workspace,
                                        hip_path=hip_path)

        parm_value = node.parm(parm_name).eval() or ''
        parm_hash = _md5(parm_value)

        # Reconcile file vs parm. If we already have a pin for this file,
        # its last_hash is the source of truth for "what we last observed".
        watchers = _SessionWatchers.instance()
        pin = watchers.get(self._file_path)
        sibling_hash = pin.last_hash if pin is not None else None

        if self._file_path.exists() and self._file_path.stat().st_size > 0:
            try:
                existing = self._file_path.read_text(encoding='utf-8')
                file_hash = _md5(existing)
            except Exception:
                existing = parm_value
                file_hash = parm_hash

            if sibling_hash is not None and file_hash != sibling_hash:
                # File drifted from what we last observed — external edits
                # while we were away. Push them to the parm.
                self._parm_suppressing = True
                try:
                    node.parm(parm_name).set(existing)
                finally:
                    QtCore.QTimer.singleShot(_SUPPRESS_CLEAR_DELAY_MS, self._clear_parm_suppress)
                effective_hash = file_hash
                effective_content = existing
            else:
                # File matches expectation — keep its content.
                effective_hash = file_hash
                effective_content = existing
        else:
            self._write_file(parm_value)
            effective_hash = parm_hash
            effective_content = parm_value

        # Belt-and-suspenders: if the file disappeared between get_apex_file
        # (which created the parent dir) and now — e.g. an older panel build
        # still in the process running a destructive clean_workspace — make
        # sure the file exists on disk before we emit the signal. The init
        # extension would otherwise show VS Code's "file not found" error.
        if not self._file_path.exists():
            self._write_file(effective_content)

        # Pin (or re-target) the file in the session watcher.
        watchers.pin(self._file_path, node, parm_name, effective_hash)

        # Signal for the VS Code init extension to open the file
        self._write_open_signal()

        # Attach the parm→file callback for the currently-bound node.
        node.addEventCallback(
            [hou.nodeEventType.ParmTupleChanged],
            self._on_parm_changed
        )

    def unbind(self):
        """Detach the parm callback. Leaves the file watched and the file on
        disk so external editors keep working.
        """
        self._detach_parm_callback()
        self._node = None
        self._parm_name = None
        self._file_path = None
        self._parm_suppressing = False

    @property
    def file_path(self):
        return self._file_path

    def write_open_signal(self):
        """Re-send the open signal without rebinding."""
        self._write_open_signal()

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _detach_parm_callback(self):
        if self._node is None:
            return
        try:
            self._node.removeEventCallback(
                [hou.nodeEventType.ParmTupleChanged],
                self._on_parm_changed
            )
        except Exception:
            pass

    def _clear_parm_suppress(self):
        self._parm_suppressing = False

    def _write_file(self, content: str):
        if self._file_path is None:
            return
        try:
            self._file_path.write_text(content, encoding='utf-8')
        except Exception:
            pass

    def _write_open_signal(self):
        """Tell the VS Code init extension which file to open."""
        if self._file_path is None:
            return
        import json, time
        from .paths import to_vscode_path, get_server_data_dir, get_workspace_dir
        file_path = to_vscode_path(str(self._file_path))
        ws = self._workspace if self._workspace is not None else get_workspace_dir()
        ws_path = to_vscode_path(ws)
        payload = json.dumps({'workspace': ws_path, 'file': file_path, 't': time.time()})
        data_dir = get_server_data_dir()
        try:
            (data_dir / f'.apex-open-{self._slot}').write_text(payload, encoding='utf-8')
        except Exception:
            pass

    def _on_parm_changed(self, **kwargs):
        """Push parm edits to disk so external editors stay in sync.

        Uses _parm_suppressing to break the loopback (parm.set inside the
        session watcher's _flush_to_parm fires this callback).
        """
        if (self._parm_suppressing or self._node is None
                or self._file_path is None):
            return
        watchers = _SessionWatchers.instance()
        pin = watchers.get(self._file_path)
        if pin is not None and pin.suppressing:
            return
        try:
            value = self._node.parm(self._parm_name).eval() or ''
        except Exception:
            return
        h = _md5(value)
        if pin is not None and h == pin.last_hash:
            return
        self._parm_suppressing = True
        try:
            self._write_file(value)
            if pin is not None:
                pin.last_hash = h
        finally:
            QtCore.QTimer.singleShot(_SUPPRESS_CLEAR_DELAY_MS, self._clear_parm_suppress)
