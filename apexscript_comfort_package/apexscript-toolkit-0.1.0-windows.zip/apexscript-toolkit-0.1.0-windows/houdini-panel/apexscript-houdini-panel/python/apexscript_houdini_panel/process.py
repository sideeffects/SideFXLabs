"""Process-management helpers — PID liveness checks, killing stale servers,
port-to-PID lookups, and the cross-process slot-lock holders.

All functions prefer ``psutil`` (ships with Houdini's bundled Python) for
speed and locale-stability, and fall back to ``tasklist`` / ``netstat`` /
``lsof`` / ``os.kill`` when psutil is unavailable.

Needs ``get_server_data_dir`` from ``paths`` (where the slot lock files
live), imported lazily inside the two functions that use it so paths.py
can re-export from this module without a circular import.
"""
from __future__ import annotations
import os
import sys
import subprocess
from pathlib import Path


def _kill_pid(pid: int):
    """Kill a process by PID (Windows: taskkill /F /T; Unix: SIGTERM)."""
    try:
        if sys.platform in ('win32', 'cygwin'):
            subprocess.run(
                ['taskkill', '/F', '/T', '/PID', str(pid)],
                capture_output=True, timeout=5,
            )
        else:
            import os as _os, signal as _signal
            _os.kill(pid, _signal.SIGTERM)
    except Exception:
        pass


def _pid_holding_port(port: int) -> int | None:
    """Return the PID listening on 127.0.0.1:port, or None.

    Prefers ``psutil`` (ships with Houdini's bundled Python); falls back to
    ``netstat -ano`` on Windows/Cygwin or ``lsof`` on macOS/Linux when
    psutil is unavailable or denies access (macOS without root).
    """
    pid = _pid_holding_port_psutil(port)
    if pid is not None:
        return pid
    return _pid_holding_port_native(port)


def _pid_holding_port_psutil(port: int) -> int | None:
    try:
        import psutil
    except ImportError:
        return None
    try:
        for conn in psutil.net_connections(kind='inet'):
            if (conn.laddr and conn.laddr.port == port
                    and conn.status == 'LISTEN' and conn.pid):
                return conn.pid
    except Exception:
        # AccessDenied on macOS without root, transient errors, etc.
        pass
    return None


def _pid_holding_port_native(port: int) -> int | None:
    try:
        if sys.platform in ('win32', 'cygwin'):
            result = subprocess.run(
                ['netstat', '-ano'],
                capture_output=True, text=True, timeout=5,
            )
            needle = f'127.0.0.1:{port}'
            for line in result.stdout.splitlines():
                if needle in line and 'LISTENING' in line:
                    return int(line.strip().split()[-1])
        else:
            result = subprocess.run(
                ['lsof', '-iTCP:' + str(port), '-sTCP:LISTEN', '-t'],
                capture_output=True, text=True, timeout=5,
            )
            pid_str = result.stdout.strip().split('\n')[0]
            if pid_str:
                return int(pid_str)
    except Exception:
        pass
    return None


def kill_stale_server(slot: int, port: int | None = None):
    """Kill a stale code serve-web process left over from a previous session.

    On a clean Houdini shutdown, VSCodeServer.stop() terminates the process.
    On a crash or force-kill, the process lingers and holds the preferred port,
    causing _free_port() to fall back to a random port.  A random port means
    a new vscode-remote:// URI every session, which triggers the trust dialog
    every time because VS Code keys workspace trust to the port number.

    Refuses to kill anything if a *live* sibling Houdini session currently
    owns this slot — that's its server, not a stale one.

    Two strategies:
    1. PID file (.apex-server-pid-{slot}) written by the previous session.
    2. Fallback: if no PID file exists (first run with this code, or file
       deleted), find whatever process is LISTENING on the preferred port
       via netstat and kill it.
    """
    if _slot_is_live_other(slot):
        return
    from .paths import get_server_data_dir
    data_dir = get_server_data_dir()
    pid_file = data_dir / f'.apex-server-pid-{slot}'
    killed = False
    try:
        pid = int(pid_file.read_text(encoding='utf-8').strip())
        _kill_pid(pid)
        killed = True
    except Exception:
        pass
    try:
        pid_file.unlink(missing_ok=True)
    except Exception:
        pass
    # Fallback: kill by port if PID file was missing or stale
    if not killed and port is not None:
        holder = _pid_holding_port(port)
        if holder is not None:
            _kill_pid(holder)


def _is_pid_alive(pid: int) -> bool:
    """Cross-platform liveness check for a PID.

    Used to tell whether a slot lock file's owner is still around. We
    avoid touching workspaces and signal files belonging to live owners.

    Prefers ``psutil.pid_exists`` (microseconds) over ``tasklist`` /
    ``os.kill`` — slot allocation calls this up to ``_MAX_SLOTS`` times
    at panel construction, so subprocess-per-check is measurable.
    """
    if pid <= 0:
        return False
    try:
        import psutil
        return psutil.pid_exists(pid)
    except ImportError:
        pass
    try:
        if sys.platform in ('win32', 'cygwin'):
            result = subprocess.run(
                ['tasklist', '/FI', f'PID eq {pid}', '/NH'],
                capture_output=True, text=True, timeout=5,
            )
            return str(pid) in result.stdout
        else:
            os.kill(pid, 0)
            return True
    except Exception:
        return False


def _slot_holder_pid(slot: int) -> int | None:
    """Read the PID that owns ``.apex-slot-{slot}.lock``, or None."""
    from .paths import get_server_data_dir
    lock = get_server_data_dir() / f'.apex-slot-{slot}.lock'
    try:
        return int(lock.read_text(encoding='utf-8').strip())
    except Exception:
        return None


def _slot_is_live_other(slot: int) -> bool:
    """True if another live Houdini process owns this slot.

    Used by both ``clear_stale_signals`` and ``kill_stale_server`` to avoid
    touching state owned by a live sibling session.
    """
    pid = _slot_holder_pid(slot)
    return pid is not None and pid != os.getpid() and _is_pid_alive(pid)
