from __future__ import annotations
import atexit
import errno
import os
import re
import sys
import shutil
import socket
from pathlib import Path

from hutil.PySide import QtCore

from .paths import get_server_data_dir, to_vscode_path
from .process import _is_pid_alive

# ---------------------------------------------------------------------------
# CLI detection
# ---------------------------------------------------------------------------


def _find_code_cli() -> str | None:
    """Return path to the VS Code CLI, or None if not found."""
    env = os.environ.get('VSCODE_CLI_PATH')
    if env and Path(env).exists():
        return env

    found = shutil.which('code')
    if found:
        return found

    if sys.platform in ('win32', 'cygwin'):
        candidates = []
        local = os.environ.get('LOCALAPPDATA', '')
        prog = os.environ.get('ProgramFiles', '')
        if local:
            candidates.append(
                Path(local) / 'Programs' / 'Microsoft VS Code' / 'bin' / 'code.cmd'
            )
        if prog:
            candidates.append(
                Path(prog) / 'Microsoft VS Code' / 'bin' / 'code.cmd'
            )
        for c in candidates:
            if c.exists():
                return str(c)

    if sys.platform == 'darwin':
        mac = Path(
            '/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code'
        )
        if mac.exists():
            return str(mac)

    for snap in ['/snap/bin/code']:
        if Path(snap).exists():
            return snap

    return None


# A running VS Code's main process listens on the named pipe
# ``<sha256(user-data-dir)[:8]>-<version>-main-sock``; ``code <file>`` hands its
# arguments to that instance through it. serve-web creates no such pipe.
_VSCODE_MAIN_PIPE = re.compile(r'^[0-9a-f]{8}-.+-main-sock$')


def _vscode_is_running() -> bool:
    """Return True if a desktop VS Code instance is running.

    Mirrors VS Code's own single-instance check by looking for its main IPC
    pipe. Errs towards True: any VS Code-based editor's pipe counts, and
    anything that can't be checked (non-Windows, no pipe listing) returns True,
    so callers only open the file and never put a folder into the user's
    running VS Code.
    """
    if sys.platform != 'win32':
        return True
    try:
        pipes = os.listdir('\\\\.\\pipe\\')
    except OSError:
        return True
    return any(_VSCODE_MAIN_PIPE.match(p) for p in pipes)


_BASE_PORT = int(os.environ.get('APEXSCRIPT_PANEL_PORT', 30201))

# Pin serve-web to a known-good commit because newer serve-web builds
# (>= 1.120) silently fail to activate any user-installed extension —
# the panel-init / LSP / Pylance entries are listed in the cache as valid
# but the extension host never loads them. Pinning bypasses VS Code's
# CLI auto-update of serve-web and forces use of the cached 1.118.1 build.
#
# Override via APEXSCRIPT_PANEL_VSCODE_COMMIT to a different SHA if a
# newer working version is released; set to empty string to disable
# pinning entirely (let the VS Code CLI pick the latest).
_DEFAULT_PINNED_COMMIT = '034f571df509819cc10b0c8129f66ef77a542f0e'  # 1.118.1
_PINNED_COMMIT = os.environ.get(
    'APEXSCRIPT_PANEL_VSCODE_COMMIT', _DEFAULT_PINNED_COMMIT,
).strip()

# How long QProcess.stop() waits for a graceful shutdown before SIGKILL.
_TERMINATE_GRACE_MS = 3000

# How often we try a TCP connect to the server port as a fallback for the
# stdout "available at" detection. If serve-web ever changes its ready
# message the panel would otherwise hang at "Starting…" forever.
_READY_POLL_INTERVAL_MS = 250
_READY_POLL_CONNECT_TIMEOUT_S = 0.1


def _free_port(preferred: int) -> int:
    """Return preferred port if free, else a random free port.

    Using a stable port is critical: VS Code keys workspace trust to
    vscode-remote://127.0.0.1:{port}/…  A random port = new URI each
    session = trust prompt every time.
    """
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.bind(('127.0.0.1', preferred))
            return preferred
    except OSError:
        pass
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(('localhost', 0))
        return s.getsockname()[1]


# Serve-web emits these to stderr routinely; they are not actionable errors.
_NOISE_PATTERNS = (
    'Canceled: Canceled',
    'Failed snippets from folder',
    'Failed to resolve files at location',
    'Uncaught TypeError',
    'color: #f33',
    'color: #fc0',
    'color: blue',
    'DEP0040',
    'ExperimentalWarning',
    'PendingMigrationError',
    'navigator is now a global',
    'GitHubLoginFailed',
    'CodeExpectedError',
    '[Extension Host]',
    '[lifecycle]',
    'github.copilot',
)


def _is_vscode_noise(text: str) -> bool:
    return any(p in text for p in _NOISE_PATTERNS)


# ---------------------------------------------------------------------------
# VSCodeServer
# ---------------------------------------------------------------------------


class VSCodeServer(QtCore.QObject):
    ready = QtCore.Signal(int)   # emits port when server is ready
    error = QtCore.Signal(str)   # emits message on failure

    def __init__(self, parent=None):
        super().__init__(parent)
        self._process = QtCore.QProcess(self)
        self._process.readyReadStandardOutput.connect(self._on_stdout)
        self._process.readyReadStandardError.connect(self._on_stderr)
        self._process.errorOccurred.connect(self._on_error)
        self._port: int | None = None
        self._ready = False
        self._pid_file: Path | None = None
        self._ready_poll_timer = QtCore.QTimer(self)
        self._ready_poll_timer.setInterval(_READY_POLL_INTERVAL_MS)
        self._ready_poll_timer.timeout.connect(self._poll_port_ready)

    @property
    def port(self) -> int | None:
        return self._port

    @property
    def is_ready(self) -> bool:
        return self._ready

    @property
    def url(self) -> str | None:
        if self._port:
            return f'http://127.0.0.1:{self._port}'
        return None

    def start(self, preferred_port: int = _BASE_PORT, pid_file: Path | None = None,
              server_data_dir: Path | None = None):
        cli = _find_code_cli()
        if not cli:
            self.error.emit(
                'VS Code CLI not found. Install VS Code and ensure "code" is in PATH, '
                'or set the VSCODE_CLI_PATH environment variable.'
            )
            return

        self._port = _free_port(preferred_port)
        # Per-slot instance dir isolates settings/trust/extensions between
        # concurrent Houdini sessions; falls back to the shared root.
        base = server_data_dir if server_data_dir is not None else get_server_data_dir()
        data_dir = to_vscode_path(base)

        args = [
            'serve-web',
            '--host', '127.0.0.1',
            '--port', str(self._port),
            '--without-connection-token',
            '--accept-server-license-terms',
            '--server-data-dir', data_dir,
        ]
        # Pin serve-web build to a known-working commit (see _PINNED_COMMIT
        # comment above). Empty string disables pinning.
        if _PINNED_COMMIT:
            args.extend(['--commit-id', _PINNED_COMMIT])

        # Remove Houdini's Python env vars so extensions that spawn Python
        # (e.g. diagnostics companion) use their own stdlib instead of
        # Houdini's broken one (mismatched _sre module).
        env = QtCore.QProcessEnvironment.systemEnvironment()
        for var in ('PYTHONHOME', 'PYTHONPATH'):
            env.remove(var)
        self._process.setProcessEnvironment(env)

        # .cmd files (Windows batch) need cmd.exe /c to execute
        if sys.platform == 'cygwin' or cli.lower().endswith('.cmd'):
            self._process.setProgram('cmd.exe')
            self._process.setArguments(['/c', cli] + args)
        else:
            self._process.setProgram(cli)
            self._process.setArguments(args)

        self._pid_file = pid_file
        self._process.start()
        # Fallback ready detection: keep trying TCP connect to our port
        # until the stdout sniffer fires or the connect succeeds.
        self._ready_poll_timer.start()

    def stop(self):
        self._ready_poll_timer.stop()
        if self._process.state() != QtCore.QProcess.NotRunning:
            self._process.terminate()
            self._process.waitForFinished(_TERMINATE_GRACE_MS)
            if self._process.state() != QtCore.QProcess.NotRunning:
                self._process.kill()
        self._ready = False
        if self._pid_file is not None:
            try:
                self._pid_file.unlink(missing_ok=True)
            except Exception:
                pass
            self._pid_file = None

    def is_running(self) -> bool:
        return self._process.state() == QtCore.QProcess.Running

    def _emit_ready_once(self):
        """Mark the server ready, persist the OS pid, emit the signal.

        Idempotent — repeated calls (e.g. stdout match AND port-poll
        success) all collapse into one emission. Persisting the OS process
        ID lets the next session reclaim the preferred port instead of
        falling back to a random one (which would break the
        vscode-remote://… trust URI by changing the port number).
        """
        if self._ready:
            return
        self._ready = True
        self._ready_poll_timer.stop()
        self.ready.emit(self._port)
        if self._pid_file is not None:
            try:
                pid = self._process.processId()
                if pid:
                    self._pid_file.write_text(str(pid), encoding='utf-8')
            except Exception:
                pass

    def _poll_port_ready(self):
        """Try a short TCP connect to our port; emit ready if it succeeds.

        Backstop for the stdout 'available at' string match — if serve-web
        ever reworks that message we still detect readiness.
        """
        if self._ready or self._port is None:
            return
        if self._process.state() == QtCore.QProcess.NotRunning:
            self._ready_poll_timer.stop()
            return
        try:
            with socket.create_connection(
                ('127.0.0.1', self._port),
                timeout=_READY_POLL_CONNECT_TIMEOUT_S,
            ):
                pass
        except OSError:
            return
        self._emit_ready_once()

    def _on_stdout(self):
        text = bytes(self._process.readAllStandardOutput()).decode(
            'utf-8', errors='replace'
        )
        if not self._ready and 'available at' in text.lower():
            self._emit_ready_once()

    def _on_stderr(self):
        # Some serve-web versions print the ready message on stderr.
        # Stderr is otherwise intentionally swallowed — _NOISE_PATTERNS
        # already captures known harmless output and the user does not
        # want any panel-related prints in Houdini's console.
        text = bytes(self._process.readAllStandardError()).decode(
            'utf-8', errors='replace'
        )
        if not self._ready and 'available at' in text.lower():
            self._emit_ready_once()

    def _on_error(self, error):
        self.error.emit(f'VS Code process error: {error}')


# ---------------------------------------------------------------------------
# Per-panel workspace directory allocation
#
# Slot allocation is cross-process so multiple concurrent Houdini sessions
# never collide on the same port / workspace / signal files. Each slot is
# owned by exactly one Houdini PID at a time, marked by a lock file
# `.apex-slot-{slot}.lock` in the server data dir.
# ---------------------------------------------------------------------------

_MAX_SLOTS = 16
_my_slots: set[int] = set()  # slots this process owns; used by the atexit hook


def _slot_lock_path(slot: int) -> Path:
    return get_server_data_dir() / f'.apex-slot-{slot}.lock'


def _try_claim_slot(slot: int) -> bool:
    """Atomically claim a slot for this Houdini process.

    Uses O_CREAT|O_EXCL so two simultaneous Houdini launches can't both
    think they own the slot.  If the file already exists, returns True only
    if its holder PID is dead (stale lock — we take it over).
    """
    lock = _slot_lock_path(slot)
    flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY
    try:
        fd = os.open(str(lock), flags, 0o644)
        try:
            os.write(fd, str(os.getpid()).encode('utf-8'))
        finally:
            os.close(fd)
        return True
    except OSError as e:
        if e.errno != errno.EEXIST:
            return False

    # Lock exists — check if owner is alive
    try:
        holder = int(lock.read_text(encoding='utf-8').strip())
    except Exception:
        holder = 0
    if holder == os.getpid():
        return True
    if _is_pid_alive(holder):
        return False
    # Stale: overwrite with our PID
    try:
        lock.write_text(str(os.getpid()), encoding='utf-8')
        return True
    except Exception:
        return False


def release_slot(slot: int):
    """Release this process's claim on a slot.

    Called explicitly by panel.cleanup() on clean shutdown and by the
    atexit hook as a fallback for crash / force-kill.  Safe to call
    multiple times.
    """
    lock = _slot_lock_path(slot)
    try:
        holder = int(lock.read_text(encoding='utf-8').strip())
    except Exception:
        holder = 0
    if holder == os.getpid():
        try:
            lock.unlink(missing_ok=True)
        except Exception:
            pass
    _my_slots.discard(slot)


def _release_all_slots():
    for slot in list(_my_slots):
        release_slot(slot)


atexit.register(_release_all_slots)


def next_panel_slot() -> tuple[Path, int, int]:
    """Return (workspace_dir, port, slot) for a new panel instance.

    Each Houdini session gets a unique slot via a cross-process file lock.
    Slot N → port _BASE_PORT+N → workspace-N/.  Stable slot→port mapping
    means VS Code remembers workspace trust for each slot permanently after
    first acceptance.

    Falls back to a non-claimed slot if all _MAX_SLOTS are taken — the
    panel still works, just without slot-isolation guarantees.
    """
    for slot in range(_MAX_SLOTS):
        if _try_claim_slot(slot):
            _my_slots.add(slot)
            port = _BASE_PORT + slot
            d = get_server_data_dir() / f'workspace-{slot}'
            d.mkdir(parents=True, exist_ok=True)
            return d, port, slot
    # All slots taken by live siblings — fall back to slot 0 unclaimed.
    # User has 16+ concurrent Houdini sessions, an edge case.
    port = _BASE_PORT
    d = get_server_data_dir() / 'workspace-0'
    d.mkdir(parents=True, exist_ok=True)
    return d, port, 0
