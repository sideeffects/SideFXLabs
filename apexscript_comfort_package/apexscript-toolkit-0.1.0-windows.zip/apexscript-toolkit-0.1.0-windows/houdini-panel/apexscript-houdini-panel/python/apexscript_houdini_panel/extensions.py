"""VS Code extension lifecycle for the embedded serve-web data dir.

Handles three categories of extensions:

* **Side-loaded** — ``apexscript-panel-init`` (lives in this package's
  ``vscode-init-extension/`` dir) and ``apexscript-lsp`` (lives in the
  sibling ``apexscript-lsp-server/vscode-extension/`` dir). Copied into
  the serve-web extensions dir on every panel construction; registered
  in ``extensions.json`` with the right metadata; ``.obsolete`` entries
  scrubbed so VS Code doesn't skip them after a version bump.
* **Marketplace** — ``ms-python.python`` and ``ms-python.vscode-pylance``.
  Installed once via ``code --install-extension`` on first launch
  (marker file in the data dir).
* **Blocked** — ``github.copilot``, ``anthropic.claude-code``. Removed on
  every startup because they install themselves from the user's regular
  VS Code profile and break in serve-web (auth failures, noisy logs).

The ``pinned: False`` flag in :func:`_register_extension`'s metadata is
load-bearing: ``pinned: True`` together with ``source: 'resource'`` (no
gallery UUID) makes VS Code 1.118.1 silently filter the extension before
activation. See ``feedback_serve_web_pinning.md``.
"""
from __future__ import annotations
import json
import sys
import subprocess
from pathlib import Path

# get_server_data_dir / to_vscode_path lazy-imported inside functions so
# paths.py can re-export from this module without a circular load.

# ---------------------------------------------------------------------------
# Marketplace + blocked extension lists
# ---------------------------------------------------------------------------

# Marketplace extensions to install on first run.
_MARKETPLACE_EXTENSIONS = [
    'ms-python.python',
    'ms-python.vscode-pylance',
]

# Extensions that break in serve-web — remove them on startup.
# anthropic.claude-code is here because previous panel builds installed it as
# part of the now-removed "Claude split mode" integration; this cleans it up
# from existing user installs on first launch.
_BLOCKED_EXTENSION_PREFIXES = (
    'github.copilot',
    'anthropic.claude-code',
)


# ---------------------------------------------------------------------------
# Side-loaded extension install + registry maintenance
# ---------------------------------------------------------------------------


def _ext_root(data_dir: Path | None):
    """Return the ``extensions/`` dir for a serve-web data dir (per-slot
    ``instance-N`` dir, or the shared root as a fallback)."""
    from .paths import get_server_data_dir
    base = data_dir if data_dir is not None else get_server_data_dir()
    return base / 'extensions'


def _copy_local_extension(name: str, src: Path, data_dir: Path | None = None):
    """Copy a local extension into the serve-web extensions dir
    and register it in extensions.json so serve-web loads it.
    """
    import shutil
    if not src.is_dir():
        return
    ext_root = _ext_root(data_dir)
    ext_root.mkdir(parents=True, exist_ok=True)
    dst = ext_root / name
    src_mtime = max(f.stat().st_mtime for f in src.iterdir())
    if dst.is_dir():
        try:
            dst_mtime = max(f.stat().st_mtime for f in dst.iterdir())
            if dst_mtime >= src_mtime:
                _register_extension(ext_root, name, src)
                return
        except (ValueError, OSError):
            pass
    if dst.exists():
        shutil.rmtree(dst)
    shutil.copytree(src, dst)
    _register_extension(ext_root, name, src)


def _unobsolete_extension(ext_root: Path, ext_id: str):
    """Remove all ``.obsolete`` entries whose key starts with ``ext_id-``.

    VS Code maintains an ``extensions/.obsolete`` JSON file listing
    ``<publisher>.<name>-<version>`` entries it intends to skip / delete on
    next startup. When we rewrite our entry in ``extensions.json`` (e.g.
    because we bumped the version in package.json), VS Code's installer
    flags the old AND new versions of our side-loaded extension as obsolete
    — and from that point the extension never activates again.

    Stripping our IDs from ``.obsolete`` on every launch ensures the
    extension is loaded even if VS Code thought it should be skipped.
    """
    obsolete_file = ext_root / '.obsolete'
    if not obsolete_file.exists():
        return
    try:
        data = json.loads(obsolete_file.read_text(encoding='utf-8'))
    except Exception:
        return
    if not isinstance(data, dict):
        return
    prefix = ext_id + '-'
    keep = {k: v for k, v in data.items() if not k.startswith(prefix)}
    if len(keep) == len(data):
        return
    try:
        if keep:
            obsolete_file.write_text(json.dumps(keep), encoding='utf-8')
        else:
            obsolete_file.unlink()
    except Exception:
        pass


def _register_extension(ext_root: Path, name: str, src: Path):
    """Ensure the extension is listed in extensions.json.

    Replaces any existing entry so version bumps in package.json propagate
    into the registry on the next launch, then strips our entry from VS
    Code's ``.obsolete`` list so the extension actually gets activated.
    """
    from .paths import to_vscode_path
    registry_file = ext_root / 'extensions.json'
    registry = []
    if registry_file.exists():
        try:
            registry = json.loads(registry_file.read_text(encoding='utf-8'))
        except Exception:
            registry = []

    # Read version from package.json
    pkg_file = src / 'package.json'
    pkg = {}
    if pkg_file.exists():
        try:
            pkg = json.loads(pkg_file.read_text(encoding='utf-8'))
        except Exception:
            pass
    publisher = pkg.get('publisher', 'undefined_publisher')
    ext_name = pkg.get('name', name)
    version = pkg.get('version', '0.0.1')
    ext_id = f'{publisher}.{ext_name}'

    # Build the location path as VS Code expects it
    loc_path = to_vscode_path(ext_root / name)
    # Look up the previous entry (if any) so we can preserve its
    # installedTimestamp — VS Code uses installedTimestamp + obsolete state
    # to decide whether an entry is "stale" and worth marking obsolete.
    import time
    existing = next(
        (e for e in registry
         if e.get('identifier', {}).get('id') == ext_id),
        None,
    )
    installed_ts = None
    if existing is not None:
        installed_ts = (existing.get('metadata') or {}).get('installedTimestamp')
    if not installed_ts:
        installed_ts = int(time.time() * 1000)

    new_entry = {
        'identifier': {'id': ext_id},
        'version': version,
        'location': {
            '$mid': 1,
            'path': '/' + loc_path.lstrip('/'),
            'scheme': 'file',
        },
        'relativeLocation': name,
        'metadata': {
            'isApplicationScoped': False,
            'isMachineScoped': False,
            'isBuiltin': False,
            'installedTimestamp': installed_ts,
            # pinned:True together with source:'resource' (no gallery UUID)
            # makes VS Code 1.118.1 silently filter the extension before
            # activation — entries pass the scan, show isValid:true in
            # extensions.user.cache, but never reach _doActivateExtension.
            # Pylance & other gallery extensions use pinned:False; matching
            # that here restores activation. See feedback_serve_web_pinning.md.
            'pinned': False,
            'source': 'resource',
        },
    }
    # Drop any existing entry for this ID, then append the fresh one.
    registry = [e for e in registry
                if e.get('identifier', {}).get('id') != ext_id]
    registry.append(new_entry)
    registry_file.write_text(json.dumps(registry, indent=2), encoding='utf-8')

    # Make sure VS Code doesn't skip the extension because of a stale
    # .obsolete entry from a previous registry rewrite.
    _unobsolete_extension(ext_root, ext_id)


def ensure_init_extension(data_dir: Path | None = None):
    """Install the panel-init extension into serve-web's extensions dir."""
    src = Path(__file__).resolve().parent.parent.parent / 'vscode-init-extension'
    _copy_local_extension('apexscript-panel-init', src, data_dir)


def ensure_apexscript_extension(data_dir: Path | None = None):
    """Install the ApexScript LSP extension into serve-web's extensions dir."""
    src = Path(__file__).resolve().parent.parent.parent.parent / \
        'apexscript-lsp-server' / 'vscode-extension'
    _copy_local_extension('apexscript-lsp', src, data_dir)


# ---------------------------------------------------------------------------
# Blocked extension cleanup + marketplace install
# ---------------------------------------------------------------------------


def remove_blocked_extensions(data_dir: Path | None = None):
    """Remove extensions that are incompatible with serve-web (e.g. Copilot).

    These extensions install themselves from the user's regular VS Code profile
    but fail with authentication errors and noisy logs in the embedded panel.
    Removes both the directory and the extensions.json registry entry so VS Code
    does not try to load them at all.
    """
    import shutil
    ext_root = _ext_root(data_dir)
    if not ext_root.is_dir():
        return

    removed_names = set()
    for entry in list(ext_root.iterdir()):
        if any(entry.name.startswith(p) for p in _BLOCKED_EXTENSION_PREFIXES):
            shutil.rmtree(entry, ignore_errors=True)
            removed_names.add(entry.name)

    if not removed_names:
        return

    # Also remove from extensions.json registry
    registry_file = ext_root / 'extensions.json'
    if not registry_file.exists():
        return
    try:
        registry = json.loads(registry_file.read_text(encoding='utf-8'))
        registry = [
            e for e in registry
            if e.get('relativeLocation') not in removed_names
        ]
        registry_file.write_text(json.dumps(registry, indent=2), encoding='utf-8')
    except Exception:
        pass


def _template_dir():
    """Shared, slot-independent extension install used to seed each instance's
    ``extensions/`` dir — so Pylance is downloaded once per machine, not once
    per slot."""
    from .paths import get_server_data_dir
    return get_server_data_dir() / 'template'


def ensure_marketplace_extensions():
    """Install Python + Pylance from the marketplace once, into the shared
    template dir.

    Per-slot instances are seeded from this template by
    :func:`seed_instance_extensions`, so the (slow) download happens once per
    machine rather than once per slot. A marker file prevents re-running.

    For users upgrading from the old shared layout, an existing
    ``~/.vscode-serve-web/extensions`` install is migrated into the template
    with a local copy instead of re-downloading.
    """
    import shutil
    from .paths import get_server_data_dir, to_vscode_path
    from .vscode_server import _find_code_cli

    template = _template_dir()
    marker = template / '.marketplace-installed'
    if marker.exists():
        return
    template.mkdir(parents=True, exist_ok=True)
    template_ext = template / 'extensions'

    # Migrate a pre-existing shared-layout install rather than re-downloading.
    legacy_ext = get_server_data_dir() / 'extensions'
    legacy_marker = get_server_data_dir() / '.marketplace-installed'
    if legacy_marker.exists() and legacy_ext.is_dir() and not template_ext.exists():
        try:
            shutil.copytree(legacy_ext, template_ext)
            marker.write_text('done')
            return
        except Exception:
            pass

    cli = _find_code_cli()
    if not cli:
        return
    template_ext.mkdir(parents=True, exist_ok=True)
    ext_dir = to_vscode_path(template_ext)

    for ext_id in _MARKETPLACE_EXTENSIONS:
        try:
            cmd = [cli, '--extensions-dir', ext_dir,
                   '--install-extension', ext_id]
            if sys.platform == 'cygwin' or cli.lower().endswith('.cmd'):
                cmd = ['cmd.exe', '/c'] + cmd
            subprocess.run(cmd, timeout=120, capture_output=True)
        except Exception:
            pass

    marker.write_text('done')


def _rewrite_extension_locations(ext_root: Path):
    """Rebuild every ``extensions.json`` entry's absolute ``location.path`` to
    point at *ext_root*.

    VS Code stores absolute paths in ``extensions.json``, so a raw copy of the
    template would leave every entry pointing back at the template dir and the
    extensions would fail to load. Rebuild the path from each entry's
    ``relativeLocation`` (the folder name), preserving all other metadata
    (gallery UUID, ``pinned``/``source`` flags) exactly — Pylance's activation
    is sensitive to those fields, see ``feedback_serve_web_pinning.md``.
    """
    from .paths import to_vscode_path
    registry_file = ext_root / 'extensions.json'
    if not registry_file.exists():
        return
    try:
        registry = json.loads(registry_file.read_text(encoding='utf-8'))
    except Exception:
        return
    if not isinstance(registry, list):
        return
    changed = False
    for entry in registry:
        rel = entry.get('relativeLocation')
        loc = entry.get('location')
        if not rel or not isinstance(loc, dict):
            continue
        new_path = '/' + to_vscode_path(ext_root / rel).lstrip('/')
        if loc.get('path') != new_path:
            loc['path'] = new_path
            changed = True
    if changed:
        try:
            registry_file.write_text(json.dumps(registry, indent=2), encoding='utf-8')
        except Exception:
            pass


def seed_instance_extensions(data_dir: Path):
    """Seed a per-slot instance's ``extensions/`` from the shared template.

    Copies the template's extension folders + ``extensions.json`` on first use
    of the slot (one local copy), then rewrites the copied registry's absolute
    paths to this instance via :func:`_rewrite_extension_locations`.

    Idempotent: does nothing once the instance already has an ``extensions``
    dir (instance dirs persist across sessions). The side-loaded init + LSP
    extensions are (re-)installed on top by ``ensure_init_extension`` /
    ``ensure_apexscript_extension``.
    """
    import shutil
    template_ext = _template_dir() / 'extensions'
    inst_ext = _ext_root(data_dir)
    if inst_ext.exists():
        return  # already seeded / in use
    if not template_ext.is_dir():
        inst_ext.mkdir(parents=True, exist_ok=True)
        return
    try:
        shutil.copytree(template_ext, inst_ext)
    except Exception:
        inst_ext.mkdir(parents=True, exist_ok=True)
        return
    _rewrite_extension_locations(inst_ext)
