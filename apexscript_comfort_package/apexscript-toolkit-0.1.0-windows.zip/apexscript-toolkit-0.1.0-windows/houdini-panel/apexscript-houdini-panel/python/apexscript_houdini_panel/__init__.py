"""ApexScript Houdini Panel — VS Code editor embedded in a Python Panel."""
