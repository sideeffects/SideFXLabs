"""Path resolution + workspace / data-dir helpers.

This module is intentionally slim — it owns just the actual path-derivation
functions (``get_server_data_dir``, ``get_workspace_dir``, ``get_apex_file``,
``to_vscode_path``, ``find_stubs_path``, ``find_reference_path``,
``_find_system_python``).

The heavy machinery — process management, session cleanup, extension
lifecycle, VS Code settings/trust — lives in dedicated modules:

* :mod:`process` — PID/port liveness, kill helpers, slot-lock holders
* :mod:`cleanup` — session-start dead-slot wipe (``clear_stale_signals``)
* :mod:`extensions` — extension copy/register/block/marketplace
* :mod:`vscode_state` — settings tables + ``ensure_trust`` + version-change profile wipe

Everything is re-exported here for backwards compatibility with existing
``from .paths import ...`` callers. New code should import from the
target modules directly.
"""
from __future__ import annotations
import functools
import os
import shutil
import sys
import subprocess
from pathlib import Path

# Process-management helpers live in process.py; re-exported here so the
# historical ``from .paths import _is_pid_alive`` style imports keep working.
# process.py uses lazy imports for get_server_data_dir to avoid a cycle.
from .process import (  # noqa: F401
    _kill_pid,
    _pid_holding_port,
    _pid_holding_port_psutil,
    _pid_holding_port_native,
    kill_stale_server,
    _is_pid_alive,
    _slot_holder_pid,
    _slot_is_live_other,
)
# Session-start cleanup helpers live in cleanup.py; same re-export pattern.
# cleanup.py uses lazy imports for get_server_data_dir / get_workspace_dir.
from .cleanup import (  # noqa: F401
    _scrub_claude_leftovers,
    clear_stale_signals,
    clean_workspace,
)
# Extension lifecycle lives in extensions.py; same re-export pattern.
# extensions.py uses lazy imports for paths to avoid a cycle.
from .extensions import (  # noqa: F401
    _copy_local_extension,
    _unobsolete_extension,
    _register_extension,
    ensure_init_extension,
    ensure_apexscript_extension,
    remove_blocked_extensions,
    ensure_marketplace_extensions,
    seed_instance_extensions,
    _MARKETPLACE_EXTENSIONS,
    _BLOCKED_EXTENSION_PREFIXES,
)
# Settings, trust, version-change profile wipe live in vscode_state.py.
# vscode_state.py uses lazy imports for paths to avoid a cycle.
from .vscode_state import (  # noqa: F401
    _TRUST_SUPPRESSION,
    _EXTENSION_BEHAVIOUR,
    _WELCOME_SUPPRESSION,
    _VISUAL_CHROME,
    _UI_SETTINGS,
    _MACHINE_EXTENSION_KEYS,
    ensure_workspace,
    ensure_user_settings,
    ensure_workspace_trusted,
    ensure_machine_settings,
    ensure_trust,
    clear_webengine_profile_if_vscode_updated,
    reap_dead_webengine_profiles,
)


def get_workspace_dir() -> Path:
    """Stable workspace directory that persists across sessions.

    Using a fixed path means VS Code only needs to trust it once — subsequent
    sessions reuse the same path and the trust decision is remembered.
    """
    d = get_server_data_dir() / 'workspace'
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_server_data_dir() -> Path:
    """Persistent shared root for the panel's serve-web state.

    Holds cross-session, cross-slot state: the slot lock files, the ``.apex-*``
    signal/keys/marker files, the shared extension ``template/``, and the
    ``workspace-N/`` editor folders. Each concurrent session's *own* serve-web
    data dir (settings, trust DB, extensions) lives under a per-slot
    ``instance-N/`` subdirectory — see :func:`get_instance_data_dir`.

    On Cygwin, Path.home() returns /home/user (C:\\cygwin\\home\\user) but
    VS Code is a Windows process that uses USERPROFILE (C:\\Users\\user).
    We must use USERPROFILE so both Python and the VS Code extension agree
    on where the data lives.
    """
    userprofile = os.environ.get('USERPROFILE')
    if userprofile:
        # Works on both native Windows and Cygwin — Cygwin can read
        # Windows paths via /cygdrive/ transparently.
        d = Path(userprofile) / '.vscode-serve-web'
    else:
        d = Path.home() / '.vscode-serve-web'
    d.mkdir(parents=True, exist_ok=True)
    return d


def get_instance_data_dir(slot: int) -> Path:
    """Per-slot serve-web ``--server-data-dir``.

    ``serve-web`` bundles user settings, the workspace-trust ``state.vscdb``,
    and the ``extensions/`` registry all under a single ``--server-data-dir``
    (it has no ``--extensions-dir`` / ``--user-data-dir`` split). Concurrent
    servers on one such dir is unsupported and is what breaks a second Houdini
    session (trust-DB clobber, extensions.json read-modify-write races). Giving
    each slot its own instance dir isolates all of it.

    Keyed by the stable slot number and persisted across sessions (like the old
    shared ``data/``), so it is written/seeded once and reused. The pinned
    ``serve-web`` *binary* lives in the CLI cache, not here, so a per-slot data
    dir does not re-download serve-web.
    """
    d = get_server_data_dir() / f'instance-{slot}'
    d.mkdir(parents=True, exist_ok=True)
    return d



def get_apex_file(node_path: str, parm_name: str, workspace: Path | None = None,
                   hip_path: str = '') -> Path:
    """Temp .apex file for a node+parm pair, scoped to the hip file.

    If *hip_path* is provided (e.g. ``hou.hipFile.path()``), files are placed
    in a subdirectory named after the hip file so that identically-named nodes
    in different hip files never collide.

    If *workspace* is given (the per-panel workspace-N dir) the file is placed
    there so VS Code can open it.  Falls back to the legacy shared workspace.
    """
    safe = node_path.replace('/', '_').replace(':', '_').lstrip('_')
    ws = workspace if workspace is not None else get_workspace_dir()
    if hip_path:
        hip_stem = Path(hip_path).stem or 'untitled'
        sub = ws / hip_stem
        sub.mkdir(parents=True, exist_ok=True)
        return sub / f'{safe}__{parm_name}.apex'
    return ws / f'{safe}__{parm_name}.apex'


def to_vscode_path(path: Path) -> str:
    """Convert path to a string VS Code serve-web can use.
    On Cygwin, VS Code is a Windows process and needs Windows paths."""
    if sys.platform == 'cygwin':
        try:
            result = subprocess.check_output(
                ['cygpath', '-w', str(path)],
                stderr=subprocess.DEVNULL
            )
            return result.decode().strip().replace('\\', '/')
        except Exception:
            pass
    return str(path).replace('\\', '/')


@functools.lru_cache(maxsize=None)
def _find_system_python() -> str:
    """Find a system Python (not Houdini's) for the diagnostics companion.

    Houdini's bundled Python has mismatched C modules that crash on import.
    We need a standalone Python 3.10+ install. Each candidate must actually
    run: on Windows, ``python3`` / ``python`` on PATH are often the Microsoft
    Store aliases, which exist but only print "Python was not found". Returns
    '' if none runs, so the ApexScript extension detects one itself. Cached:
    ``ensure_workspace`` calls this on every bind.
    """
    candidates = []
    # Check common locations on Windows
    for name in ['python3', 'python']:
        found = shutil.which(name)
        if found and 'hfs' not in found.lower() and 'houdini' not in found.lower():
            candidates.append(found)
    # Explicit Windows paths
    local = os.environ.get('LOCALAPPDATA', '')
    if local:
        for ver in ['Python312', 'Python311', 'Python310']:
            p = Path(local) / 'Programs' / 'Python' / ver / 'python.exe'
            if p.exists():
                candidates.append(str(p))
    env = {k: v for k, v in os.environ.items()
           if k not in ('PYTHONHOME', 'PYTHONPATH')}
    for candidate in candidates:
        try:
            result = subprocess.run(
                [candidate, '--version'], capture_output=True, timeout=5, env=env,
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except (OSError, subprocess.SubprocessError):
            continue
        if result.returncode == 0:
            return to_vscode_path(candidate)
    return ''


def find_stubs_path() -> str | None:
    """Walk up from this file to find apexscript-stubs/ sibling, or use env var.

    Returns the PARENT of the apexscript-stubs directory as a Windows path.
    Pylance's python.analysis.stubPath expects the parent so it can discover
    the ``apexscript-stubs`` package (which has ``__init__.pyi``) inside it.
    This matches the convention used by the ApexScript VS Code extension.
    """
    env_path = os.environ.get('APEX_STUBS_PATH')
    if env_path:
        return env_path
    current = Path(__file__).resolve().parent
    for _ in range(8):
        candidate = current / 'apexscript-stubs'
        if candidate.is_dir():
            return to_vscode_path(current)
        current = current.parent
    return None


def find_reference_path() -> str | None:
    """Walk up from this file to find the apexscript-reference data dir.

    Looks for ``reference/apexscript-reference/metadata/api-cache/callbacks_cache.json``
    relative to the comfort package root.  The extension uses this for port
    completion and kwarg documentation.
    """
    env_path = os.environ.get('APEX_REFERENCE_PATH')
    if env_path:
        return env_path
    current = Path(__file__).resolve().parent
    for _ in range(8):
        candidate = current / 'reference' / 'apexscript-reference'
        cache = candidate / 'metadata' / 'api-cache' / 'callbacks_cache.json'
        if cache.is_file():
            return to_vscode_path(candidate)
        current = current.parent
    return None


# Settings, trust, extension lifecycle: all live in dedicated modules now
# — see the re-export shims at the top of this file.
