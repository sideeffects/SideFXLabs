from __future__ import annotations
import json as _json
import os
import subprocess
import sys
import threading

import hou
from hutil.PySide import QtCore, QtWidgets

from .vscode_server import VSCodeServer
from .file_sync import ParameterFileSync
from .paths import clear_stale_signals

APEX_SCRIPT_TYPE_PREFIXES = ('apex::script', 'apex::autorigcomponent')

# Timer intervals (milliseconds). Tuned by trial against Houdini's Qt event
# loop + Chromium's renderer; bumping them up is safe, bumping down may
# cause focus/mouse races on slower machines.
_FOCUS_AFTER_CLICK_MS = 400        # delay before refocusing webview after Parm/VS Code button click
_CLIPBOARD_SYNC_DELAY_MS = 300     # wait for the init extension to write .apex-clipboard
_FOCUS_RETRY_INTERVAL_MS = 500     # poll cadence while searching for Monaco's textarea
_FOCUS_RETRY_MAX_TICKS = 60        # gives up after _FOCUS_RETRY_MAX_TICKS * _FOCUS_RETRY_INTERVAL_MS (~30 s)
_MOUSE_RELEASE_RETRY_MS = 50       # poll cadence for "is the mouse button released yet?"

HAS_WEBENGINE = False
try:
    from hutil.PySide.QtWebEngineWidgets import QWebEngineView
    from hutil.PySide.QtWebEngineCore import (
        QWebEngineProfile, QWebEnginePage, QWebEngineScript,
    )
    HAS_WEBENGINE = True

    class _QuietPage(QWebEnginePage):
        """Suppresses VS Code serve-web console noise at the Qt level.

        VS Code uses console.error('%c ...', 'color: #f33') for all structured
        log output. The ``%c`` marker reliably identifies infrastructure noise
        vs actionable errors. Non-styled messages still print.
        """
        _SUPPRESS = (
            '%c',
            'color: #f33',
            'color: #fc0',
            'Canceled: Canceled',
            'Failed to resolve files at location',
            'Cannot read properties of null',
        )

        def javaScriptConsoleMessage(self, level, message, line_number, source):
            if any(p in message for p in self._SUPPRESS):
                return
            super().javaScriptConsoleMessage(level, message, line_number, source)

except Exception:
    pass


class _KeyProxy(QtWidgets.QLineEdit):
    """Invisible QLineEdit that captures keystrokes for the webview.

    Houdini's application-level event filter lets keyboard events through to
    recognised text-input widgets (QLineEdit, QTextEdit, etc.) but consumes
    them for everything else (viewport hotkeys).  QWebEngineView's internal
    render widget is not on the whitelist.

    This 1-pixel-tall QLineEdit sits below the webview in the layout.  When
    the webview area receives focus (detected via QApplication.focusChanged),
    focus is silently redirected to this proxy.  Houdini sees a QLineEdit with
    focus and lets keys through.

    Keystrokes are written as JSON to .apex-keys-{slot}.  The VS Code init
    extension watches this file and replays keystrokes via vscode.commands
    executeCommand('type', {text}) — the only reliable way to type into
    Monaco when the QWebEngineView doesn't have native OS keyboard focus.
    """

    def __init__(self, parent=None):
        super().__init__(parent)
        self._keys_file = None
        self._counter = 0
        # Auxiliary-input bridge state. VS Code's find/replace/rename/quick-input
        # widgets are real DOM <input> elements, not Monaco's canvas. The normal
        # `type` IPC targets the active *editor*, so it can't fill these. When one
        # of the opening commands fires we "arm" aux mode: subsequent keystrokes
        # are routed to the focused widget via runJavaScript DOM injection.
        # _aux_mode is only a hint — the injected JS reports whether an aux input
        # is actually focused, so a stale hint self-corrects on the next key.
        self._webview = None
        self._aux_mode = None       # None, or a tag from _AUX_OPEN
        self._aux_armed_ms = 0      # QDateTime ms when aux mode was last armed
        self.setFixedHeight(1)
        self.setStyleSheet('border:none; background:transparent; padding:0; margin:0;')
        self.setFocusPolicy(QtCore.Qt.StrongFocus)

    def setKeysFile(self, keys_file):
        self._keys_file = keys_file

    def setWebView(self, webview):
        self._webview = webview

    @staticmethod
    def _syncClipboard(data_dir):
        """Read .apex-clipboard written by the extension and set Qt clipboard."""
        clip_file = data_dir / '.apex-clipboard'
        try:
            text = clip_file.read_text(encoding='utf-8')
            if text:
                QtWidgets.QApplication.clipboard().setText(text)
        except Exception:
            pass

    # Map Qt special key codes to VS Code command names for the extension
    _SPECIAL_CMDS: dict = {
        0x01000000: 'Escape',    0x01000001: 'Tab',
        0x01000003: 'Backspace', 0x01000004: 'Enter',
        0x01000005: 'Enter',     0x01000007: 'Delete',
        0x01000012: 'ArrowLeft', 0x01000013: 'ArrowUp',
        0x01000014: 'ArrowRight',0x01000015: 'ArrowDown',
        0x01000010: 'Home',      0x01000011: 'End',
        0x01000016: 'PageUp',    0x01000017: 'PageDown',
        0x01000031: 'editor.action.rename',  # F2 — Rename Symbol
    }

    # Shift+navigation → selection commands
    _SHIFT_NAV: dict = {
        'ArrowUp': 'cursorUpSelect',       'ArrowDown': 'cursorDownSelect',
        'ArrowLeft': 'cursorLeftSelect',    'ArrowRight': 'cursorRightSelect',
        'Home': 'cursorHomeSelect',         'End': 'cursorEndSelect',
        'PageUp': 'cursorPageUpSelect',     'PageDown': 'cursorPageDownSelect',
    }

    # Ctrl+Shift+navigation → word-select / multi-cursor
    _CTRL_SHIFT_CMDS: dict = {
        0x01000013: 'editor.action.insertCursorAbove',  # Ctrl+Shift+Up
        0x01000015: 'editor.action.insertCursorBelow',  # Ctrl+Shift+Down
        0x01000012: 'cursorWordLeftSelect',              # Ctrl+Shift+Left
        0x01000014: 'cursorWordRightSelect',             # Ctrl+Shift+Right
        0x01000010: 'cursorTopSelect',                   # Ctrl+Shift+Home
        0x01000011: 'cursorBottomSelect',                # Ctrl+Shift+End
        0x46: 'workbench.action.findInFiles',            # Ctrl+Shift+F
        0x48: 'workbench.action.replaceInFiles',         # Ctrl+Shift+H
        0x50: 'workbench.action.showCommands',           # Ctrl+Shift+P (command palette)
    }

    # Ctrl+key → VS Code command mapping.
    # Ctrl+C/V/X are handled specially in _sendKey (Qt clipboard bridge).
    _CTRL_CMDS: dict = {
        0x53: 'workbench.action.files.save',       # Ctrl+S
        0x5a: 'undo',                               # Ctrl+Z
        0x59: 'redo',                               # Ctrl+Y
        0x41: 'editor.action.selectAll',             # Ctrl+A
        0x44: 'editor.action.addSelectionToNextFindMatch',  # Ctrl+D
        0x46: 'actions.find',                        # Ctrl+F — find widget
        0x48: 'editor.action.startFindReplaceAction',  # Ctrl+H — find & replace
        0x47: 'workbench.action.gotoLine',           # Ctrl+G — go to line
        0x50: 'workbench.action.quickOpen',          # Ctrl+P — quick open
        0x2f: 'editor.action.commentLine',           # Ctrl+/
        0x01000004: 'workbench.action.files.save',   # Ctrl+Enter → save
        0x01000005: 'workbench.action.files.save',   # Ctrl+Enter (numpad)
        0x01000012: 'cursorWordLeft',                # Ctrl+Left
        0x01000013: 'scrollLineUp',                  # Ctrl+Up
        0x01000014: 'cursorWordRight',               # Ctrl+Right
        0x01000015: 'scrollLineDown',                # Ctrl+Down
        0x01000010: 'cursorTop',                     # Ctrl+Home
        0x01000011: 'cursorBottom',                  # Ctrl+End
    }

    # Commands that open a DOM <input> widget inside the webview. After sending
    # one of these we arm aux mode with the listed tag. 'find' keeps the widget
    # open across keystrokes (Enter = next match); 'oneshot' closes on accept.
    _AUX_OPEN: dict = {
        'actions.find': 'find',
        'editor.action.startFindReplaceAction': 'find',
        'workbench.action.findInFiles': 'find',
        'workbench.action.replaceInFiles': 'find',
        'editor.action.rename': 'oneshot',
        'workbench.action.quickOpen': 'oneshot',
        'workbench.action.showCommands': 'oneshot',
        'workbench.action.gotoLine': 'oneshot',
    }

    # How long after arming we keep retrying a keystroke while the widget is
    # still opening (it takes a frame or two for the input to appear + focus).
    _AUX_GRACE_MS = 600

    def keyPressEvent(self, event):
        if self._keys_file is not None:
            self._sendKey(event)
        self.clear()
        event.accept()

    def keyReleaseEvent(self, event):
        event.accept()

    def _sendKey(self, event):
        """Route a keystroke either to the editor (file IPC) or, when an
        auxiliary widget is open, to that widget's DOM input (runJavaScript)."""
        d = {
            'key': int(event.key()),
            'text': event.text(),
            'ctrl': bool(event.modifiers() & QtCore.Qt.ControlModifier),
            'shift': bool(event.modifiers() & QtCore.Qt.ShiftModifier),
        }
        if self._aux_mode:
            self._sendAuxKey(d)
            return
        entry = self._editorEntry(d)
        if entry is None:
            return
        self._writeEntry(entry)
        self._armIfOpening(entry)

    def _editorEntry(self, d):
        """Build the {text|cmd} entry for the active *editor* (no widget open).

        Returns the entry dict, or None if the key maps to nothing. Ctrl+C/X
        additionally schedule a Qt-clipboard sync as a side effect (unchanged).
        """
        key, text, ctrl, shift = d['key'], d['text'], d['ctrl'], d['shift']
        if ctrl:
            # Ctrl+V (paste): read Qt system clipboard and send as typed text.
            if key == 0x56:  # Ctrl+V
                clip = QtWidgets.QApplication.clipboard()
                clip_text = clip.text() if clip else ''
                return {'text': clip_text} if clip_text else None
            if key in (0x43, 0x58):  # Ctrl+C / Ctrl+X — copy/cut
                cmd = ('editor.action.clipboardCopyAction' if key == 0x43
                       else 'editor.action.clipboardCutAction')
                if self._keys_file is not None:
                    data_dir = self._keys_file.parent
                    QtCore.QTimer.singleShot(
                        _CLIPBOARD_SYNC_DELAY_MS,
                        lambda dd=data_dir: self._syncClipboard(dd),
                    )
                return {'cmd': cmd}
            if shift:
                # Ctrl+Shift combos (multi-cursor, word-select, search-in-files)
                cmd = self._CTRL_SHIFT_CMDS.get(key) or self._CTRL_CMDS.get(key)
                return {'cmd': cmd} if cmd else None
            cmd = self._CTRL_CMDS.get(key)
            return {'cmd': cmd} if cmd else None
        if key in self._SPECIAL_CMDS:
            base = self._SPECIAL_CMDS[key]
            if shift and base in self._SHIFT_NAV:
                return {'cmd': self._SHIFT_NAV[base]}
            if base == 'Enter':
                return {'text': '\n'}
            if base == 'Tab':
                return {'cmd': 'Tab'}
            return {'cmd': base}
        if text and len(text) == 1 and ord(text) >= 32:
            return {'text': text}
        return None

    def _writeEntry(self, entry):
        """Write one entry to the keys file for the extension to replay."""
        if self._keys_file is None or entry is None:
            return
        # Each write includes a unique counter so fs.watch always fires.
        self._counter += 1
        payload = _json.dumps([entry, {'_seq': self._counter}])
        try:
            self._keys_file.write_text(payload, encoding='utf-8')
        except Exception:
            pass

    def _armIfOpening(self, entry):
        """If we just sent a widget-opening command, arm aux mode."""
        tag = self._AUX_OPEN.get(entry.get('cmd')) if entry else None
        if tag:
            self._aux_mode = tag
            self._aux_armed_ms = QtCore.QDateTime.currentMSecsSinceEpoch()

    # ------------------------------------------------------------------
    # Auxiliary-input bridge (find / replace / rename / command palette)
    # ------------------------------------------------------------------

    def _runJSAux(self, js, cb=None):
        page = self._webview.page() if self._webview is not None else None
        if page is None:
            if cb:
                cb(None)
            return
        if cb is None:
            page.runJavaScript(js)
        else:
            page.runJavaScript(js, cb)

    def _sendAuxKey(self, d, allow_retry=True):
        """Route a keystroke to the focused VS Code DOM input widget."""
        key, text, ctrl, shift = d['key'], d['text'], d['ctrl'], d['shift']

        if key == 0x01000000:  # Escape — cancel/close the widget
            self._aux_mode = None
            self._runJSAux("window.__apexAuxKey&&__apexAuxKey('Escape','Escape',27,false)")
            self._writeEntry({'cmd': 'Escape'})  # extension also closes find widget
            return

        if key in (0x01000004, 0x01000005):  # Enter
            self._enterInAux(shift)
            return

        if key == 0x56 and ctrl:  # Ctrl+V — paste into the widget input
            clip = QtWidgets.QApplication.clipboard()
            t = clip.text() if clip else ''
            if t:
                self._auxJSWithFallback(
                    "window.__apexAuxText&&__apexAuxText(%s)" % _json.dumps(t),
                    d, allow_retry)
            return

        if ctrl and key == 0x41:  # Ctrl+A — select all in the input
            self._auxJSWithFallback(
                "window.__apexAuxEdit&&__apexAuxEdit('selectall')", d, allow_retry)
            return

        if key == 0x01000001 and not ctrl:  # Tab — move between find/replace fields
            sh = 'true' if shift else 'false'
            self._runJSAux(
                "window.__apexAuxKey&&__apexAuxKey('Tab','Tab',9,%s)" % sh)
            return

        _EDIT = {
            0x01000003: 'backspace', 0x01000007: 'delete',
            0x01000012: 'left',      0x01000014: 'right',
            0x01000010: 'home',      0x01000011: 'end',
        }
        if not ctrl and key in _EDIT:
            self._auxJSWithFallback(
                "window.__apexAuxEdit&&__apexAuxEdit('%s')" % _EDIT[key], d, allow_retry)
            return

        if not ctrl and text and len(text) == 1 and ord(text) >= 32:  # printable
            self._auxJSWithFallback(
                "window.__apexAuxText&&__apexAuxText(%s)" % _json.dumps(text),
                d, allow_retry)
            return

        # Anything else (Ctrl+S, reopening find, etc.): treat as an editor key.
        # Don't disarm — the widget may still be open; the editor command is
        # focus-independent and harmless.
        entry = self._editorEntry(d)
        if entry is not None:
            self._writeEntry(entry)
            self._armIfOpening(entry)

    def _auxJSWithFallback(self, js, d, allow_retry):
        """Run an aux DOM-injection call; if no aux input was focused, retry
        once (the widget may still be opening) then fall back to the editor."""
        def cb(handled):
            if handled:
                return
            within_grace = (
                QtCore.QDateTime.currentMSecsSinceEpoch() - self._aux_armed_ms
                < self._AUX_GRACE_MS)
            if allow_retry and self._aux_mode and within_grace:
                QtCore.QTimer.singleShot(
                    60, lambda: self._sendAuxKey(d, allow_retry=False))
                return
            # Widget isn't there — disarm and treat the key as an editor key.
            self._aux_mode = None
            entry = self._editorEntry(d)
            if entry is not None:
                self._writeEntry(entry)
        self._runJSAux(js, cb)

    def _enterInAux(self, shift):
        """Enter inside an aux widget depends on which input has focus."""
        def on_role(role):
            if not role:
                # Not actually in an aux input — disarm, send a real newline.
                self._aux_mode = None
                self._writeEntry({'text': '\n'})
                return
            if role in ('find', 'search'):
                cmd = ('editor.action.previousMatchFindAction' if shift
                       else 'editor.action.nextMatchFindAction')
                self._writeEntry({'cmd': cmd})           # stays open
            elif role == 'replace':
                self._writeEntry({'cmd': 'editor.action.replaceOne'})
            else:  # rename / quickinput — accept and close
                self._runJSAux(
                    "window.__apexAuxKey&&__apexAuxKey('Enter','Enter',13,false)")
                self._aux_mode = None
        self._runJSAux("window.__apexAuxRole?__apexAuxRole():''", on_role)


_slot_webprofiles = {}   # slot -> QWebEngineProfile (per-process cache)

# Auto-accept the workspace-trust modal. In `code serve-web` the workbench
# reads trust from BROWSER storage, not the server's settings.json, so our
# Machine/User/state.vscdb writes cannot suppress the client modal — this is
# an upstream "as-designed" limitation (microsoft/vscode#210965). Since we own
# the embedding webview, we click the "trust" button ourselves. Runs at
# document-creation so it survives workspace-folder-add reloads, and a
# MutationObserver catches the modal whenever it appears. Pinned to serve-web
# 1.118.1, so the dialog DOM/labels are stable (revisit if the pin changes).
#
# After clicking, we reload the webview ONCE: clicking the modal mid-load leaves
# Qt focus off the key-proxy (Houdini then eats keystrokes — the "accepted trust
# but can't type until restart" bug). A reload re-runs the clean load path
# (loadFinished -> _giveFocusToWebView) with the grant now cached (no modal), so
# focus lands correctly — same effect as a Houdini restart, automatic + instant.
# A sessionStorage counter caps reloads so a non-persisting grant can't loop.
_TRUST_AUTOACCEPT_JS = r"""
(function() {
    var done = false, last = 0, obs = null;
    function isTrustBtn(el) {
        var t = (el.textContent || '').trim().toLowerCase();
        if (!t || t.indexOf('trust') < 0) return false;
        // Never click the negative choice or a "manage/configure/learn" button.
        if (t.indexOf("don't") >= 0 || t.indexOf('do not') >= 0
            || t.indexOf('no,') >= 0 || t.indexOf('manage') >= 0
            || t.indexOf('configure') >= 0 || t.indexOf('learn') >= 0) return false;
        return true;  // "Yes, I trust the authors" / "Trust Folder" / "Trust"
    }
    function reloadOnce() {
        var n = 0;
        try { n = parseInt(sessionStorage.getItem('__apexTrustReloads') || '0', 10); } catch (e) {}
        if (n >= 2) return;   // safety cap: never loop if the grant won't persist
        try { sessionStorage.setItem('__apexTrustReloads', String(n + 1)); } catch (e) {}
        setTimeout(function() { try { location.reload(); } catch (e) {} }, 600);
    }
    function tryAccept() {
        if (done) return;
        var now = Date.now();
        if (now - last < 150) return;   // throttle: VS Code churns the DOM a lot
        last = now;
        try {
            // Trust prompt can render as a modal dialog OR (on file-open) via a
            // different container — scan any dialog-ish box, then fall back to
            // the whole document (the strict isTrustBtn gate keeps this safe).
            var scopes = document.querySelectorAll(
                '.monaco-dialog-box, .monaco-dialog, [role="dialog"], .dialog-modal-block');
            var containers = scopes.length ? scopes : [document];
            for (var s = 0; s < containers.length; s++) {
                var btns = containers[s].querySelectorAll(
                    'a.monaco-button, button.monaco-button, .monaco-button, '
                    + 'a.monaco-text-button, button, a[role="button"]');
                for (var i = 0; i < btns.length; i++) {
                    if (isTrustBtn(btns[i])) {
                        btns[i].click();
                        done = true;                 // grant now persists in the profile
                        if (obs) obs.disconnect();   // stop watching — job done
                        reloadOnce();                // reset focus via a clean reload
                        return;
                    }
                }
            }
        } catch (e) {}
    }
    try {
        obs = new MutationObserver(tryAccept);
        obs.observe(document.documentElement, {childList: true, subtree: true});
    } catch (e) {}
    tryAccept();
})();
"""


def _profile_name_for_slot(slot: int) -> str:
    """QtWebEngine profile name for a slot.

    Keyed by SLOT (not PID) so the on-disk profile dir is:
      * stable across launches  → the client-side workspace-trust grant
        (IndexedDB ``uriTrustInfo``) persists after the user accepts it once,
        which is the ONLY thing that reliably suppresses the workbench trust
        modal in serve-web (server-side Machine/User settings do NOT — confirmed
        empirically; a fresh profile re-prompts even single-session);
      * distinct per slot        → two concurrent Houdini sessions get separate
        profile dirs and never contend for the same Chromium profile lock (that
        contention was what broke the 2nd session's webview);
      * port-stable (port = 30201 + slot) → the port-keyed grant stays valid.

    Slot 0 keeps the historical unsuffixed name so existing single-session
    users keep their cached grant (no re-trust). Slots >0 (concurrent sessions)
    get their own dir and need a one-time accept that then persists.
    """
    return 'apexscript_vscode' if slot == 0 else f'apexscript_vscode_slot{slot}'


def _get_slot_profile(slot: int, theme_js: str):
    """Return the QWebEngineProfile for *slot*, created once per process.

    Cached per slot so multiple panels for the same slot in one process don't
    double-lock the on-disk dir. The cache is a plain module dict: safe_reload
    resetting it is harmless — a fresh profile object simply re-wraps the same
    persistent on-disk dir (this mirrors the old singleton's lifecycle).
    """
    if not HAS_WEBENGINE:
        return None
    profile = _slot_webprofiles.get(slot)
    if profile is None:
        profile = QWebEngineProfile(_profile_name_for_slot(slot), None)

        def _mk_script(name, source):
            s = QWebEngineScript()
            s.setName(name)
            s.setInjectionPoint(getattr(
                QWebEngineScript, 'DocumentCreation',
                QWebEngineScript.InjectionPoint.DocumentCreation))
            s.setWorldId(getattr(
                QWebEngineScript, 'MainWorld',
                QWebEngineScript.ScriptWorldId.MainWorld))
            s.setRunsOnSubFrames(False)
            s.setSourceCode(source)
            return s

        profile.scripts().insert(_mk_script('apexscript-dark-theme', theme_js))
        # Auto-accept the workspace-trust modal (serve-web can't be told to
        # trust via settings — see _TRUST_AUTOACCEPT_JS).
        profile.scripts().insert(
            _mk_script('apexscript-trust-autoaccept', _TRUST_AUTOACCEPT_JS))
        _slot_webprofiles[slot] = profile
    return profile


class ApexScriptEditorPanel(QtWidgets.QWidget):
    """Panel with Parm and VS Code modes.

    VS Code mode embeds ``code serve-web`` via QWebEngineView.
    Falls back to opening the system browser if WebEngine is unavailable.
    """

    MODE_PARM = 0
    MODE_VSCODE = 1

    def __init__(self, parent=None):
        super().__init__(parent)
        self._node: hou.Node | None = None
        self._sync = ParameterFileSync(self)
        self._mode = self.MODE_PARM
        self._ws_vscode_path = None
        self._vscode_inited = False
        # Claim this panel's slot up front (via the on-disk cross-process lock)
        # so the webview profile in _setupUI can be keyed by it — a per-slot
        # profile persists the client trust grant AND avoids concurrent-session
        # profile-lock contention. _initVSCode reuses these; released in cleanup.
        from .vscode_server import next_panel_slot
        self._ws, self._port, self._slot = next_panel_slot()
        # Session-start cleanup (gated by per-PID .apex-session-{pid} so it runs
        # once per Houdini process; never destructive on reopen). It wipes our
        # slot's leftover .apex files, so it must run before the first bind:
        # Houdini binds right after onCreateInterface, before _initVSCode, and
        # running it there deleted the file that bind had just written.
        clear_stale_signals()
        # Configure the file-sync with the slot + per-slot workspace NOW, not in
        # the deferred _initVSCode. Houdini calls onNodePathChanged -> bind()
        # synchronously right after onCreateInterface — i.e. BEFORE the
        # singleShot(0, _initVSCode) fires. If configure() were still pending at
        # that point, the first bind() would see _workspace=None and fall back
        # to the legacy shared workspace (get_apex_file(workspace=None)),
        # writing the base file to the wrong directory. The embedded editor
        # self-healed via a second _rebindCurrent(), but "Open External" did
        # not, so it opened a nonexistent/empty file. Configuring here closes
        # that window for every code path.
        self._sync.configure(self._slot, self._ws)
        # Each panel gets its own server instance (independent port + workspace).
        self._server = VSCodeServer()
        self._server.ready.connect(self._onServerReady)
        self._server.error.connect(self._onServerError)
        # Retry timer: polls Monaco's textarea every 500 ms until focus lands.
        # Needed because Monaco may not exist in the DOM when loadFinished fires
        # (e.g. trust dialog, extension loading, or workspace reload delay).
        self._focus_retry_timer = QtCore.QTimer(self)
        self._focus_retry_timer.setInterval(_FOCUS_RETRY_INTERVAL_MS)
        self._focus_retry_timer.timeout.connect(self._retryFocusMonaco)
        self._focus_retry_count = 0
        self._setupUI()

        # Start VS Code server eagerly so it's ready when the user switches modes
        QtCore.QTimer.singleShot(0, self._initVSCode)

    # ------------------------------------------------------------------
    # UI Setup
    # ------------------------------------------------------------------

    def _setupUI(self):
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Toolbar
        toolbar = QtWidgets.QWidget()
        tl = QtWidgets.QHBoxLayout(toolbar)
        tl.setContentsMargins(4, 2, 4, 2)

        # The parm picker is hidden: the panel always edits `snippet`, which
        # _bindBestParm picks first (apex::script and apex::autorigcomponent
        # both have it). The combo still holds the bound parm name.
        self._parm_combo = QtWidgets.QComboBox()
        self._parm_combo.setMinimumWidth(120)
        self._parm_combo.currentTextChanged.connect(self._onParmSelected)
        parm_label = QtWidgets.QLabel('Parameter:')
        tl.addWidget(parm_label)
        tl.addWidget(self._parm_combo)

        sep = QtWidgets.QFrame()
        sep.setFrameShape(QtWidgets.QFrame.VLine)
        tl.addWidget(sep)
        for w in (parm_label, self._parm_combo, sep):
            w.hide()

        self._parm_btn = QtWidgets.QToolButton()
        self._parm_btn.setText('Parm')
        self._parm_btn.setCheckable(True)
        self._parm_btn.setChecked(True)
        self._parm_btn.setToolTip('Parameter editor')
        self._parm_btn.clicked.connect(lambda: self._setMode(self.MODE_PARM))
        tl.addWidget(self._parm_btn)
        # Hidden: with the VS Code button gone, Parm is the only mode.
        self._parm_btn.hide()

        self._vscode_btn = QtWidgets.QToolButton()
        self._vscode_btn.setText('VS Code')
        self._vscode_btn.setCheckable(True)
        self._vscode_btn.setToolTip(
            'Embedded VS Code (serve-web)' if HAS_WEBENGINE
            else 'Open VS Code in browser (no WebEngine)')
        self._vscode_btn.clicked.connect(lambda: self._setMode(self.MODE_VSCODE))
        tl.addWidget(self._vscode_btn)
        # Hidden: the embedded VS Code view is not offered in the toolbar.
        self._vscode_btn.hide()

        # A push button, not a flat tool button: it is the toolbar's only
        # visible action and should read as one.
        self._ext_btn = QtWidgets.QPushButton('Edit in VS Code')
        self._ext_btn.setIcon(hou.qt.Icon('BUTTONS_edit'))
        self._ext_btn.setToolTip(
            'Open the snippet in VS Code; saving there updates the node')
        self._ext_btn.clicked.connect(self._openExternal)
        # Added after the status label below, at the right end of the toolbar.

        self._reload_btn = QtWidgets.QToolButton()
        self._reload_btn.setText('↻')  # ↻ refresh glyph
        self._reload_btn.setToolTip(
            'Reload the embedded VS Code view (resets focus / recovers a stuck view)')
        self._reload_btn.clicked.connect(self._reloadVSCode)
        tl.addWidget(self._reload_btn)
        # Hidden: it only reloads the embedded VS Code view, which is hidden.
        self._reload_btn.hide()

        tl.addStretch()
        self._status = QtWidgets.QLabel()
        self._status.setAlignment(QtCore.Qt.AlignRight | QtCore.Qt.AlignVCenter)
        tl.addWidget(self._status)
        tl.addWidget(self._ext_btn)
        layout.addWidget(toolbar)

        # Content area
        self._content = QtWidgets.QWidget()
        content_layout = QtWidgets.QVBoxLayout(self._content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(0)

        self._parmdialog = hou.qt.ParmDialog(None, False, True)
        content_layout.addWidget(self._parmdialog)

        # VS Code embedded web view
        self._webview = None
        self._css_injected = False
        self._key_proxy = None
        if HAS_WEBENGINE:
            # Per-slot profile: persistent (trust grant survives) and unique per
            # slot (no concurrent-session profile-lock contention). See
            # _profile_name_for_slot.
            profile = _get_slot_profile(self._slot, self._THEME_PRELOAD_JS)

            self._webview = QWebEngineView()
            self._webview.setFocusPolicy(QtCore.Qt.StrongFocus)
            page = _QuietPage(profile, self._webview)
            self._webview.setPage(page)
            self._webview.loadFinished.connect(self._onWebViewLoaded)
            content_layout.addWidget(self._webview)
            self._webview.hide()

            # Invisible QLineEdit that captures keyboard input.
            # Houdini's event filter recognises QLineEdit as a text-input
            # widget and lets key events through.  Focus is redirected here
            # from the webview via _onFocusChanged.
            self._key_proxy = _KeyProxy(self._content)
            self._key_proxy.setWebView(self._webview)
            # Keys file is set later in _initVSCode once we know the slot
            content_layout.addWidget(self._key_proxy)
            self._key_proxy.hide()

            # When this panel's webview gains focus, re-send the open signal
            # so VS Code switches to this panel's file. This handles the case
            # where two panels are open for different nodes simultaneously.
            QtWidgets.QApplication.instance().focusChanged.connect(
                self._onFocusChanged
            )

        layout.addWidget(self._content, 1)

    # ------------------------------------------------------------------
    # Mode switching
    # ------------------------------------------------------------------

    def _setMode(self, mode: int):
        # If WebEngine isn't available, fall back to browser for VS Code mode
        if mode == self.MODE_VSCODE and not HAS_WEBENGINE:
            self._openVSCodeWeb()
            # Keep current mode — don't switch visually
            self._vscode_btn.setChecked(False)
            return

        self._mode = mode
        self._parm_btn.setChecked(mode == self.MODE_PARM)
        self._vscode_btn.setChecked(mode == self.MODE_VSCODE)

        self._parmdialog.setVisible(mode == self.MODE_PARM)
        if self._webview is not None:
            self._webview.setVisible(mode == self.MODE_VSCODE)
            self._key_proxy.setVisible(mode == self.MODE_VSCODE)
        if mode == self.MODE_VSCODE:
            self._ensureVSCodeLoaded()
            # Delayed Qt-level focus — the button click steals focus from the webview
            QtCore.QTimer.singleShot(_FOCUS_AFTER_CLICK_MS, self._giveFocusToWebView)
            # Retry Monaco DOM focus until the textarea actually exists
            self._startFocusRetry()

    # ------------------------------------------------------------------
    # Pypanel lifecycle
    # ------------------------------------------------------------------

    def activate(self, pane_tab=None):
        # When this panel gains focus, re-send the open signal so VS Code
        # switches to this panel's file (multiple panels share one server).
        if self._mode == self.MODE_VSCODE:
            self._sync.write_open_signal()

    def deactivate(self):
        pass

    def cleanup(self):
        from .vscode_server import release_slot
        slot = self._slot
        self._sync.unbind()
        self._focus_retry_timer.stop()
        # Drop the app-wide focus hook so we don't leak a connection to a
        # destroyed widget across panel reopens (safe_reload rebuilds the panel
        # on every tab reopen).
        if self._webview is not None:
            try:
                QtWidgets.QApplication.instance().focusChanged.disconnect(
                    self._onFocusChanged)
            except (RuntimeError, TypeError):
                pass
        self._server.stop()
        self._server = None
        release_slot(slot)

    def nodePathChanged(self, node: hou.Node | None):
        if node is not None and not any(
                node.type().name().startswith(p) for p in APEX_SCRIPT_TYPE_PREFIXES):
            node = None
        self._node = node
        self._parmdialog.setNode(node)
        self._populateParmCombo()
        if node:
            self._bindBestParm()
        else:
            self._sync.unbind()

    # ------------------------------------------------------------------
    # Parameter handling
    # ------------------------------------------------------------------

    def _populateParmCombo(self):
        self._parm_combo.blockSignals(True)
        self._parm_combo.clear()
        if self._node:
            for parm in self._node.parms():
                if parm.parmTemplate().type() == hou.parmTemplateType.String:
                    self._parm_combo.addItem(parm.name())
        self._parm_combo.blockSignals(False)

    def _bindBestParm(self):
        """Pick the preferred parameter for the current node and bind it.

        Always calls ``_rebindCurrent`` after selecting, so switching between
        two nodes that share the same parm name still triggers a fresh
        bind (otherwise ``currentTextChanged`` doesn't fire and the panel
        stays pointed at the previous node's file).
        """
        target_idx = -1
        for preferred in ('snippet', 'script', 'code', 'expression'):
            idx = self._parm_combo.findText(preferred)
            if idx >= 0:
                target_idx = idx
                break
        if target_idx < 0 and self._parm_combo.count() > 0:
            target_idx = 0
        if target_idx < 0:
            return
        # blockSignals so we don't double-bind via _onParmSelected when the
        # index actually changes — we always do the bind explicitly below.
        self._parm_combo.blockSignals(True)
        self._parm_combo.setCurrentIndex(target_idx)
        self._parm_combo.blockSignals(False)
        self._rebindCurrent()

    def _rebindCurrent(self):
        """(Re-)bind the file-sync to the currently-selected (node, parm)."""
        if not self._node:
            return
        parm_name = self._parm_combo.currentText()
        if not parm_name:
            return
        self._sync.bind(self._node, parm_name, hip_path=hou.hipFile.path())

    def _onParmSelected(self, parm_name: str):
        # User picked a parm manually from the combo. Programmatic changes
        # go through _bindBestParm + _rebindCurrent, which block signals to
        # avoid hitting this path twice.
        self._rebindCurrent()

    # ------------------------------------------------------------------
    # VS Code (embedded WebEngine or browser fallback)
    # ------------------------------------------------------------------

    def _initVSCode(self):
        """Run VS Code setup and start the server in the background.
        Called once at panel creation so the server is ready before the
        user switches to VS Code mode.

        Each panel owns one serve-web bound to its per-slot instance dir
        (settings / trust / extensions). serve-web is stopped and the slot
        released in cleanup() — no cross-reopen server reuse (that made the
        slot bookkeeping depend on module state that safe_reload wipes).
        """
        if self._vscode_inited:
            return  # already set up (singleShot + _ensureVSCodeLoaded both call this)
        self._vscode_inited = True
        from .paths import (ensure_workspace, ensure_user_settings,
                            ensure_trust,
                            ensure_init_extension, ensure_apexscript_extension,
                            ensure_marketplace_extensions, seed_instance_extensions,
                            remove_blocked_extensions, to_vscode_path,
                            kill_stale_server,
                            get_server_data_dir, get_instance_data_dir)
        # Slot/workspace/port were claimed in __init__ (so the profile could be
        # keyed by slot); reuse them here — do NOT re-allocate.
        ws, port, slot = self._ws, self._port, self._slot
        instance_dir = get_instance_data_dir(slot)
        # The session-start cleanup runs in __init__, before the first bind.
        # Do NOT add a QtWebEngine IndexedDB wipe here — that storage holds VS
        # Code's workspace-trust grant (see feedback_webview_indexeddb_clear.md).
        # Kill any stale serve-web from a previous session before it can hold
        # the preferred port (a stale holder forces _free_port() to a random
        # port, changing the vscode-remote:// URI and re-triggering trust).
        kill_stale_server(slot, port=port)
        pid_file = get_server_data_dir() / f'.apex-server-pid-{slot}'
        ensure_workspace(ws)
        # Marketplace install lands in the shared template once; seed this
        # slot's own instance dir from it before writing per-instance
        # settings / trust / extensions (all keyed to instance_dir so two
        # concurrent Houdini sessions never share a serve-web data dir).
        ensure_marketplace_extensions()
        seed_instance_extensions(instance_dir)
        remove_blocked_extensions(instance_dir)
        ensure_user_settings(instance_dir)
        self._ws_vscode_path = to_vscode_path(ws)
        # ensure_trust = Machine settings + state.vscdb pre-trust write.
        # See its docstring for the full 4-layer trust apparatus.
        ensure_trust(self._ws_vscode_path, port, instance_dir)
        ensure_init_extension(instance_dir)
        ensure_apexscript_extension(instance_dir)
        self._sync.configure(slot, ws)
        # Tell the key proxy where to write keystroke signals
        keys_file = get_server_data_dir() / f'.apex-keys-{slot}'
        if self._key_proxy is not None:   # None when WebEngine is unavailable
            self._key_proxy.setKeysFile(keys_file)
        self._server.start(preferred_port=port, pid_file=pid_file,
                           server_data_dir=instance_dir)

    def _ensureVSCodeLoaded(self):
        """Load VS Code URL into the embedded QWebEngineView."""
        # _initVSCode runs eagerly on panel creation, but call it here too
        # in case the panel was created before _initVSCode completed.
        if self._ws_vscode_path is None:
            self._initVSCode()

        # Re-bind the current parm so the signal file is (re-)written now.
        self._rebindCurrent()

        if self._server.is_ready:
            self._loadVSCodeURL(self._server.port)
        else:
            self._status.setText('Starting VS Code server…')

    def _loadVSCodeURL(self, port: int):
        self._status.setText(f'VS Code on port {port}')
        if self._webview is None or not self._server:
            return
        base = self._server.url  # http://127.0.0.1:{port}
        # Pass workspace as ?folder= so VS Code starts in single-folder mode
        # from the first page load.  This avoids the updateWorkspaceFolders()
        # window-reload path entirely, which is what triggered the trust dialog.
        # VS Code serve-web folder path format: /C:/path/to/folder
        # (leading slash + Windows path with forward slashes).
        # The extension.js updateWorkspaceFolders() call remains as a fallback
        # for when this parameter is not recognised by the serve-web version.
        if self._ws_vscode_path:
            target = f'{base}?folder=/{self._ws_vscode_path}'
        else:
            target = base
        current = self._webview.url().toString()
        if not current.startswith(base):
            self._css_injected = False
            self._webview.setUrl(QtCore.QUrl(target))

    def _reloadVSCode(self):
        """Manually reload the embedded VS Code view (toolbar ↻ button).

        A user-facing reset: re-runs the clean load path (loadFinished ->
        _giveFocusToWebView) so keyboard focus lands on the key proxy again and
        the current file re-opens. Handy if the webview ever gets stuck — e.g.
        focus lost after a trust prompt, or a transient load glitch.
        """
        if self._webview is None:
            self._openVSCodeWeb()   # no WebEngine — fall back to the browser
            return
        if not self._server or not self._server.is_ready:
            self._status.setText('VS Code server not ready yet…')
            self._ensureVSCodeLoaded()
            return
        self._status.setText('Reloading VS Code…')
        self._css_injected = False
        base = self._server.url or ''
        if base and self._webview.url().toString().startswith(base):
            self._webview.reload()
        else:
            self._loadVSCodeURL(self._server.port)
        # Re-open the current file and re-grab focus once the reload settles
        # (loadFinished also does this; this is belt-and-suspenders).
        self._rebindCurrent()
        QtCore.QTimer.singleShot(_FOCUS_AFTER_CLICK_MS, self._giveFocusToWebView)
        self._startFocusRetry()

    # ------------------------------------------------------------------
    # JS injection scripts
    # ------------------------------------------------------------------

    # Pre-load: just prevent white flash.  The real theme/settings work
    # is done by the apexscript-panel-init VS Code extension.
    _THEME_PRELOAD_JS = r"""
    (function() {
        document.documentElement.style.backgroundColor = '#1e1e1e';
        document.documentElement.style.color = '#d4d4d4';
    })();
    """

    # Post-load: just ensure dark background.  All chrome hiding is done
    # by the init extension via VS Code settings API.
    _VSCODE_POST_JS = r"""
    (function() {
        document.documentElement.style.backgroundColor = '#1e1e1e';
    })();
    """

    # Auxiliary-input bridge: typing into VS Code's find/replace/rename/quick-
    # input widgets. Unlike Monaco's canvas editor (which only accepts the
    # `type` command), these are real DOM <input> elements, so we can set their
    # value + dispatch events directly. Defines window.__apexAux* helpers that
    # _KeyProxy calls via runJavaScript. All helpers operate on the currently
    # focused element, and refuse to touch anything that isn't one of our known
    # widget inputs (so Monaco's hidden .inputarea textarea is never affected).
    _AUX_BRIDGE_JS = r"""
    (function() {
        function role(ae) {
            if (!ae) return '';
            var tag = (ae.tagName || '').toLowerCase();
            if (tag !== 'input' && tag !== 'textarea') return '';
            if (!ae.closest) return '';
            if (ae.closest('.replace-part')) return 'replace';
            if (ae.closest('.find-part') || ae.closest('.find-widget')) return 'find';
            if (ae.closest('.rename-box')) return 'rename';
            if (ae.closest('.quick-input-widget')) return 'quickinput';
            if (ae.closest('.search-view') || ae.closest('.search-viewlet')) return 'search';
            return '';
        }
        function aux() {
            var ae = document.activeElement;
            return role(ae) ? ae : null;
        }
        window.__apexAuxRole = function() { return role(document.activeElement); };
        window.__apexAuxText = function(t) {
            var el = aux(); if (!el) return false;
            var s = el.selectionStart, e = el.selectionEnd, v = el.value;
            if (s == null) { el.value = v + t; }
            else {
                el.value = v.slice(0, s) + t + v.slice(e);
                var p = s + t.length; el.selectionStart = el.selectionEnd = p;
            }
            el.dispatchEvent(new Event('input', {bubbles: true}));
            return true;
        };
        window.__apexAuxEdit = function(kind) {
            var el = aux(); if (!el) return false;
            var v = el.value, s = el.selectionStart, e = el.selectionEnd;
            if (s == null) { s = v.length; e = v.length; }
            var changed = false;
            if (kind === 'backspace') {
                if (s !== e) { el.value = v.slice(0, s) + v.slice(e); el.selectionStart = el.selectionEnd = s; }
                else if (s > 0) { el.value = v.slice(0, s - 1) + v.slice(s); el.selectionStart = el.selectionEnd = s - 1; }
                changed = true;
            } else if (kind === 'delete') {
                if (s !== e) { el.value = v.slice(0, s) + v.slice(e); el.selectionStart = el.selectionEnd = s; }
                else if (s < v.length) { el.value = v.slice(0, s) + v.slice(s + 1); el.selectionStart = el.selectionEnd = s; }
                changed = true;
            } else if (kind === 'left') {
                var pl = (s !== e) ? s : Math.max(0, s - 1); el.selectionStart = el.selectionEnd = pl;
            } else if (kind === 'right') {
                var pr = (s !== e) ? e : Math.min(v.length, e + 1); el.selectionStart = el.selectionEnd = pr;
            } else if (kind === 'home') {
                el.selectionStart = el.selectionEnd = 0;
            } else if (kind === 'end') {
                el.selectionStart = el.selectionEnd = v.length;
            } else if (kind === 'selectall') {
                el.selectionStart = 0; el.selectionEnd = v.length;
            }
            if (changed) el.dispatchEvent(new Event('input', {bubbles: true}));
            return true;
        };
        window.__apexAuxKey = function(key, code, keyCode, shift) {
            var el = aux(); if (!el) return false;
            var init = {key: key, code: code, keyCode: keyCode, which: keyCode,
                        bubbles: true, cancelable: true, shiftKey: !!shift};
            el.dispatchEvent(new KeyboardEvent('keydown', init));
            el.dispatchEvent(new KeyboardEvent('keyup', init));
            return true;
        };
    })();
    """

    def _onWebViewLoaded(self, ok: bool):
        if not ok:
            return
        self._webview.page().runJavaScript(self._VSCODE_POST_JS)
        self._webview.page().runJavaScript(self._AUX_BRIDGE_JS)
        self._giveFocusToWebView()
        self._startFocusRetry()

    def _giveFocusToWebView(self):
        """Focus the key proxy and DOM-focus Monaco's textarea.

        The _key_proxy QLineEdit receives keyboard events (Houdini recognises
        QLineEdit as a text-input and lets keys through).  Each keystroke is
        forwarded to Monaco via runJavaScript().
        """
        if self._webview is None:
            return
        self._key_proxy.setFocus()
        self._webview.page().runJavaScript(
            "(function(){"
            "var el=document.querySelector('.monaco-editor .inputarea')"
            "||document.querySelector('.monaco-editor textarea');"
            "if(el)el.focus();"
            "})();"
        )

    def _startFocusRetry(self):
        """Start polling for Monaco's textarea every 500 ms (up to 10 s).

        Monaco is not in the DOM when loadFinished first fires if VS Code is
        still initializing (extensions loading, trust dialog showing, workspace
        switching).  This retry loop handles all such delayed-load cases.
        """
        self._focus_retry_count = 0
        self._focus_retry_timer.start()

    def _retryFocusMonaco(self):
        self._focus_retry_count += 1
        if self._webview is None or self._mode != self.MODE_VSCODE:
            self._focus_retry_timer.stop()
            return
        if self._focus_retry_count > _FOCUS_RETRY_MAX_TICKS:
            self._focus_retry_timer.stop()
            return

        def on_found(found):
            if not found:
                return
            # Monaco textarea is in the DOM and has DOM focus — stop polling.
            self._focus_retry_timer.stop()

        self._webview.page().runJavaScript(
            "(function(){"
            "var el=document.querySelector('.monaco-editor .inputarea')"
            "||document.querySelector('.monaco-editor textarea');"
            "if(el){el.focus();return true;}"
            "return false;"
            "})()",
            on_found,
        )

    def _openVSCodeWeb(self):
        """Fallback: open in system browser when WebEngine is unavailable."""
        import webbrowser
        if self._server.is_ready:
            self._status.setText(f'VS Code on port {self._server.port}')
            webbrowser.open(self._server.url)
        else:
            self._status.setText('Starting VS Code server…')
            self._server.ready.connect(self._onServerReadyBrowser)

    def _onServerReadyBrowser(self, port: int):
        import webbrowser
        self._status.setText(f'VS Code on port {port}')
        if self._server and self._server.url:
            webbrowser.open(self._server.url)

    def _onFocusChanged(self, _old, new):
        """Redirect keyboard focus from the webview to the key proxy.

        When the user clicks in the webview, Qt gives focus to QWebEngineView's
        internal render widget.  Houdini's event filter does not recognise it as
        a text-input, so it eats keyboard events as viewport hotkeys.

        We detect this via focusChanged, redirect focus to self._key_proxy (a
        QLineEdit that Houdini DOES recognise), and re-send the open signal so
        VS Code switches to this panel's file.
        """
        if self._mode != self.MODE_VSCODE or self._webview is None:
            return
        widget = new
        while widget is not None:
            if widget is self._webview:
                # Defer processing until mouse is fully released so
                # click-drag text selection works uninterrupted.
                def _after_mouse_up():
                    if QtWidgets.QApplication.mouseButtons() != QtCore.Qt.NoButton:
                        QtCore.QTimer.singleShot(_MOUSE_RELEASE_RETRY_MS, _after_mouse_up)
                        return
                    self._sync.write_open_signal()
                    self._key_proxy.setFocus()
                QtCore.QTimer.singleShot(0, _after_mouse_up)
                return
            widget = widget.parent()

    def _onServerReady(self, port: int):
        """Called when this panel's server becomes ready."""
        if self._mode == self.MODE_VSCODE:
            self._loadVSCodeURL(port)
        else:
            self._status.setText(f'VS Code server ready (port {port})')

    def _onServerError(self, msg: str):
        self._status.setText(f'Error: {msg[:60]}')

    # ------------------------------------------------------------------
    # External VS Code
    # ------------------------------------------------------------------

    def _openExternal(self):
        from .paths import to_vscode_path
        from .vscode_server import _find_code_cli, _vscode_is_running
        if not self._node:
            self._status.setText('No node selected')
            return
        parm = self._parm_combo.currentText()
        if not parm:
            self._status.setText('No parameter selected')
            return
        # (Re-)bind first, exactly like the embedded VS Code path does via
        # _ensureVSCodeLoaded. bind() ensures the workspace exists, writes the
        # base file to disk with the current parm content, and pins it in the
        # session watcher — all at the SAME path the embedded editor uses.
        # Opening standalone VS Code without this launched it on a path that
        # get_apex_file() had only mkdir'd (no file yet), so the external editor
        # opened an empty/nonexistent buffer and the watcher never saw its saves
        # — the failure seen when "Open External" was clicked before VS Code.
        self._rebindCurrent()
        apex_file = self._sync.file_path
        if apex_file is None:
            self._status.setText('No file to open')
            return
        cli = _find_code_cli()
        if not cli:
            self._status.setText('VS Code CLI not found')
            return
        targets = [to_vscode_path(str(apex_file))]
        if not _vscode_is_running():
            # A fresh VS Code given only a file opens a folder-less window:
            # the workspace's .vscode/settings.json (stub path, *.apex as
            # Python, diagnostics Python) is not loaded and the ApexScript
            # extension can't set Pylance's stub path. So open the workspace
            # folder too. A running VS Code only gets the file, in the window
            # the user already has.
            targets.insert(0, to_vscode_path(self._ws))
        # A VS Code started from here inherits Houdini's environment; drop its
        # Python variables like VSCodeServer.start does.
        env = {k: v for k, v in os.environ.items()
               if k not in ('PYTHONHOME', 'PYTHONPATH')}
        try:
            if sys.platform == 'cygwin':
                proc = subprocess.Popen(['cmd.exe', '/c', cli] + targets, env=env)
            elif cli.lower().endswith('.cmd'):
                # cmd.exe /c drops the first and last quote of its command line
                # when it holds more than one quoted argument (the default
                # "Microsoft VS Code" path plus an .apex path with a space, e.g.
                # from the hip name), so quote the whole line once more.
                proc = subprocess.Popen(
                    f'cmd.exe /c "{subprocess.list2cmdline([cli] + targets)}"',
                    env=env)
            else:
                proc = subprocess.Popen([cli] + targets, env=env)
            # Reap the launcher in the background: dropping a Popen whose
            # process still runs makes Python print a ResourceWarning.
            threading.Thread(target=proc.wait, daemon=True).start()
            self._status.setText(f'Opened {apex_file.name}')
        except Exception as e:
            self._status.setText(f'Cannot open: {e}')
