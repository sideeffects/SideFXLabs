"""Session-start cleanup of dead-slot state.

Runs exactly once per Houdini PID (gated by a per-PID ``.apex-session-{pid}``
marker) at panel construction time. Wipes signal/claim/PID/keys files and
workspace directories belonging to slots whose holder PIDs are dead, while
leaving state owned by live sibling Houdini sessions completely alone.

The marker is per-PID (not a single shared ``.apex-session-pid`` holding one
PID) so two concurrent sessions can't ping-pong the marker and re-trigger the
destructive wipe on each other's panel reopen — see
``feedback_panel_init_idempotent.md``.

The "live other" classification comes from :mod:`process` — we never
touch state belonging to another live Houdini process, even by accident.
"""
from __future__ import annotations
import os
from pathlib import Path

# get_server_data_dir / get_workspace_dir are lazy-imported inside the
# functions that use them so paths.py can re-export from this module
# without triggering a circular-import partial-attribute error.
from .process import _slot_holder_pid, _slot_is_live_other, _is_pid_alive


def _scrub_claude_leftovers(workspace: Path):
    """One-shot scrub of artifacts written by the now-removed Claude
    split-mode integration. Removes ``.claude/``, ``.mcp.json``, and
    ``CLAUDE.md`` from the workspace root if present. Idempotent.
    """
    import shutil
    for name in ('.claude', '.mcp.json', 'CLAUDE.md'):
        target = workspace / name
        try:
            if target.is_dir():
                shutil.rmtree(target, ignore_errors=True)
            elif target.exists():
                target.unlink()
        except Exception:
            pass


def clear_stale_signals():
    """Once-per-session cleanup of dead-slot state and our own slot's
    leftover .apex files.

    Iterates every ``.apex-slot-*.lock`` file. Sibling slots whose holder PID
    is alive are left **completely** untouched. Dead-slot files and our own
    slot's stale state both get cleaned exactly once per Houdini process
    (gated by the per-PID ``.apex-session-{pid}`` marker).

    Subsequent panel re-creations within the same Houdini process find our
    marker already present and short-circuit, so the user's in-flight .apex
    files are never destroyed by a reopen of the panel tab — and, because the
    marker is keyed to our own PID, a concurrent sibling session can never flip
    it and make our reopen re-run the wipe.
    """
    from .paths import get_server_data_dir
    data_dir = get_server_data_dir()
    my_pid = os.getpid()
    marker = data_dir / f'.apex-session-{my_pid}'
    if marker.exists():
        return  # Already cleared for this session

    # Reap markers left by dead sessions so they don't accumulate.
    for m in data_dir.glob('.apex-session-*'):
        try:
            mpid = int(m.name.rsplit('-', 1)[-1])
        except (ValueError, IndexError):
            continue
        if mpid != my_pid and not _is_pid_alive(mpid):
            try:
                m.unlink()
            except Exception:
                pass

    # Classify slots into "live siblings" (skip) vs "ours/dead" (clean).
    # Our own slot is cleaned here at session start, but the lock itself is
    # preserved — we just acquired it in next_panel_slot() and dropping it
    # would let a concurrent session steal the slot.
    live_other_slots: set[int] = set()
    for lock in data_dir.glob('.apex-slot-*.lock'):
        try:
            slot = int(lock.stem.split('-')[-1])
        except (ValueError, IndexError):
            continue
        holder = _slot_holder_pid(slot)
        if holder == my_pid:
            continue                            # ours — preserve lock
        if _slot_is_live_other(slot):
            live_other_slots.add(slot)
        else:
            # Dead session's lock — remove so the slot can be reclaimed.
            try:
                lock.unlink()
            except Exception:
                pass

    def _slot_of(name: str, prefix: str) -> int | None:
        try:
            return int(name[len(prefix):])
        except ValueError:
            return None

    # Remove signal/claim/PID/keys files for every slot EXCEPT live siblings.
    # Our own slot's helpers get rewritten later in _initVSCode (bind writes
    # .apex-open-{slot}, server writes .apex-server-pid-{slot}, key proxy
    # writes .apex-keys-{slot}, init extension writes .apex-claim-{slot}),
    # so wiping any stale leftovers from a previous crashed session is safe.
    for prefix in ('.apex-open-', '.apex-claim-', '.apex-server-pid-', '.apex-keys-'):
        for f in data_dir.glob(prefix + '*'):
            slot = _slot_of(f.name, prefix)
            if slot is not None and slot in live_other_slots:
                continue
            try:
                f.unlink()
            except Exception:
                pass

    # Remove legacy bare signal file always
    try:
        (data_dir / '.apex-open').unlink()
    except Exception:
        pass

    # Clean workspaces for dead slots AND our own slot. Live siblings are
    # left alone. Also scrub the now-removed Claude integration's artifacts
    # (idempotent — once cleaned they stay clean).
    for ws_dir in data_dir.glob('workspace-*'):
        if not ws_dir.is_dir():
            continue
        try:
            slot = int(ws_dir.name.split('-')[-1])
        except ValueError:
            continue
        if slot in live_other_slots:
            continue
        clean_workspace(ws_dir)
        _scrub_claude_leftovers(ws_dir)

    try:
        marker.write_text(str(my_pid), encoding='utf-8')
    except Exception:
        pass


def clean_workspace(workspace: Path | None = None):
    """Delete stale .apex files and empty hip-name subdirectories.

    Called at session start (before the first bind) so leftover temp files
    from a previous session never confuse VS Code into showing stale content.
    """
    from .paths import get_workspace_dir
    ws = workspace if workspace is not None else get_workspace_dir()
    if not ws.is_dir():
        return
    for item in list(ws.iterdir()):
        if item.name == '.vscode':
            continue  # preserve VS Code settings
        if item.is_file() and item.suffix == '.apex':
            try:
                item.unlink()
            except Exception:
                pass
        elif item.is_dir() and item.name != '.vscode':
            # Hip-name subdirectory — remove all .apex files inside
            for f in list(item.iterdir()):
                if f.is_file() and f.suffix == '.apex':
                    try:
                        f.unlink()
                    except Exception:
                        pass
            # Remove the subdir if now empty
            try:
                item.rmdir()
            except Exception:
                pass
