// ApexScript Panel Init — auto-configures embedded VS Code serve-web.
const vscode = require('vscode');
const fs = require('fs');
const path = require('path');

const HOME = process.env.USERPROFILE || process.env.HOME || '';
const DATA_DIR = path.join(HOME, '.vscode-serve-web');

// Debug log. Per-slot once the slot is known (mySlot) so concurrent sessions
// don't clobber each other's log — essential for multi-session debugging.
// Pre-derivation lines land in the shared .apex-init.log.
const LOG_FILE = path.join(DATA_DIR, '.apex-init.log');
const logLines = [];
function log(msg) {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log('[apexscript-panel-init]', msg);
    logLines.push(line);
    const lf = (mySlot !== null)
        ? path.join(DATA_DIR, `.apex-init-${mySlot}.log`)
        : LOG_FILE;
    try { fs.writeFileSync(lf, logLines.join('\n') + '\n'); } catch (_) {}
}

// ---------------------------------------------------------------------------
// Workspace claiming
//
// Each VS Code serve-web instance writes .apex-claim-{slot} to prevent
// another instance from stealing the same workspace's signals.
// ---------------------------------------------------------------------------

let mySlot = null;  // slot number claimed by this instance (null = not yet claimed)

function getMySlot() {
    return mySlot;
}

function claimFile(slot) {
    return path.join(DATA_DIR, `.apex-claim-${slot}`);
}

/** Write our PID into .apex-claim-{slot}.  Debug artifact only now — the slot
 *  is derived deterministically from the workspace folder (see
 *  deriveSlotFromWorkspace), so this no longer arbitrates ownership. */
function tryClaimSlot(slot) {
    const cf = claimFile(slot);
    try {
        fs.writeFileSync(cf, JSON.stringify({ pid: process.pid, t: Date.now() }));
        return true;
    } catch (_) { return true; }
}

function releaseClaim() {
    if (mySlot === null) return;
    try { fs.unlinkSync(claimFile(mySlot)); } catch (_) {}
}

/** Derive our slot from the workspace folder VS Code was launched with.
 *
 * The Python side loads serve-web with ?folder=/.../workspace-N (panel.py),
 * so workspaceFolders[0] is populated at activate() and unambiguously names
 * our slot. This is authoritative and replaces the old first-come signal-scan
 * claim, which could cross-wire two concurrent serve-web instances (each
 * opening the other session's node). Returns the slot number, or null if no
 * workspace folder is open yet (fallback path).
 */
function deriveSlotFromWorkspace() {
    try {
        const folders = vscode.workspace.workspaceFolders;
        if (folders && folders.length) {
            const p = (folders[0].uri.fsPath || '').replace(/\\/g, '/');
            const m = p.match(/workspace-(\d+)/i);
            if (m) return parseInt(m[1], 10);
        }
    } catch (_) {}
    return null;
}

// ---------------------------------------------------------------------------
// Signal file helpers
// ---------------------------------------------------------------------------

/** Return signal file paths to poll.
 *
 * Once we know our workspace, only return the matching slot's file.
 * Otherwise return all .apex-open-* files sorted descending by slot number
 * (the most recently created panel = highest slot = most likely to be ours).
 */
function getSignalFiles() {
    const mySlot = getMySlot();
    if (mySlot !== null) {
        return [path.join(DATA_DIR, `.apex-open-${mySlot}`)];
    }
    // No workspace claimed yet — scan for all slot files
    const entries = [];
    try {
        fs.readdirSync(DATA_DIR).forEach(f => {
            const m = f.match(/^\.apex-open-(\d+)$/);
            if (m) entries.push({ file: path.join(DATA_DIR, f), slot: parseInt(m[1], 10) });
        });
    } catch (_) {}
    // Descending by slot: most-recently-created panel is most likely to be us
    entries.sort((a, b) => b.slot - a.slot);
    return entries.map(e => e.file);
}

// ---------------------------------------------------------------------------
// Core: process one signal
// ---------------------------------------------------------------------------

let lastSignalKey = '';

function processSignal() {
    for (const signalFile of getSignalFiles()) {
        let raw;
        try {
            if (!fs.existsSync(signalFile)) continue;
            raw = fs.readFileSync(signalFile, 'utf-8').trim();
        } catch (_) { continue; }
        if (!raw) continue;

        let filePath = null, workspacePath = null, signalT = '';
        try {
            const obj = JSON.parse(raw);
            filePath = obj.file || null;
            workspacePath = obj.workspace || null;
            signalT = String(obj.t || '');
        } catch (_) {
            filePath = raw;
        }

        if (!filePath) continue;

        // Extract slot from workspace path
        const slotMatch = (workspacePath || '').replace(/\\/g, '/').match(/workspace-(\d+)/i);
        const signalSlot = slotMatch ? parseInt(slotMatch[1], 10) : null;

        // Our slot is normally derived from the workspace folder at activate().
        // Fallback: if it wasn't known yet (folder not open), adopt it from the
        // first signal we see. No cross-instance race — getSignalFiles narrows
        // to our own slot once mySlot is set.
        if (mySlot === null && signalSlot !== null) {
            mySlot = signalSlot;
            tryClaimSlot(signalSlot);   // debug artifact
            log(`adopted slot ${signalSlot} from signal (fallback)`);
        }
        // Never act on another slot's signal (belt-and-suspenders; getSignalFiles
        // already narrows to .apex-open-{mySlot} once mySlot is known).
        if (mySlot !== null && signalSlot !== null && signalSlot !== mySlot) continue;

        // Deduplicate: same file+timestamp = already handled
        const signalKey = filePath + '|' + signalT;
        if (signalKey === lastSignalKey) continue;
        lastSignalKey = signalKey;

        // Set workspace folder so Pylance activates and stubs / diagnostics work.
        // Only needed once: when no folder is open yet.  VS Code 1.97+ reloads the
        // window when adding the first folder; trust is suppressed at Machine scope
        // (written by Python before VS Code starts) so no trust dialog appears.
        // After the reload the extension re-activates and re-processes this signal.
        if (workspacePath) {
            const existing = vscode.workspace.workspaceFolders;
            if (!existing || existing.length === 0) {
                // vscode.Uri.file and fs.existsSync both accept forward slashes
                // on Windows; on Linux they only accept forward slashes. The
                // Python side (to_vscode_path) always produces forward-slash
                // paths, so the path goes through unmodified on both OSes.
                const wsUri = vscode.Uri.file(workspacePath);
                log('setting workspace folder: ' + workspacePath);
                vscode.workspace.updateWorkspaceFolders(0, null, { uri: wsUri });
                return;  // window will reload; signal is re-processed after reload
            }
        }

        // Open the file
        log('trust=' + vscode.workspace.isTrusted + ' folders=' + (vscode.workspace.workspaceFolders || []).length);
        log('opening: ' + filePath);
        if (!fs.existsSync(filePath)) { log('file not found: ' + filePath); return; }
        vscode.window.showTextDocument(vscode.Uri.file(filePath), { preview: false, preserveFocus: false }).then(
            (editor) => {
                log('opened OK');
                // Force VS Code to re-read from disk so we never show a stale
                // cached buffer — the Python side always writes the current parm
                // value to the file before sending this signal.
                // BUT: skip revert if the buffer has unsaved edits; otherwise
                // any stray open-signal (e.g. from a panel re-focus) would
                // silently discard the user's typing.
                if (editor && editor.document && !editor.document.isDirty) {
                    vscode.commands.executeCommand('workbench.action.files.revert')
                        .then(() => log('reverted to disk'), () => {});
                } else {
                    log('skipped revert — buffer is dirty');
                }
                // Explicitly focus the editor from inside VS Code so keyboard
                // input works in embedded (serve-web / QWebEngineView) contexts
                // where programmatic Qt focus and window.focus() are blocked by
                // Chromium's "user gesture" requirement on newly-loaded pages.
                setTimeout(() => {
                    vscode.commands.executeCommand('workbench.action.focusActiveEditorGroup')
                        .then(() => {}, () => {});
                }, 300);
            },
            (err) => log('showTextDocument error: ' + err)
        );
        return;
    }
}

// ---------------------------------------------------------------------------
// Keystroke injection via file IPC
//
// The Houdini panel's _KeyProxy (a QLineEdit) captures keyboard events that
// Houdini's event filter would otherwise eat.  Each keystroke is written to
// .apex-keys-{slot} as JSON.  We watch for changes via fs.watch and replay
// them using VS Code's command API — the only reliable way to type into
// Monaco when the browser window doesn't have native OS keyboard focus.
// ---------------------------------------------------------------------------

// Track whether autocomplete suggestions might be visible.
// Set to true when a character is typed, false on Escape/cursor movement.
let _suggestLikely = false;

// Autocomplete-aware arrow handler: try suggestion navigation first,
// fall back to cursor movement if suggestions aren't visible.
function _arrowWithSuggest(suggestCmd, cursorCmd) {
    if (_suggestLikely) {
        vscode.commands.executeCommand(suggestCmd).then(() => {}, () => {});
    } else {
        vscode.commands.executeCommand(cursorCmd).then(() => {}, () => {});
    }
}

// Editor-specific keystroke commands (only used when a text editor is active).
const _EDITOR_CMDS = {
    'Enter':      () => vscode.commands.executeCommand('type', {text: '\n'}),
    'Backspace':  () => { _suggestLikely = false; vscode.commands.executeCommand('deleteLeft'); },
    'Delete':     () => vscode.commands.executeCommand('deleteRight'),
    'Tab':        () => vscode.commands.executeCommand('tab'),
    'ArrowLeft':  () => { _suggestLikely = false; vscode.commands.executeCommand('cursorLeft'); },
    'ArrowRight': () => { _suggestLikely = false; vscode.commands.executeCommand('cursorRight'); },
    'ArrowUp':    () => _arrowWithSuggest('selectPrevSuggestion', 'cursorUp'),
    'ArrowDown':  () => _arrowWithSuggest('selectNextSuggestion', 'cursorDown'),
    'Home':       () => { _suggestLikely = false; vscode.commands.executeCommand('cursorHome'); },
    'End':        () => { _suggestLikely = false; vscode.commands.executeCommand('cursorEnd'); },
    'PageUp':     () => vscode.commands.executeCommand('cursorPageUp'),
    'PageDown':   () => vscode.commands.executeCommand('cursorPageDown'),
    'Escape':     () => { _suggestLikely = false; vscode.commands.executeCommand('closeFindWidget').then(()=>{},()=>{}); vscode.commands.executeCommand('hideSuggestWidget').then(()=>{},()=>{}); },
};

let _lastKeysContent = '';

function processKeystrokes(filename) {
    const filepath = path.join(DATA_DIR, filename);
    let raw;
    try {
        raw = fs.readFileSync(filepath, 'utf-8').trim();
    } catch (_) { return; }
    if (!raw || raw === _lastKeysContent) return;

    let entries;
    try {
        entries = JSON.parse(raw);
        if (!Array.isArray(entries)) entries = [entries];
    } catch (_) { return; }
    // Update dedup cache only after successful parse, so partial writes
    // (caught above) don't pollute the cache and block the real write.
    _lastKeysContent = raw;

    for (const entry of entries) {
        if (entry.text) {
            // Enter and Tab need special handling: when autocomplete is open,
            // they should accept the suggestion instead of inserting \n / \t.
            // We try acceptSelectedSuggestion first; if the document doesn't
            // change (no suggestion was accepted), fall back to typing.
            if (entry.text === '\n') {
                const ed = vscode.window.activeTextEditor;
                if (ed) {
                    const docVer = ed.document.version;
                    vscode.commands.executeCommand('acceptSelectedSuggestion').then(() => {
                        setTimeout(() => {
                            if (ed.document.version === docVer) {
                                // Document unchanged — no suggestion accepted; type normally
                                vscode.commands.executeCommand('type', {text: entry.text});
                            } else {
                                // Suggestion accepted — reset suggest state
                                _suggestLikely = false;
                            }
                        }, 80);
                    }, () => {
                        vscode.commands.executeCommand('type', {text: entry.text});
                    });
                } else {
                    vscode.commands.executeCommand('type', {text: entry.text});
                }
            } else {
                _suggestLikely = true;  // Typing a char may trigger autocomplete
                vscode.commands.executeCommand('type', {text: entry.text});
            }
        } else if (entry.cmd === 'editor.action.clipboardCopyAction'
                || entry.cmd === 'editor.action.clipboardCutAction') {
            // Copy/Cut: get the selection text and write it to a clipboard
            // signal file so the Python side can put it on Qt's clipboard.
            // The browser Clipboard API may not work without window focus.
            const editor = vscode.window.activeTextEditor;
            if (editor) {
                const sel = editor.selection;
                let text;
                if (sel.isEmpty) {
                    // No selection: copy the current line (VS Code default behavior)
                    const line = editor.document.lineAt(sel.active.line);
                    text = line.text + '\n';
                } else {
                    text = editor.document.getText(sel);
                }
                if (text) {
                    const clipFile = path.join(DATA_DIR, '.apex-clipboard');
                    try { fs.writeFileSync(clipFile, text, 'utf-8'); } catch (_) {}
                }
                if (entry.cmd === 'editor.action.clipboardCutAction') {
                    if (sel.isEmpty) {
                        // Cut entire line when nothing is selected
                        const line = editor.document.lineAt(sel.active.line);
                        const range = line.rangeIncludingLineBreak;
                        editor.edit(b => b.delete(range));
                    } else {
                        editor.edit(b => b.delete(sel));
                    }
                }
            }
        } else if (entry.cmd) {
            const fn = _EDITOR_CMDS[entry.cmd];
            if (fn) {
                fn();
            } else {
                vscode.commands.executeCommand(entry.cmd).then(() => {}, () => {});
            }
        }
    }
}

// ---------------------------------------------------------------------------
// Activate
// ---------------------------------------------------------------------------

function activate(context) {
    log('=== ACTIVATING ===');
    log('workspace.isTrusted: ' + vscode.workspace.isTrusted);
    log('workspaceFolders: ' + JSON.stringify((vscode.workspace.workspaceFolders || []).map(f => f.uri.toString())));

    // Derive our slot deterministically from the workspace folder VS Code was
    // launched with (?folder=/.../workspace-N). Authoritative, and immune to
    // the startup race that could cross-wire two concurrent serve-web instances.
    mySlot = deriveSlotFromWorkspace();
    if (mySlot !== null) {
        tryClaimSlot(mySlot);   // debug artifact
        log(`derived slot ${mySlot} from workspace folder`);
    } else {
        // Fallback: no folder open yet — restore our slot from a claim file we
        // wrote before a mid-session reload, else adopt it from the first signal.
        for (let s = 0; s < 16; s++) {
            const cf = claimFile(s);
            try {
                if (!fs.existsSync(cf)) continue;
                const data = JSON.parse(fs.readFileSync(cf, 'utf-8'));
                if (data.pid === process.pid) {
                    mySlot = s;
                    log(`restored slot ${s} from claim file`);
                    break;
                }
            } catch (_) {}
        }
    }

    const config = vscode.workspace.getConfiguration();

    // Trust: disable entirely so embedded panel never shows trust prompts
    config.update('security.workspace.trust.enabled', false, vscode.ConfigurationTarget.Global);
    config.update('security.workspace.trust.startupPrompt', 'never', vscode.ConfigurationTarget.Global);
    config.update('security.workspace.trust.banner', 'never', vscode.ConfigurationTarget.Global);
    config.update('security.workspace.trust.emptyWindow', true, vscode.ConfigurationTarget.Global);
    const theme = config.get('workbench.colorTheme');
    if (!theme || theme.toLowerCase().includes('light') || theme === 'Default Dark+') {
        config.update('workbench.colorTheme', 'Default Dark Modern', vscode.ConfigurationTarget.Global);
    }
    config.update('workbench.startupEditor', 'none', vscode.ConfigurationTarget.Global);
    config.update('workbench.tips.enabled', false, vscode.ConfigurationTarget.Global);
    config.update('window.menuBarVisibility', 'classic', vscode.ConfigurationTarget.Global);
    config.update('workbench.activityBar.location', 'hidden', vscode.ConfigurationTarget.Global);
    config.update('editor.minimap.enabled', false, vscode.ConfigurationTarget.Global);
    config.update('breadcrumbs.enabled', false, vscode.ConfigurationTarget.Global);
    config.update('workbench.editor.showTabs', 'none', vscode.ConfigurationTarget.Global);
    config.update('workbench.statusBar.visible', false, vscode.ConfigurationTarget.Global);
    config.update('zenMode.centerLayout', false, vscode.ConfigurationTarget.Global);
    config.update('workbench.editor.centeredLayoutAutoResize', false, vscode.ConfigurationTarget.Global);
    config.update('workbench.editor.centeredLayoutFixedWidth', false, vscode.ConfigurationTarget.Global);
    config.update('workbench.panel.defaultLocation', 'bottom', vscode.ConfigurationTarget.Global);

    // Suppress new VS Code onboarding/chat prompts (added in 1.96+)
    config.update('chat.welcomeMessage', 'never', vscode.ConfigurationTarget.Global).then(() => {}, () => {});
    config.update('workbench.welcomePage.enabled', false, vscode.ConfigurationTarget.Global).then(() => {}, () => {});
    config.update('workbench.welcomePage.walkthroughs.openOnInstall', false, vscode.ConfigurationTarget.Global).then(() => {}, () => {});
    config.update('workbench.startupEditor', 'none', vscode.ConfigurationTarget.Global).then(() => {}, () => {});

    // Close sidebar, panels, notifications, and exit zen mode.
    // Repeat after a delay because VS Code auto-opens the chat / "Build with
    // Agent" auxiliary bar on first workspace load AFTER our initial close;
    // firing again post-startup catches that.
    const _hideChrome = () => {
        vscode.commands.executeCommand('workbench.action.closeSidebar').then(() => {}, () => {});
        vscode.commands.executeCommand('workbench.action.closePanel').then(() => {}, () => {});
        vscode.commands.executeCommand('workbench.action.closeAuxiliaryBar').then(() => {}, () => {});
        vscode.commands.executeCommand('workbench.action.exitZenMode').then(() => {}, () => {});
        vscode.commands.executeCommand('notifications.clearAll').then(() => {}, () => {});
    };
    _hideChrome();
    setTimeout(_hideChrome, 500);
    setTimeout(_hideChrome, 1500);
    setTimeout(_hideChrome, 3000);

    // Close any open editors (Welcome page, "Get Started", restored tabs from
    // a previous serve-web session) BEFORE processSignal opens our .apex file.
    // Without this, the welcome editor can stay around even with
    // workbench.startupEditor:'none' set, because VS Code restored it from
    // session state.
    vscode.commands.executeCommand('workbench.action.closeAllEditors').then(() => {
        // Initial signal check — opens our .apex AFTER the welcome page is gone.
        processSignal();
    }, () => {
        processSignal();
    });

    // Watch DATA_DIR for .apex-open-* changes
    try {
        if (fs.existsSync(DATA_DIR)) {
            const w = fs.watch(DATA_DIR, (_, fn) => {
                if (!fn) return;
                if (/^\.apex-open(-\d+)?$/.test(fn)) { processSignal(); return; }
                // Replay ONLY our own slot's keystrokes. DATA_DIR is shared
                // across sessions, so without this a concurrent session's
                // extension would replay THIS session's keys into its own
                // editor — the cross-session bleed seen when switching
                // desktops/windows. (.apex-open is already slot-scoped via
                // getMySlot inside processSignal.)
                if (mySlot !== null && fn === '.apex-keys-' + mySlot) {
                    processKeystrokes(fn);
                }
            });
            context.subscriptions.push({ dispose: () => w.close() });
        }
    } catch (_) {}

    // Poll every 2 s as a fallback
    const interval = setInterval(() => processSignal(), 2000);
    context.subscriptions.push({ dispose: () => clearInterval(interval) });

    // Watch tabs and auto-close any walkthrough / welcome / getting-started
    // tabs that VS Code reopens after our initial closeAllEditors. The
    // welcomePage / startupEditor settings should suppress these but don't
    // always — this is the only reliable way to make them disappear.
    const _isUnwantedTab = (tab) => {
        try {
            const input = tab.input;
            if (!input) return false;
            // TabInputWebview (walkthrough page) — viewType starts with 'walkthroughs'
            if (input.viewType && /walkthrough|gettingStarted|welcome/i.test(input.viewType)) return true;
            // TabInputText with welcome:// scheme
            if (input.uri && input.uri.scheme && /walkthrough|welcome|gettingStarted/i.test(input.uri.scheme)) return true;
            // Tab label fallback for older VS Code
            if (tab.label && /get started|welcome/i.test(tab.label)) return true;
        } catch (_) {}
        return false;
    };
    const _purgeUnwantedTabs = () => {
        try {
            for (const group of vscode.window.tabGroups.all) {
                for (const tab of group.tabs) {
                    if (_isUnwantedTab(tab)) {
                        vscode.window.tabGroups.close(tab).then(() => {}, () => {});
                    }
                }
            }
        } catch (_) {}
    };
    _purgeUnwantedTabs();
    if (vscode.window.tabGroups && vscode.window.tabGroups.onDidChangeTabs) {
        const sub = vscode.window.tabGroups.onDidChangeTabs((e) => {
            if (e && e.opened && e.opened.some(_isUnwantedTab)) _purgeUnwantedTabs();
        });
        context.subscriptions.push(sub);
    }

    log('activation complete');
}

function deactivate() {
    releaseClaim();
}

module.exports = { activate, deactivate };
