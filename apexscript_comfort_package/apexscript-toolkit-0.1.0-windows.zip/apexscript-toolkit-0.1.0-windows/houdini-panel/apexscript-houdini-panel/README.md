# ApexScript Houdini Panel

A Houdini Python Panel for ApexScript nodes: it shows the node's parameters and opens the node's `snippet` in VS Code (Pylance, stubs, ApexScript diagnostics), syncing every save back to the node.

## Prerequisites

- **VS Code** installed with `code` available in PATH, or `VSCODE_CLI_PATH` set
- The **ApexScript** VS Code extension and **Pylance** (`ms-python.python`) in that VS Code — the toolkit installer adds both
- **Houdini 20+** (PySide2 or PySide6)

## Installation

1. Copy this `apexscript-houdini-panel/` directory to a permanent location.

2. Set the `APEXSCRIPT_PANEL_PATH` environment variable to that location:
   ```bash
   export APEXSCRIPT_PANEL_PATH=/path/to/apexscript-houdini-panel
   ```

3. Copy `apexscript-houdini-panel.json` into your Houdini packages directory:
   ```bash
   cp apexscript-houdini-panel.json ~/houdiniXX.X/packages/
   ```

4. Restart Houdini.

## Usage

### Opening the Panel

- Select an `apex::script` or `apex::autorigcomponent` SOP node
- The panel auto-appears in the Parameters pane
- Or open manually: **Pane Tab Menu > ApexScript Editor**

### Editing in VS Code

The panel shows the node's parameters. Click **Edit in VS Code** to open the node's `snippet` in VS Code:
- If VS Code is already running, the file opens in your current window.
- If not, VS Code starts with the panel's workspace folder, so the stub path and ApexScript settings apply.
- Saving in VS Code updates the node; editing the snippet in Houdini updates the file.

## Environment Variables

| Variable | Description |
|----------|-------------|
| `APEXSCRIPT_PANEL_PATH` | **Required.** Path to this package directory |
| `VSCODE_CLI_PATH` | Override VS Code CLI location |
| `APEX_STUBS_PATH` | Override path to apexscript-stubs for Pylance |

## Troubleshooting

### VS Code not found
Ensure `code` is in your PATH or set `VSCODE_CLI_PATH` to the full path of the VS Code CLI.

### No completions in VS Code
Check that the ApexScript extension and Pylance are installed (`code --list-extensions`). The stubs need a folder open in the VS Code window: without one, the extension can't set Pylance's stub path. **Edit in VS Code** opens the panel's workspace folder when VS Code isn't running; if your open window has no folder, open one, or close VS Code and click the button again.

### Stubs not detected
Set `APEX_STUBS_PATH` to the parent directory containing `apexscript-stubs/`.

### Panel not appearing
Verify `$HOUDINI_PATH` includes your install directory by running in Houdini's Python shell:
```python
import os; print(os.environ.get('HOUDINI_PATH', ''))
```
