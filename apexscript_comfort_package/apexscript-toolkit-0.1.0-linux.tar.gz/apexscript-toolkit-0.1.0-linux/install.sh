#!/usr/bin/env bash
# ApexScript Toolkit Installer (Linux / macOS / WSL)
# Installs everything into ~/.apexscript/ — no venv, no global pollution.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.apexscript"
CLAUDE_DIR="$HOME/.claude"
HELPER="$INSTALL_DIR/apex_toolkit_config.py"
BUNDLE_HELPER="$SCRIPT_DIR/apex_toolkit_config.py"
TOOLKIT_VERSION="dev"
[ -f "$SCRIPT_DIR/VERSION" ] && TOOLKIT_VERSION="$(tr -d '[:space:]' < "$SCRIPT_DIR/VERSION")"

echo "=== ApexScript Toolkit Installer $TOOLKIT_VERSION ==="
echo ""
echo "Install directory: $INSTALL_DIR"
echo ""

# --- Parse args (--force / -y for non-interactive reinstall) ---
FORCE=0
for arg in "$@"; do
    case "$arg" in
        -f|--force|-y|--yes) FORCE=1 ;;
    esac
done

# --- Check for existing installation ---
REINSTALL_PENDING=0
if [ -d "$INSTALL_DIR" ]; then
    do_reinstall=$FORCE
    if [ "$FORCE" -ne 1 ]; then
        read -p "Existing installation found. Reinstall? [y/N] (snippets/workflows are kept) " -n 1 -r
        echo ""
        [[ $REPLY =~ ^[Yy]$ ]] && do_reinstall=1
    fi
    if [ "$do_reinstall" -eq 1 ]; then
        # Deliberately NOT running the previously installed uninstaller: older
        # ones delete the whole ~/.apexscript including the user's snippets/ and
        # workflows/. All steps below are idempotent, so we only need the
        # managed files removed; the bundled helper does that (after Python
        # is found) and keeps user data.
        REINSTALL_PENDING=1
    else
        echo "Aborted."
        exit 0
    fi
fi

# --- Find Python 3.11+ ---
# One probe answers everything: "major.minor|platform|pip|exe". A usable
# interpreter is 3.11+ (3.10 is NOT supported), not Cygwin/MSYS, and has pip (Debian/Ubuntu ship python3
# without it until python3-pip is installed). Rejections are listed on failure.
PROBE="import sys, importlib.util; print(f'{sys.version_info.major}.{sys.version_info.minor}|{sys.platform}|{int(importlib.util.find_spec(\"pip\") is not None)}|{sys.executable}')"
PYTHON=""
PYTHON_PATH=""
REJECTED=()
probe_python() {  # $1 label, $2 executable -> sets PYTHON_PATH on success
    local out ver plat pip exe major minor
    out="$("$2" -c "$PROBE" 2>/dev/null)" || { REJECTED+=("$1 - not found or does not run"); return 1; }
    IFS='|' read -r ver plat pip exe <<< "$out"
    major="${ver%%.*}"; minor="${ver##*.}"
    if [ "$major" -lt 3 ] || [ "$minor" -lt 11 ]; then REJECTED+=("$1 - Python $ver is too old: the toolkit needs Python 3.11 or newer"); return 1; fi
    case "$plat" in cygwin*|msys*) REJECTED+=("$1 - Cygwin/MSYS Python is not supported"); return 1 ;; esac
    if [ "$pip" != "1" ]; then REJECTED+=("$1 - $exe has no pip (Debian/Ubuntu: sudo apt install python3-pip)"); return 1; fi
    [ "$minor" -gt 14 ] && echo "Note: Python $ver is newer than the tested range (3.11-3.14)."
    PYTHON_PATH="$exe"
    return 0
}
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null && probe_python "$cmd" "$cmd"; then PYTHON="$cmd"; break; fi
done

# Fallback: uv-managed CPython (uv-only machines). uv's CPython ships pip.
if [ -z "$PYTHON" ] && command -v uv &>/dev/null; then
    uvpy="$(uv python find '>=3.11' 2>/dev/null | head -1 || true)"
    if [ -n "$uvpy" ] && [ -x "$uvpy" ] && probe_python "uv python" "$uvpy"; then
        PYTHON="$uvpy"
        echo "Found uv-managed Python: $uvpy"
    fi
fi

if [ -z "$PYTHON" ]; then
    echo "ERROR: no usable Python 3.11+ found (Python 3.10 and older are not supported). Candidates checked:"
    for r in "${REJECTED[@]:-}"; do [ -n "$r" ] && echo "  - $r"; done
    echo "Install Python 3.11 or newer with pip (python.org, your package manager, or Homebrew),"
    echo "or with uv:  uv python install 3.12   (then re-run this installer)."
    exit 1
fi
echo "Using Python: $PYTHON_PATH ($("$PYTHON" --version))"

# --- Network preflight ---
echo ""
echo ">>> Checking network access..."
"$PYTHON" "$BUNDLE_HELPER" preflight || true
MARKETPLACE_OK=0
"$PYTHON" "$BUNDLE_HELPER" preflight --only marketplace --quiet && MARKETPLACE_OK=1

# --- Remove the previous install's managed files (user data is kept) ---
# Uses the BUNDLED helper (the installed copy is one of the files removed).
if [ "$REINSTALL_PENDING" -eq 1 ]; then
    echo "Removing previous installation (keeping snippets/ and workflows/)..."
    if ! "$PYTHON" "$SCRIPT_DIR/apex_toolkit_config.py" installdir clean --install-dir "$INSTALL_DIR"; then
        echo "ERROR: could not remove the previous installation. Nothing was changed."
        exit 1
    fi
fi

# --- Create install directory ---
mkdir -p "$INSTALL_DIR/lib" "$INSTALL_DIR/bin" "$INSTALL_DIR/snippets"

# From here on, keep a transcript for bug reports (the dir exists and is clean).
INSTALL_LOG="$INSTALL_DIR/install.log"
exec > >(tee "$INSTALL_LOG") 2>&1
echo "Toolkit version: $TOOLKIT_VERSION   (log: $INSTALL_LOG)"
[ -f "$SCRIPT_DIR/VERSION" ] && cp "$SCRIPT_DIR/VERSION" "$INSTALL_DIR/"

# Copy the cross-platform config helper + canonical instruction blocks in so
# the uninstall script can reuse them after the bundle is gone.
cp "$SCRIPT_DIR/apex_toolkit_config.py" "$INSTALL_DIR/"
cp "$SCRIPT_DIR/claude-md-block.md" "$INSTALL_DIR/"
[ -f "$SCRIPT_DIR/agents-md-block.md" ] && cp "$SCRIPT_DIR/agents-md-block.md" "$INSTALL_DIR/"

# --- Step 1: Install Python packages ---
echo ""
echo ">>> Installing Python packages into $INSTALL_DIR/lib..."
REF_WHEEL=$(find "$SCRIPT_DIR" -maxdepth 1 -name 'apexscript_reference_loader-*.whl' | head -1)
MCP_WHEEL=$(find "$SCRIPT_DIR" -maxdepth 1 -name 'apexscript_mcp_server-*.whl' | head -1)

if [ -z "$REF_WHEEL" ]; then
    echo "ERROR: apexscript_reference_loader wheel not found in $SCRIPT_DIR"
    exit 1
fi
if [ -z "$MCP_WHEEL" ]; then
    echo "ERROR: apexscript_mcp_server wheel not found in $SCRIPT_DIR"
    exit 1
fi

# Sanitize the env for the install too: a Houdini shell leaks PYTHONHOME/PYTHONPATH
# which can poison pip's target resolution (or break the interpreter outright).
# constraints.txt (written at build time) pins every transitive dependency to
# the versions the bundle was tested with (unpinned, mcp 2.x got in).
PIP_CONSTRAINTS=()
[ -f "$SCRIPT_DIR/constraints.txt" ] && PIP_CONSTRAINTS=(-c "$SCRIPT_DIR/constraints.txt")
env -u PYTHONHOME -u PYTHONPATH "$PYTHON" -m pip install \
    --target "$INSTALL_DIR/lib" --quiet "${PIP_CONSTRAINTS[@]}" "$REF_WHEEL" "$MCP_WHEEL"
echo "    Done."

# --- Step 2: Create the launcher ---
# The helper writes bin/apexscript_mcp_launcher.py (registered with Claude Code
# and Codex as `<python> <launcher>`) and bin/apexscript-mcp-server for humans /
# --selfcheck. Both pin the exact interpreter that just ran pip (the compiled
# deps match its ABI). The shell wrapper also clears a PYTHONHOME leaked from a
# Houdini shell; the .py launcher puts lib first on sys.path and processes its
# .pth files (pywin32 on Windows; harmless here).
echo ""
echo ">>> Writing launcher..."
"$PYTHON" "$HELPER" launcher install --install-dir "$INSTALL_DIR" --python "$PYTHON_PATH"
LAUNCHER="$INSTALL_DIR/bin/apexscript_mcp_launcher.py"

# Warn if the pinned interpreter lives inside a Houdini install — it works, but
# the toolkit is now bound to an interpreter that moves with HFS upgrades.
case "$PYTHON_PATH" in
    *hfs*|*houdini*|*Houdini*|*sidefx*|*SideFX*)
        echo "    Note: pinned interpreter is inside a Houdini install:"
        echo "          $PYTHON_PATH"
        echo "          For a more stable install, re-run from a plain shell where"
        echo "          'python3' is a standalone system/uv Python."
        ;;
esac

# --- Step 3: Install VS Code extension ---
echo ""
# Find a CLI on PATH or where its own installer puts it (a fresh install is only
# on PATH in NEW shells). Usage: find_cli name [name...] -- candidate [...]
find_cli() {
    local n
    while [ $# -gt 0 ] && [ "$1" != "--" ]; do
        if command -v "$1" &>/dev/null; then echo "$1"; return 0; fi
        shift
    done
    shift || true
    for n in "$@"; do [ -x "$n" ] && { echo "$n"; return 0; }; done
    return 1
}
CODE_CMD="$(find_cli code code-insiders -- /snap/bin/code /usr/share/code/bin/code \
    "/Applications/Visual Studio Code.app/Contents/Resources/app/bin/code" || true)"

VSIX=$(find "$SCRIPT_DIR" -maxdepth 1 -name 'apexscript-lsp-*.vsix' | head -1)
if [ -z "$VSIX" ]; then
    echo "Note: VS Code extension (.vsix) not found in bundle, skipping."
elif [ -z "$CODE_CMD" ]; then
    echo "Note: VS Code not found on PATH. To install the extension later:"
    echo "    code --install-extension $VSIX"
else
    # A failed extension install must not abort the whole installer (set -e).
    echo ">>> Installing VS Code extension..."
    if "$CODE_CMD" --install-extension "$VSIX" --force 2>/dev/null; then
        echo "    Done."
    else
        echo "    Warning: extension install failed. Install it later with:"
        echo "    $CODE_CMD --install-extension $VSIX"
    fi
    # Pylance (bundled with ms-python.python) — the ApexScript extension defaults
    # to 'pylance' mode and needs it for completions in standalone VS Code.
    echo ">>> Installing Pylance (ms-python.python) for completions..."
    if [ "$MARKETPLACE_OK" -ne 1 ]; then
        echo "    Skipped: the VS Code Marketplace is unreachable from here. Install it later with:"
        echo "    $CODE_CMD --install-extension ms-python.python"
    elif "$CODE_CMD" --install-extension ms-python.python --force 2>/dev/null; then
        echo "    Done."
    else
        echo "    Warning: Pylance install failed. Install it later with:"
        echo "    $CODE_CMD --install-extension ms-python.python"
    fi
fi

# --- Step 4: Configure MCP server ---
echo ""
MCP_BIN="$INSTALL_DIR/bin/apexscript-mcp-server"

# Smoke-test the launcher before registering it, so a broken install (ABI
# mismatch, missing dep) fails LOUD here instead of showing up later as a silent
# "not connected" in Claude Code.
echo ">>> Verifying the MCP server launches..."
if "$MCP_BIN" --selfcheck; then
    echo "    Self-check passed."
else
    echo "    WARNING: the MCP server failed to start (see diagnostic above)."
    echo "    Re-run the check any time with:  $MCP_BIN --selfcheck"
fi
echo ""

# Claude Code's VS Code extension ships the CLI too; someone who only uses
# Claude Code inside VS Code has nothing else on PATH. Newest version first.
CLAUDE_VSIX="$(ls -d "$HOME"/.vscode/extensions/anthropic.claude-code-*/resources/native-binary/claude 2>/dev/null | sort -r | head -1 || true)"
CLAUDE_CMD="$(find_cli claude -- "$HOME/.local/bin/claude" ${CLAUDE_VSIX:+"$CLAUDE_VSIX"} || true)"
if [ -n "$CLAUDE_CMD" ]; then
    echo ">>> Configuring MCP server for Claude Code (user scope)..."
    # `claude mcp add` refuses to overwrite an existing name; drop any previous
    # registration first (a failure here just means there was none).
    "$CLAUDE_CMD" mcp remove --scope user apexscript >/dev/null 2>&1 || true
    if "$CLAUDE_CMD" mcp add --transport stdio --scope user apexscript -- "$PYTHON_PATH" "$LAUNCHER" 2>/dev/null; then
        echo "    Done. MCP server registered as 'apexscript'."
        echo "    Note: a project-scope 'apexscript' entry in a .mcp.json SHADOWS this"
        echo "          user-scope registration - remove any manual one so this takes effect."
    else
        echo "    Warning: Could not auto-configure. See manual setup below."
    fi
else
    echo "Note: Claude CLI not found. To configure the MCP server manually,"
    echo "add to your project's .mcp.json:"
    echo ""
    echo "  {"
    echo "    \"mcpServers\": {"
    echo "      \"apexscript\": {"
    echo "        \"command\": \"$PYTHON_PATH\","
    echo "        \"args\": [\"$LAUNCHER\"]"
    echo "      }"
    echo "    }"
    echo "  }"
fi

# --- Step 4b: Configure MCP server for Codex CLI ---
# Codex is configured only when it is actually present (the `codex` CLI on
# PATH, or an existing ~/.codex dir from an app-managed install) — we never
# create a Codex config tree for non-Codex users. Primary path is
# `codex mcp add`; fallback is a marker-delimited block in ~/.codex/config.toml
# written by the helper (safe around user-authored TOML).
CODEX_DIR="$HOME/.codex"
CODEX_CMD="$(find_cli codex -- "$HOME/.local/bin/codex" || true)"
if [ -n "$CODEX_CMD" ]; then
    echo ""
    echo ">>> Configuring MCP server for Codex CLI..."
    "$CODEX_CMD" mcp remove apexscript >/dev/null 2>&1 || true
    if "$CODEX_CMD" mcp add apexscript -- "$PYTHON_PATH" "$LAUNCHER" 2>/dev/null; then
        echo "    Done. MCP server registered as 'apexscript'."
    else
        echo "    'codex mcp add' unavailable; writing $CODEX_DIR/config.toml directly..."
        "$PYTHON" "$HELPER" codexmcp install --codex-dir "$CODEX_DIR" --command "$PYTHON_PATH" --arg "$LAUNCHER"
    fi
elif [ -d "$CODEX_DIR" ]; then
    echo ""
    echo ">>> Codex config found (no codex CLI on PATH) — configuring MCP server..."
    "$PYTHON" "$HELPER" codexmcp install --codex-dir "$CODEX_DIR" --command "$PYTHON_PATH" --arg "$LAUNCHER"
fi

# --- Step 5: Install CLAUDE.md instructions ---
echo ""
echo ">>> Installing ApexScript instructions into $CLAUDE_DIR/CLAUDE.md..."
"$PYTHON" "$HELPER" claudemd install --claude-dir "$CLAUDE_DIR" --block-file "$INSTALL_DIR/claude-md-block.md"

# --- Step 5b: Install AGENTS.md instructions for Codex ---
# Codex has no PreToolUse hooks, so the block carries hard self-directed rules
# instead of a gate (see agents-md-block.md).
if [ -f "$INSTALL_DIR/agents-md-block.md" ] && { command -v codex &>/dev/null || [ -d "$CODEX_DIR" ]; }; then
    echo ""
    echo ">>> Installing ApexScript instructions into $CODEX_DIR/AGENTS.md..."
    "$PYTHON" "$HELPER" codexmd install --codex-dir "$CODEX_DIR" --block-file "$INSTALL_DIR/agents-md-block.md"
fi

# --- Step 6: Install the .apex MCP-gate hook ---
# A PreToolUse hook that blocks Write/Edit on .apex files unless the apexscript
# MCP server was consulted in the current turn. This is the single biggest
# quality lever — it forces snippet/example lookups before code is written.
echo ""
echo ">>> Installing .apex MCP-gate hook..."
mkdir -p "$CLAUDE_DIR/hooks"
HOOK_DST="$CLAUDE_DIR/hooks/apexscript_require_mcp.py"
cp "$SCRIPT_DIR/hooks/apexscript_require_mcp.py" "$HOOK_DST"
# Pieces are passed separately and quoted by the helper (same call shape as
# install.ps1, where a pre-quoted --command lost its quotes on PowerShell 5.1).
"$PYTHON" "$HELPER" hook install --claude-dir "$CLAUDE_DIR" \
    --interpreter "$PYTHON_PATH" --script "$HOOK_DST"

# --- Step 6b: Install Claude skills ---
# Drops skill folders into ~/.claude/skills/ (Claude Code auto-discovers them).
# Currently: apexscript-save-snippets (session -> save_snippet curation).
if [ -d "$SCRIPT_DIR/skills" ]; then
    echo ""
    echo ">>> Installing Claude skills into $CLAUDE_DIR/skills..."
    mkdir -p "$CLAUDE_DIR/skills"
    cp -r "$SCRIPT_DIR/skills/." "$CLAUDE_DIR/skills/"
    echo "    Done."
fi

# --- Step 6c: Install Codex custom prompts ---
# The Codex analog of skills: markdown prompts in ~/.codex/prompts/ become
# /name commands in a Codex session.
if [ -d "$SCRIPT_DIR/prompts" ] && { command -v codex &>/dev/null || [ -d "$CODEX_DIR" ]; }; then
    echo ""
    echo ">>> Installing Codex prompts into $CODEX_DIR/prompts..."
    mkdir -p "$CODEX_DIR/prompts"
    cp "$SCRIPT_DIR/prompts/"*.md "$CODEX_DIR/prompts/"
    echo "    Done."
fi

# --- Step 7: Install the Houdini Python panel ---
echo ""
if [ -d "$SCRIPT_DIR/houdini-panel" ]; then
    echo ">>> Installing Houdini panel..."
    cp -r "$SCRIPT_DIR/houdini-panel" "$INSTALL_DIR/"
    PANEL_ROOT="$INSTALL_DIR/houdini-panel"
    "$PYTHON" "$HELPER" panel install \
        --panel-path "$PANEL_ROOT/apexscript-houdini-panel" \
        --stubs-path "$PANEL_ROOT/stubs" \
        --reference-path "$PANEL_ROOT/reference/apexscript-reference" \
        --houdini-root "$HOME" \
        --houdini-root "$HOME/Library/Preferences/houdini"
else
    echo "Note: Houdini panel not found in bundle, skipping."
fi

# --- Step 8: Install uninstall script ---
# Shipped in the bundle (single source of truth); copied in so it can be run
# later as ~/.apexscript/uninstall.sh.
cp "$SCRIPT_DIR/uninstall.sh" "$INSTALL_DIR/uninstall.sh"
chmod +x "$INSTALL_DIR/uninstall.sh"

# --- Done ---
echo ""
echo "========================================="
echo "  Installation complete!"
echo "========================================="
echo ""
echo "  Install location:  $INSTALL_DIR"
echo "  MCP server:        $PYTHON_PATH $LAUNCHER"
echo "                     (shell wrapper: $MCP_BIN)"
echo "  Snippet library:   $INSTALL_DIR/snippets  (kept across reinstalls)"
if [ -n "$CODE_CMD" ] && [ -n "$VSIX" ]; then
echo "  VS Code extension: installed"
fi
echo "  .apex MCP-gate:    $HOOK_DST"
echo "  Uninstall:         $INSTALL_DIR/uninstall.sh"
echo "  Diagnostics:       \"$PYTHON_PATH\" \"$HELPER\" doctor   (paste its output in bug reports)"
echo "  Install log:       $INSTALL_LOG"
echo ""
echo "Getting started:"
if [ -n "${CODE_CMD:-}" ]; then
echo "  - Open VS Code, create a .apex file, type 'apex.geo.' for completions"
fi
if [ -n "$CLAUDE_CMD" ]; then
echo "  - Open Claude Code — ApexScript MCP tools are available in any project"
echo "  - Writing a .apex file now requires an apexscript MCP call first"
echo "    (bypass once with the token [skip-apex-hook] in your message)"
fi
if command -v codex &>/dev/null || [ -d "$CODEX_DIR" ]; then
echo "  - Open Codex — the 'apexscript' MCP server and AGENTS.md rules are configured"
echo "    (restart any running Codex session to pick up the new config)"
fi
if [ -d "$INSTALL_DIR/houdini-panel" ]; then
echo "  - Restart Houdini and open: Pane Tab Menu > ApexScript Editor"
fi
echo ""
echo "See README.md for more details."
