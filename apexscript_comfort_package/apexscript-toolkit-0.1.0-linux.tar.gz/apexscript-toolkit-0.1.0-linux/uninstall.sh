#!/usr/bin/env bash
# ApexScript Toolkit uninstaller (Linux / macOS / WSL).
#
# Reverses everything install.sh does: the MCP registration, the VS Code
# extension, the .apex MCP-gate hook (+ its settings.json entry), the injected
# CLAUDE.md section, the Houdini panel package files, and the ~/.apexscript dir.
#
# Runnable two ways:
#   - from the install:  ~/.apexscript/uninstall.sh
#   - straight from the bundle:  ./uninstall.sh   (uses the bundled helper)
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALL_DIR="$HOME/.apexscript"
CLAUDE_DIR="$HOME/.claude"

# --purge: also delete snippets/ and workflows/ instead of moving them aside.
PURGE=""
for arg in "$@"; do
    case "$arg" in
        --purge) PURGE="--purge" ;;
    esac
done

# Prefer the installed helper; fall back to one sitting next to this script
# (true when running directly from the unpacked bundle).
HELPER="$INSTALL_DIR/apex_toolkit_config.py"
[ -f "$HELPER" ] || HELPER="$SCRIPT_DIR/apex_toolkit_config.py"

echo "=== Uninstalling ApexScript Toolkit ==="

# Same lookup as the installer: PATH, ~/.local/bin, then the binary bundled
# with Claude Code's VS Code extension (newest first).
CLAUDE_CMD=""
if command -v claude &>/dev/null; then CLAUDE_CMD="claude"
elif [ -x "$HOME/.local/bin/claude" ]; then CLAUDE_CMD="$HOME/.local/bin/claude"
else
    CLAUDE_CMD="$(ls -d "$HOME"/.vscode/extensions/anthropic.claude-code-*/resources/native-binary/claude 2>/dev/null | sort -r | head -1 || true)"
fi
if [ -n "$CLAUDE_CMD" ]; then
    echo ">>> Removing MCP server registration..."
    "$CLAUDE_CMD" mcp remove apexscript --scope user 2>/dev/null || true
fi

CODEX_DIR="$HOME/.codex"
if command -v codex &>/dev/null; then
    echo ">>> Removing Codex MCP server registration..."
    codex mcp remove apexscript 2>/dev/null || true
fi

CODE_CMD=""
command -v code &>/dev/null && CODE_CMD="code"
command -v code-insiders &>/dev/null && CODE_CMD="code-insiders"
if [ -n "$CODE_CMD" ]; then
    echo ">>> Removing VS Code extension..."
    "$CODE_CMD" --uninstall-extension apexscript.apexscript-lsp 2>/dev/null || true
fi

# Undo the structured changes (settings.json / CLAUDE.md / panel json).
PYTHON=""
for cmd in python3 python; do
    if command -v "$cmd" &>/dev/null; then PYTHON="$cmd"; break; fi
done
# Fallback: uv-managed CPython (parity with the installer, for uv-only machines).
if [ -z "$PYTHON" ] && command -v uv &>/dev/null; then
    uvpy="$(uv python find '>=3.11' 2>/dev/null | head -1 || true)"
    [ -n "$uvpy" ] && [ -x "$uvpy" ] && PYTHON="$uvpy"
fi
if [ -n "$PYTHON" ] && [ -f "$HELPER" ]; then
    echo ">>> Removing .apex hook, CLAUDE.md/AGENTS.md sections, and Houdini panel..."
    "$PYTHON" "$HELPER" hook uninstall --claude-dir "$CLAUDE_DIR" || true
    "$PYTHON" "$HELPER" claudemd uninstall --claude-dir "$CLAUDE_DIR" || true
    # Codex cleanup: the AGENTS.md block, plus any marker-delimited config.toml
    # entry the fallback path wrote (a `codex mcp add` entry is removed above;
    # this is a no-op when neither exists).
    "$PYTHON" "$HELPER" codexmd uninstall --codex-dir "$CODEX_DIR" || true
    "$PYTHON" "$HELPER" codexmcp uninstall --codex-dir "$CODEX_DIR" || true
    "$PYTHON" "$HELPER" panel uninstall \
        --houdini-root "$HOME" \
        --houdini-root "$HOME/Library/Preferences/houdini" || true
else
    echo "Note: python/helper not found; skipping settings.json / CLAUDE.md / AGENTS.md / panel cleanup."
fi
rm -f "$CLAUDE_DIR/hooks/apexscript_require_mcp.py"
rm -rf "$CLAUDE_DIR/skills/apexscript-save-snippets"
rm -f "$CODEX_DIR/prompts/apexscript-save-snippets.md"

if [ -d "$INSTALL_DIR" ]; then
    # User data (snippets/, workflows/) is moved next to the install dir unless
    # --purge is given; the helper prints where.
    if [ -n "$PYTHON" ] && [ -f "$HELPER" ]; then
        "$PYTHON" "$HELPER" installdir backup-user-data --install-dir "$INSTALL_DIR" $PURGE || true
    fi
    echo ">>> Removing $INSTALL_DIR..."
    rm -rf "$INSTALL_DIR"
fi
echo "=== Uninstall complete ==="
